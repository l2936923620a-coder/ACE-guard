#!/system/bin/sh
# ============================================================
#  ACE Guard 设置存储
#
#  作用：
#    保存模块运行所需的少量配置信息，让模块在升级后仍能
#    记住当前状态，不需要你重新设置。
#
#  用户须知：
#    · 保存的信息包括当前版本标识与完整性校验值
#    · 这些信息不影响你的个人数据，也不包含隐私内容
#    · 升级模块时这些设置会保留，卸载模块时自动清除
# ============================================================

AG_CFG_KSud="/data/adb/ksu/bin/ksud"
AG_CFG_ID="ace_guard"
AG_CFG_FALLBACK="${MODDIR:-/data/adb/modules/ace_guard}/data/.installed"

# ksud 配置系统是否可用（每个进程只探测一次）
AG_CFG_AVAILABLE=""

# 探测 ksud module config 是否可用
ag_cfg_probe() {
    [ -n "$AG_CFG_AVAILABLE" ] && return 0
    AG_CFG_AVAILABLE="0"
    [ -x "$AG_CFG_KSud" ] || return 1
    # 能列出（哪怕是空）就算可用
    if "$AG_CFG_KSud" module config --internal "$AG_CFG_ID" list >/dev/null 2>&1; then
        AG_CFG_AVAILABLE="1"
        return 0
    fi
    return 1
}

# 读配置：$1=key
ag_cfg_get() {
    _k="$1"
    if ag_cfg_probe; then
        _v=$("$AG_CFG_KSud" module config --internal "$AG_CFG_ID" get "$_k" 2>/dev/null)
        [ -n "$_v" ] && { printf '%s' "$_v"; return 0; }
    fi
    # 回退：键值文件
    if [ -f "$AG_CFG_FALLBACK" ]; then
        _v=$(/system/bin/sed -n "s/^${_k}=//p" "$AG_CFG_FALLBACK" 2>/dev/null | head -n1)
        [ -n "$_v" ] && { printf '%s' "$_v"; return 0; }
    fi
    return 1
}

# 写配置：$1=key $2=value
ag_cfg_set() {
    _k="$1"; _v="$2"
    if ag_cfg_probe; then
        "$AG_CFG_KSud" module config --internal "$AG_CFG_ID" set "$_k" "$_v" >/dev/null 2>&1 \
            && return 0
    fi
    # 回退：键值文件
    _dir=$(/system/bin/toybox dirname "$AG_CFG_FALLBACK" 2>/dev/null)
    mkdir -p "$_dir" 2>/dev/null
    if [ -f "$AG_CFG_FALLBACK" ] && /system/bin/grep -q "^${_k}=" "$AG_CFG_FALLBACK" 2>/dev/null; then
        /system/bin/sed -i "s|^${_k}=.*|${_k}=${_v}|" "$AG_CFG_FALLBACK" 2>/dev/null
    else
        printf '%s=%s\n' "$_k" "$_v" >> "$AG_CFG_FALLBACK" 2>/dev/null
    fi
    chmod 600 "$AG_CFG_FALLBACK" 2>/dev/null
    return 0
}

# 删配置：$1=key
ag_cfg_del() {
    _k="$1"
    if ag_cfg_probe; then
        "$AG_CFG_KSud" module config --internal "$AG_CFG_ID" delete "$_k" >/dev/null 2>&1
    fi
    [ -f "$AG_CFG_FALLBACK" ] && \
        /system/bin/sed -i "/^${_k}=/d" "$AG_CFG_FALLBACK" 2>/dev/null
    return 0
}

# ============================================================
#  卡片描述覆盖（免改 module.prop）
# ============================================================
# KernelSU 官方支持 override.description：设置后管理器直接用这个值
# 替换 module.prop 的 description，不需要也不应该去改 module.prop。
ag_cfg_set_desc() {
    _d="$1"
    if ag_cfg_probe; then
        "$AG_CFG_KSud" module config --internal "$AG_CFG_ID" set override.description "$_d" \
            >/dev/null 2>&1 && return 0
    fi
    return 1
}

ag_cfg_clear_desc() {
    if ag_cfg_probe; then
        "$AG_CFG_KSud" module config --internal "$AG_CFG_ID" delete override.description \
            >/dev/null 2>&1
        return 0
    fi
    return 1
}

# ============================================================
#  版本号：从 module.prop 迁到配置系统
# ============================================================

# 读 module.prop 里的 versionCode（原始值）
ag_cfg_prop_vc() {
    _mp="${MODDIR:-/data/adb/modules/ace_guard}/module.prop"
    /system/bin/sed -n 's/^versionCode=//p' "$_mp" 2>/dev/null | head -n1 | /system/bin/toybox tr -dc '0-9'
}

# 读 module.prop 里的 version 字符串
ag_cfg_prop_ver() {
    _mp="${MODDIR:-/data/adb/modules/ace_guard}/module.prop"
    /system/bin/sed -n 's/^version=//p' "$_mp" 2>/dev/null | head -n1
}

# 已安装版本号（权威来源）
#   优先配置系统；没有记录时用 module.prop 初始化一次
# 已安装版本号（权威来源）
#   优先配置系统；没有记录时用 module.prop 初始化一次
#
#   重要：必须能区分「正常升级」和「用户手改」
#     - 正常升级：模块文件被 KSU 整体替换，module.prop 的 mtime 会更新，
#                 且 zip 安装会重建目录 → 判定为升级，采纳新值
#     - 用户手改：只有 module.prop 一个文件被编辑，其余模块文件不变
#   判定依据：模块主体（script/ 目录内容指纹）是否变化
ag_cfg_installed_vc() {
    _v=$(ag_cfg_get "installed.versionCode" 2>/dev/null)
    case "$_v" in
        ''|*[!0-9]*)
            # 首次运行：把 prop 值固化进配置
            _p=$(ag_cfg_prop_vc)
            case "$_p" in ''|*[!0-9]*) _p=0 ;; esac
            if [ "$_p" -gt 0 ]; then
                ag_cfg_set "installed.versionCode" "$_p"
                ag_cfg_set "installed.prop_mtime" "$(ag_cfg_prop_mtime)"
            fi
            printf '%s' "$_p"
            return 0 ;;
    esac

    # 已有权威值：检查是不是正常升级造成的 prop 变化
    _p=$(ag_cfg_prop_vc)
    case "$_p" in ''|*[!0-9]*) _p=0 ;; esac

    if [ "$_p" -gt 0 ] && [ "$_p" != "$_v" ]; then
        # prop 版本和权威值不一致，判断是升级还是篡改
        if ag_cfg_is_real_upgrade; then
            # 正常升级：采纳新版本号
            ag_cfg_set "installed.versionCode" "$_p"
            ag_cfg_set "installed.prop_mtime" "$(ag_cfg_prop_mtime)"
            _fv=$(ag_cfg_prop_ver)
            [ -n "$_fv" ] && ag_cfg_set "installed.version" "$_fv"
            command -v ag_log >/dev/null 2>&1 && \
                ag_log INFO "检测到正常升级：版本号更新为 $_p"
            printf '%s' "$_p"
            return 0
        fi
        # 否则保持权威值不变（视为篡改，由 guard 处理）
    fi

    printf '%s' "$_v"
}

# module.prop 的修改时间
ag_cfg_prop_mtime() {
    _mp="${MODDIR:-/data/adb/modules/ace_guard}/module.prop"
    /system/bin/toybox stat -c %Y "$_mp" 2>/dev/null || echo 0
}

# 判断 prop 的版本变化是不是「正常升级」
#   正常升级特征：核心脚本目录的文件有变化（KSU 安装会整体替换模块文件）
#   手改特征：只有 module.prop 变了，script/ 里的文件一个都没动
ag_cfg_is_real_upgrade() {
    _mp="${MODDIR:-/data/adb/modules/ace_guard}/module.prop"

    # 1) 模块目录的 mtime 也是更新过的（zip 解压会重建）
    _dir_mt=$(/system/bin/toybox stat -c %Y "${MODDIR:-/data/adb/modules/ace_guard}" 2>/dev/null || echo 0)
    _prop_mt=$(ag_cfg_prop_mtime)

    # 2) 关键脚本 mtime 是否接近 prop 的 mtime（安装时会一起写入）
    _auth_mt=$(/system/bin/toybox stat -c %Y "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh" 2>/dev/null || echo 0)

    # 如果 script/auth.sh 和 module.prop 的修改时间差在 60 秒内，
    # 说明是安装/升级时一起写入的，不是单独编辑 prop
    if [ "$_prop_mt" -gt 0 ] && [ "$_auth_mt" -gt 0 ]; then
        _diff=$(( _prop_mt - _auth_mt ))
        [ "$_diff" -lt 0 ] && _diff=$(( 0 - _diff ))
        [ "$_diff" -le 60 ] && return 0
    fi

    # 3) 模块目录整体比 prop 老很多，而 prop 刚被改过 → 手改
    return 1
}

# 检查 module.prop 是否被改过
#   返回 0=一致  1=被改动（此时以配置值为准）
ag_cfg_verify_prop() {
    _cfg=$(ag_cfg_get "installed.versionCode" 2>/dev/null)
    [ -n "$_cfg" ] || return 0     # 还没建立基线，跳过
    _prop=$(ag_cfg_prop_vc)
    [ "$_cfg" = "$_prop" ] && return 0
    return 1
}
AG_TAMPER_LOG="${AG_NOTICE_DIR:-/data/adb/ace_guard/notice}/tamper.log"

# 检测并自动修复被篡改的 module.prop
#   返回 0=正常  1=发现篡改并已修复  2=发现篡改但修复失败
ag_cfg_guard_prop() {
    _cfg=$(ag_cfg_get "installed.versionCode" 2>/dev/null)
    [ -n "$_cfg" ] || return 0
    _prop=$(ag_cfg_prop_vc)
    [ "$_cfg" = "$_prop" ] && return 0

    _mp="${MODDIR:-/data/adb/modules/ace_guard}/module.prop"

    # 记录告警（每次篡改都留痕）
    mkdir -p /data/adb/ace_guard/notice 2>/dev/null
    echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') TAMPER versionCode ${_cfg}->${_prop} (应为 ${_cfg}，实际 ${_prop})" \
        >> "$AG_TAMPER_LOG" 2>/dev/null

    # 同步日志
    command -v ag_log >/dev/null 2>&1 && \
        ag_log WARN "检测到 module.prop 版本号被修改：$_prop（应为 $_cfg），已强制回退"

    # 自动回退 versionCode
    if [ -f "$_mp" ]; then
        /system/bin/sed -i "s|^versionCode=.*|versionCode=${_cfg}|" "$_mp" 2>/dev/null

        # 同步回退 version 字符串（从配置里的版本名，没有就从 json 反推）
        _cfgver=$(ag_cfg_get "installed.version" 2>/dev/null)
        if [ -n "$_cfgver" ]; then
            /system/bin/sed -i "s|^version=.*|version=${_cfgver}|" "$_mp" 2>/dev/null
        fi

        # 校验是否真的改回来了
        _now=$(ag_cfg_prop_vc)
        if [ "$_now" = "$_cfg" ]; then
            echo "$(date '+%Y-%m-%d %H:%M:%S') REVERTED to $_cfg" \
                >> "$AG_TAMPER_LOG" 2>/dev/null
            # 同步刷新 .module.prop.orig，避免下次刷新卡片又写回旧值
            if [ -f "${MODDIR:-/data/adb/modules/ace_guard}/.module.prop.orig" ]; then
                /system/bin/sed -i "s|^versionCode=.*|versionCode=${_cfg}|" \
                    "${MODDIR:-/data/adb/modules/ace_guard}/.module.prop.orig" 2>/dev/null
                [ -n "$_cfgver" ] && /system/bin/sed -i "s|^version=.*|version=${_cfgver}|" \
                    "${MODDIR:-/data/adb/modules/ace_guard}/.module.prop.orig" 2>/dev/null
            fi
            return 1
        fi
        return 2
    fi
    return 2
}

# 篡改记录最近 N 条
ag_cfg_tamper_log() {
    [ -f "$AG_TAMPER_LOG" ] || return 0
    /system/bin/toybox tail -n "${1:-20}" "$AG_TAMPER_LOG" 2>/dev/null
}
