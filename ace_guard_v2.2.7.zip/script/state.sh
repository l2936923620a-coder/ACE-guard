#!/system/bin/sh
# ============================================================
#  ACE Guard 游戏状态中心 (v1.1.9)
#
#  全模块唯一的游戏进程检测点。
#  所有循环不再各自调 ag_find_game_pid，统一读这里的缓存。
#
#  检测手段：/system/bin/pidof -s
#    内核级查找，实测 21~30ms（1000+ 进程时）
#    对比旧版 shell 遍历 /proc（fork cat+tr）：1239~2026ms
#
#  缓存有效期：AG_STATE_TTL 秒（默认等于 LIFECYCLE_INTERVAL）
#    生命周期循环是唯一刷新者，其余循环只读
# ============================================================

AG_STATE_PID=""        # 缓存的游戏 PID（空=未运行）
AG_STATE_TS=0          # 上次刷新时间戳（秒）
AG_STATE_TTL=5         # 缓存有效期

# ---------- 原始检测（不做缓存）----------
ag_probe_game_pid() {
    if [ -x /system/bin/pidof ]; then
        /system/bin/pidof -s "$PKG" 2>/dev/null
        return $?
    fi
    # 回退：pidof 缺失时用 shell 内建 read 遍历
    local p a0
    for p in /proc/[0-9]*; do
        { IFS= read -r -d '' a0 < "$p/cmdline"; } 2>/dev/null || continue
        [ -n "$a0" ] || continue
        case "$a0" in
            "$PKG"|"$PKG":*) echo "${p#/proc/}"; return 0 ;;
        esac
    done
    return 1
}

# ---------- 刷新缓存（仅生命周期循环调用）----------
ag_state_refresh() {
    AG_STATE_PID=$(ag_probe_game_pid 2>/dev/null)
    AG_STATE_TS=$(/system/bin/date +%s 2>/dev/null)
    [ -z "$AG_STATE_TS" ] && AG_STATE_TS=0
}

# ---------- 读缓存（其余循环调用，过期不主动刷新）----------
# 返回 0=游戏运行中(输出PID)  1=未运行
# 缓存过期时不刷新，只返回上次结果（等生命周期循环更新）
ag_game_running() {
    # 缓存新鲜：直接用
    if [ -n "$AG_STATE_TS" ] && [ "$AG_STATE_TS" != "0" ]; then
        local now age
        now=$(/system/bin/date +%s 2>/dev/null)
        [ -n "$now" ] || now=0
        age=$((now - AG_STATE_TS))
        # 缓存过期超过 TTL*3 说明生命周期循环可能挂了，自行补一次
        if [ "$age" -gt "$((AG_STATE_TTL * 3))" ]; then
            ag_state_refresh
        fi
    else
        ag_state_refresh
    fi

    [ -n "$AG_STATE_PID" ] || return 1
    # 二次确认：缓存的 PID 是否还活着（读 /proc，不 fork）
    [ -d "/proc/$AG_STATE_PID" ] || return 1
    echo "$AG_STATE_PID"
    return 0
}

# ---------- 兼容旧接口 ----------
# 全模块原有调用点保持 ag_find_game_pid 不变，内部走缓存
ag_find_game_pid() {
    ag_game_running
}
