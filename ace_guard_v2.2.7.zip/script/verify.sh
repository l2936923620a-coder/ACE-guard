#!/system/bin/sh

# 独立运行时自动载入所需依赖
if ! command -v ag_hmac_hex >/dev/null 2>&1; then
    [ -f "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh" ] && \
        . "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh" 2>/dev/null
fi
# ============================================================
#  ACE Guard 更新信息校验
#
#  作用：
#    确认收到的更新信息确实来自本模块的发布方，没有在传输
#    过程中被替换或篡改，保证你下载到的更新是安全可靠的。
#
#  对用户的影响：
#    · 信息正常时，更新提示与下载照常工作
#    · 信息异常时，模块会忽略这条更新提示，不会误更新
#    · 同时会检查当前版本是否过旧，必要时提醒你尽快更新
#
#  说明：
#    本模块只校验更新信息的来源，不收集与上传任何数据。
# ============================================================

# 从缓存 JSON 读取签名相关字段到 AG_V_* 变量
ag_verify_load() {
    _f="${1:-$AG_NOTICE_JSON}"
    [ -f "$_f" ] || return 1
    AG_V_VER=$(ag_notice_json_get "$_f" version str 2>/dev/null)
    AG_V_VC=$(ag_notice_json_get "$_f" versionCode num 2>/dev/null)
    AG_V_MIN=$(ag_notice_json_get "$_f" minAllowed num 2>/dev/null)
    AG_V_KILL=$(ag_notice_json_get "$_f" killBelow num 2>/dev/null)
    AG_V_URL=$(ag_notice_json_get "$_f" url str 2>/dev/null)
    AG_V_SIG=$(ag_notice_json_get "$_f" sig str 2>/dev/null)
    case "$AG_V_VC" in ''|*[!0-9]*) AG_V_VC=0 ;; esac
    case "$AG_V_MIN" in ''|*[!0-9]*) AG_V_MIN=0 ;; esac
    case "$AG_V_KILL" in ''|*[!0-9]*) AG_V_KILL=0 ;; esac
    return 0
}

# 计算期望签名
ag_verify_sign() {
    _msg="${AG_V_VER}|${AG_V_VC}|${AG_V_MIN}|${AG_V_KILL}|${AG_V_URL}"
    ag_hmac_hex "$_msg" 2>/dev/null | /system/bin/toybox cut -c1-16
}

# 校验签名
#   返回 0=通过  1=签名错误  2=清单没有 sig 字段（未启用签名）
ag_verify_check() {
    [ -n "${AG_V_SIG:-}" ] || return 2
    _want=$(ag_verify_sign)
    _got=$(printf '%s' "$AG_V_SIG" | /system/bin/toybox tr 'A-F' 'a-f')
    [ "$_want" = "$_got" ] && return 0
    AG_VERIFY_EXPECT="$_want"
    AG_VERIFY_ACTUAL="$_got"
    return 1
}

# 版本门槛判定
#   返回 0=正常  1=低于 minAllowed（警告）  2=低于 killBelow（强制停止）
ag_verify_threshold() {
    _cur="$1"
    case "$_cur" in ''|*[!0-9]*) _cur=0 ;; esac
    [ "${AG_V_KILL:-0}" -gt 0 ] && [ "$_cur" -lt "$AG_V_KILL" ] && return 2
    [ "${AG_V_MIN:-0}" -gt 0 ] && [ "$_cur" -lt "$AG_V_MIN" ] && return 1
    return 0
}

# 完整校验并把结论写入 AG_VERIFY_STATE
#     state: ok | unsigned | badsig | too_old | warning
ag_verify_evaluate() {
    _cur=$(ag_notice_local_vc 2>/dev/null)
    case "$_cur" in ''|*[!0-9]*) _cur=0 ;; esac

    ag_verify_load 2>/dev/null || { AG_VERIFY_STATE="ok"; return 0; }

    # 1) 签名
    ag_verify_check
    case $? in
        0) ;;
        2) AG_VERIFY_STATE="unsigned"
           AG_VERIFY_MSG="远程清单未带签名（作者尚未启用）"
           return 0 ;;
        *) AG_VERIFY_STATE="badsig"
           AG_VERIFY_MSG="签名校验失败，清单可能被篡改"
           return 1 ;;
    esac

    # 2) 版本门槛
    ag_verify_threshold "$_cur"
    case $? in
        0) AG_VERIFY_STATE="ok"; AG_VERIFY_MSG="" ;;
        1) AG_VERIFY_STATE="warning"
           AG_VERIFY_MSG="当前版本 v${_cur} 低于最低要求 v${AG_V_MIN}，建议尽快更新" ;;
        2) AG_VERIFY_STATE="too_old"
           AG_VERIFY_MSG="当前版本 v${_cur} 已被停止支持（最低 v${AG_V_KILL}），请立即更新"
           return 2 ;;
    esac
    return 0
}

# 记录校验结果
ag_verify_log() {
    _log="${AG_NOTICE_DIR:-/data/adb/ace_guard/notice}/verify.log"
    mkdir -p /data/adb/ace_guard/notice 2>/dev/null
    echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') state=${AG_VERIFY_STATE:-?} msg=${AG_VERIFY_MSG:-} vc=${AG_V_VC:-?} min=${AG_V_MIN:-?} kill=${AG_V_KILL:-?}" \
        >> "$_log" 2>/dev/null
    # 只保留最近 200 行
    _sz=$(/system/bin/toybox stat -c %s "$_log" 2>/dev/null || echo 0)
    [ "$_sz" -gt 32768 ] && /system/bin/toybox tail -n 200 "$_log" > "$_log.t" 2>/dev/null && \
        mv -f "$_log.t" "$_log" 2>/dev/null
    return 0
}
