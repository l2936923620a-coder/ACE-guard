#!/system/bin/sh

# >>> AG-AUTH-GUARD >>>
# 授权闸门（性能优化版）
#   1) 同进程内复用：_AG_AUTH_GUARDED=1 直接跳过
#   2) 跨进程复用：60 秒内通过的标记文件，避免每次 source 都跑 sha256
#   3) 缓存失效才真正校验
if [ "${_AG_AUTH_GUARDED:-0}" != "1" ]; then
    _ag_gcache="/data/adb/ace_guard/auth/.guardok"
    _ag_gok=0
    if [ -f "$_ag_gcache" ]; then
        _ag_gt=$(cat "$_ag_gcache" 2>/dev/null)
        _ag_now=$(/system/bin/date +%s)
        # 60 秒内的标记视为有效
        case "$_ag_gt" in
            ''|*[!0-9]*) : ;;
            *) [ $(( _ag_now - _ag_gt )) -lt 60 ] && _ag_gok=1 ;;
        esac
    fi
    if [ "$_ag_gok" != "1" ]; then
        if [ -f "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh" ]; then
            . "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh"
            if ! ag_auth_guard "${0##*/}" 2>/dev/null; then
                echo "此设备未授权，功能已冻结" >&2
                exit 1
            fi
            /system/bin/date +%s > "$_ag_gcache" 2>/dev/null
        fi
    fi
fi
_AG_AUTH_GUARDED=1
# <<< AG-AUTH-GUARD <<<

# ============================================================
#  ACE Guard 监控与反制
#  监控: ACE 下发文件 / 风险目录 / 进程 / 属性
#  反制: 按 COUNTER_ACTIONS 自动执行
# ============================================================

# ---------- 定位游戏数据目录 ----------
# 优先取文件最多的那个（游戏真正使用的用户），避免命中残留空目录
ag_find_game_dir() {
    local d best="" bestn=-1 n
    for d in /data_mirror/data_ce/null/*/"$PKG" /data/user/*/"$PKG"; do
        [ -d "$d" ] || continue
        n=$(/system/bin/toybox ls -A "$d/files" 2>/dev/null | /system/bin/toybox wc -l)
        [ -z "$n" ] && n=0
        if [ "$n" -gt "$bestn" ]; then
            bestn=$n
            best="$d"
        fi
    done
    [ -n "$best" ] && { echo "$best"; return 0; }
    return 1
}


# ---------- 检测1: 下发文件 ----------
# 移植自 上号.sh guard_inside 的 find -maxdepth 2 通配删除：
#   1. 通配串在 files/ 与 cache/ 下都展开（原模块只扫 files/）
#   2. 走 find -maxdepth $PURGE_MAXDEPTH，能挖到子目录里的下发文件
#   3. 目录写入检测同时覆盖 cache/
ag_check_purge_files() {
    local base="$1" f d hit=0
    [ -d "$base" ] || { echo 0; return 0; }
    [ "$ENABLE_PURGE_WATCH" = "1" ] || { echo 0; return 0; }

    local depth="${PURGE_MAXDEPTH:-2}"

    # 1. 通配扫描（files + cache 双根，find 限深）
    local pat
    for pat in $PURGE_PATTERNS; do
        [ -n "$pat" ] || continue
        for f in $(/system/bin/toybox find "$base/files" -maxdepth "$depth" -name "$pat" 2>/dev/null) \
                 $(/system/bin/toybox find "$base/cache" -maxdepth "$depth" -name "$pat" 2>/dev/null); do
            [ -e "$f" ] || continue
            ag_alert "检测到下发文件: ${f#"$base/"}" >/dev/null 2>&1
            [ "$ENABLE_AUTO_PURGE" = "1" ] && /system/bin/toybox rm -rf "$f" 2>/dev/null
            hit=$((hit + 1))
        done
    done

    # 2. 目录被写入
    local sub
    for d in $PURGE_DIRS; do
        [ -n "$d" ] || continue
        for sub in "files/$d" "cache/$d"; do
            [ -d "$base/$sub" ] || continue
            if [ -n "$(/system/bin/toybox ls -A "$base/$sub" 2>/dev/null)" ]; then
                ag_alert "检测到下发目录有写入: $sub" >/dev/null 2>&1
                [ "$ENABLE_AUTO_PURGE" = "1" ] && /system/bin/toybox rm -rf "$base/$sub"/* 2>/dev/null
                hit=$((hit + 1))
            fi
        done
    done
    echo "$hit"
}

# ---------- 检测2: 隐藏是否被破坏 ----------
ag_check_hide() {
    local self=$$ p pid broken=0
    for p in /proc/[0-9]*; do
        pid="${p#/proc/}"
        [ "$pid" = "$self" ] && continue
        local ctx
        ctx=$(/system/bin/cat "$p/attr/current" 2>/dev/null | /system/bin/toybox tr -d '\0')
        case "$ctx" in
            *untrusted_app*)
                ag_hide_injected "$pid" || broken=$((broken + 1))
                ;;
        esac
    done
    echo "$broken"
}

# ---------- 检测3: 游戏进程注入痕迹 ----------
ag_check_inject_trace() {
    local pid="$1" cnt
    [ -z "$pid" ] && return 0
    cnt=$(/system/bin/cat "/proc/$pid/maps" 2>/dev/null | \
          /system/bin/grep -icE "zygisk|lspd|magisk|shamiko|ksud|hma")
    echo "$cnt"
}

# ---------- 检测4: 关键属性 ----------
ag_check_props() {
    local bad=""
    [ "$(/system/bin/getprop ro.debuggable 2>/dev/null)" = "0" ] || bad="$bad ro.debuggable"
    [ "$(/system/bin/getprop ro.secure 2>/dev/null)" = "1" ] || bad="$bad ro.secure"
    [ "$(/system/bin/getprop ro.build.tags 2>/dev/null)" = "release-keys" ] || bad="$bad ro.build.tags"
    [ "$(/system/bin/getprop ro.boot.flash.locked 2>/dev/null)" = "1" ] || bad="$bad flash.locked"
    [ "$(/system/bin/getprop ro.boot.verifiedbootstate 2>/dev/null)" = "green" ] || bad="$bad verifiedboot"
    echo "$bad"
}

# ---------- 执行反制 ----------
ag_counter_act() {
    local reason="$1" act
    ag_log ALERT "触发反制: $reason"
    for act in $COUNTER_ACTIONS; do
        case "$act" in
            purge)
                local base
                base=$(ag_find_game_dir)
                [ -n "$base" ] && {
                    # 复用 ag_check_purge_files 的同一套通配+find 扫描
                    local old
                    old="$ENABLE_AUTO_PURGE"
                    ENABLE_AUTO_PURGE=1
                    ag_check_purge_files "$base" >/dev/null 2>&1
                    ENABLE_AUTO_PURGE="$old"
                }
                ag_log INFO "反制: 已清理下发文件"
                ;;
            rehide)
                # 隐藏注入挂载已移除，rehide 改为重新执行目录遮蔽 + 守护锁
                [ -x "$MODDIR/script/shadow.sh" ] && . "$MODDIR/script/shadow.sh" && ag_shadow_sweep
                ag_log INFO "反制: 已重建目录遮蔽"
                ;;
            rotate)
                ag_identity_rotate && ag_identity_apply
                ag_log INFO "反制: 已轮换身份"
                ;;
            block)
                ag_block_up
                ag_log INFO "反制: 已阻断上报"
                ;;
        esac
    done
}

# ---------- 上报阻断（可选，默认关闭） ----------
ag_block_up() {
    local rp="/data/adb/ksu/bin/busybox"
    [ -x "$rp" ] || rp=/system/bin/toybox

    /system/bin/iptables -N ACG_BLOCK 2>/dev/null
    /system/bin/iptables -F ACG_BLOCK 2>/dev/null

    local pid uid
    pid=$(ag_find_game_pid)
    [ -n "$pid" ] && uid=$(/system/bin/stat -c %u "/proc/$pid" 2>/dev/null)

    if [ -n "$uid" ]; then
        local d
        for d in statdata action_track upload_log cheat_submit traceupload busi_report; do
            /system/bin/iptables -A ACG_BLOCK -m owner --uid-owner "$uid" \
                -m string --string "$d" --algo bm -j DROP 2>/dev/null
        done
    fi
    /system/bin/iptables -C OUTPUT -j ACG_BLOCK 2>/dev/null || \
        /system/bin/iptables -I OUTPUT 1 -j ACG_BLOCK 2>/dev/null
}

ag_block_down() {
    /system/bin/iptables -D OUTPUT -j ACG_BLOCK 2>/dev/null
    /system/bin/iptables -F ACG_BLOCK 2>/dev/null
    /system/bin/iptables -X ACG_BLOCK 2>/dev/null
}

# ---------- 主循环 ----------
# 移植自 上号.sh 主循环的取模限频：
#   COUNTER % 4 == 0 才做昂贵的 find 扫描，避免每轮都全盘遍历
#   这里用 tick % 3（间隔 30s → 实际约 90s 一次），并加"有游戏才扫"前置条件
ag_monitor_loop() {
    ag_log INFO "监控启动 (间隔 ${MONITOR_INTERVAL}s，重扫周期 $((MONITOR_INTERVAL * 3))s)"
    local tick=0 base n gpid cnt
    while true; do
        tick=$((tick + 1))

        # 游戏进程状态（触发退出清理）—— 每轮都要查，轻量
        gpid=$(ag_find_game_pid 2>/dev/null)
        ag_check_game_exit "$gpid"

        # 下发文件检测：每 3 轮一次，且只在游戏运行或目录有内容时才扫
        if [ $((tick % 3)) -eq 1 ] && [ "$ENABLE_PURGE_WATCH" = "1" ]; then
            base=$(ag_find_game_dir)
            if [ -n "$base" ]; then
                n=$(ag_check_purge_files "$base")
                [ -n "$n" ] && [ "$n" -gt 0 ] && ag_counter_act "下发文件 x$n"
            fi
        fi

        # 游戏运行时：检查注入痕迹
        if [ -n "$gpid" ]; then
            cnt=$(ag_check_inject_trace "$gpid")
            [ -n "$cnt" ] && [ "$cnt" -gt 0 ] && ag_alert "游戏 maps 命中注入痕迹 $cnt 处"
        fi

        /system/bin/sleep "$MONITOR_INTERVAL"
    done
}
