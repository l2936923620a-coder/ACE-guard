#!/system/bin/sh
# ============================================================
#  ACE Guard 环境诊断  v2
#
#  核心原则：以【目标 APP 的上下文】做探针，而不是以 root 视角。
#
#  为什么这很重要：
#    - 游戏进程有独立的 SELinux 域 (untrusted_app_30:s0:c...)
#    - 游戏进程有独立的 mount namespace
#    - root 看到的 /proc/modules、/data/adb、su 路径，游戏根本看不到
#    - 用 root 视角自查会得出"到处都是 Root 痕迹"的错误结论
#
#  实现：读取目标进程的 /proc/<pid>/ 下真实数据（mountinfo / maps /
#        status / attr / ns），等价于站在游戏内部观察自己的环境。
#        目标进程未运行时，退化为「沙盒推演」并明确标注。
# ============================================================

AG_DIAG_JSON=""
AG_DIAG_FIRST=1

agd_esc() {
    printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e 's/\r//g' -e 's/\t/ /g' \
        | awk 'BEGIN{ORS=""} {if(NR>1)printf "\\n"; print}'
}

# $1=分组 $2=key $3=中文名 $4=级别 $5=说明 $6=重要(1/0) $7=观察视角
agd_add() {
    [ "$AG_DIAG_FIRST" = "1" ] || AG_DIAG_JSON="$AG_DIAG_JSON,"
    AG_DIAG_FIRST=0
    AG_DIAG_JSON="$AG_DIAG_JSON{\"group\":\"$(agd_esc "$1")\",\"key\":\"$(agd_esc "$2")\",\"name\":\"$(agd_esc "$3")\",\"state\":\"$4\",\"detail\":\"$(agd_esc "$5")\",\"important\":${6:-0},\"scope\":\"$(agd_esc "${7:-app}")\"}"
}

agd_begin() { AG_DIAG_JSON=""; AG_DIAG_FIRST=1; }
agd_end()   { printf '[%s]' "$AG_DIAG_JSON"; }

# ============================================================
#  目标进程定位
# ============================================================
AGD_PID=""
AGD_UID=""
AGD_CTX=""
AGD_MNTNS=""

agd_find_target() {
    AGD_PID=""
    AGD_UID=""
    AGD_CTX=""
    AGD_MNTNS=""

    # 优先用模块已有的查找函数
    if command -v ag_find_game_pid >/dev/null 2>&1; then
        AGD_PID=$(ag_find_game_pid 2>/dev/null)
    fi
    # 兜底：直接扫 ps
    if [ -z "$AGD_PID" ]; then
        AGD_PID=$(/system/bin/toybox ps -A -o PID,ARGS 2>/dev/null \
                  | /system/bin/grep "$PKG" | /system/bin/grep -v grep \
                  | awk '{print $1}' | head -n1)
    fi
    [ -n "$AGD_PID" ] || return 1
    [ -d "/proc/$AGD_PID" ] || { AGD_PID=""; return 1; }

    AGD_UID=$(/system/bin/toybox ps -A -o UID -p "$AGD_PID" 2>/dev/null | tail -n1 | tr -d ' ')
    AGD_CTX=$(cat "/proc/$AGD_PID/attr/current" 2>/dev/null | tr -d '\0')
    AGD_MNTNS=$(/system/bin/toybox readlink "/proc/$AGD_PID/ns/mnt" 2>/dev/null)
    return 0
}

# ============================================================
#  上下文总览
# ============================================================
agd_group_context() {
    _g="观察上下文"

    if agd_find_target; then
        agd_add "$_g" "ctx_pid" "目标进程" "OK" "PID $AGD_PID · $PKG" 1 "app"
        agd_add "$_g" "ctx_uid" "运行身份" "OK" "UID $AGD_UID" 1 "app"
        agd_add "$_g" "ctx_selinux" "SELinux 域" "OK" "$AGD_CTX" 1 "app"
        agd_add "$_g" "ctx_mntns" "挂载命名空间" "OK" "$AGD_MNTNS" 1 "app"
        agd_add "$_g" "ctx_scope" "探针视角" "OK" "读取目标进程 /proc 真实数据（非 root 视角）" 1 "app"
    else
        agd_add "$_g" "ctx_pid" "目标进程" "SKIP" "$PKG 未运行，无法采样进程上下文" 1 "app"
        agd_add "$_g" "ctx_scope" "探针视角" "WARN" "退化为沙盒推演，结果仅供参考" 1 "app"
    fi
}

# ============================================================
#  一、APP 视角的挂载表（核心）
#  直接读 /proc/<pid>/mountinfo，就是游戏看到的挂载视图
# ============================================================
agd_group_mountview() {
    _g="APP 挂载视图"

    if [ -z "$AGD_PID" ]; then
        agd_add "$_g" "mv_na" "挂载视图" "SKIP" "目标未运行，无法读取其挂载表" 1 "app"
        return 0
    fi

    _mi="/proc/$AGD_PID/mountinfo"
    if [ ! -r "$_mi" ]; then
        agd_add "$_g" "mv_na" "挂载视图" "FAIL" "无法读取 $PKG 的 mountinfo" 1 "app"
        return 0
    fi

    _cnt=$(wc -l < "$_mi" 2>/dev/null)
    agd_add "$_g" "mv_count" "挂载条目总数" "INFO" "$_cnt 条（APP 视角）" 0 "app"

    # 1) 游戏数据目录上的挂载（遮蔽是否生效）
    _shadow=$(/system/bin/grep -c "$PKG" "$_mi" 2>/dev/null)
    _shadow=${_shadow:-0}
    if [ "$_shadow" -gt 0 ]; then
        agd_add "$_g" "mv_shadow" "游戏目录挂载" "OK" "发现 $_shadow 条挂载在 $PKG 路径上 · 遮蔽已生效" 1 "app"
        # 逐条列出挂载目的路径
        _paths=$(/system/bin/grep "$PKG" "$_mi" 2>/dev/null | awk '{for(i=5;i<=NF;i++){if($i=="/")break}; print $5}' | head -n6)
        for p in $_paths; do
            agd_add "$_g" "mv_p_$(echo "$p" | tr '/.' '__')" "挂载点" "OK" "$p" 0 "app"
        done
    else
        agd_add "$_g" "mv_shadow" "游戏目录挂载" "WARN" "APP 挂载表中无 $PKG 相关挂载（游戏运行中应出现）" 1 "app"
    fi

    # 2) Root / 模块相关挂载在 APP 视角是否可见
    _root_mnt=$(/system/bin/grep -cE "magisk|ksu|apatch|overlay.*(adb|magisk)" "$_mi" 2>/dev/null)
    _root_mnt=${_root_mnt:-0}
    if [ "$_root_mnt" -gt 0 ]; then
        agd_add "$_g" "mv_root" "Root 模块挂载" "FAIL" "APP 挂载表中可见 $_root_mnt 条 Root/模块挂载" 1 "app"
        _samples=$(/system/bin/grep -E "magisk|ksu|apatch" "$_mi" 2>/dev/null | awk '{print $5}' | head -n4 | tr '\n' ' ')
        [ -n "$_samples" ] && agd_add "$_g" "mv_root_s" "可见挂载点" "FAIL" "$_samples" 1 "app"
    else
        agd_add "$_g" "mv_root" "Root 模块挂载" "OK" "APP 挂载表中未见 Root/模块痕迹" 1 "app"
    fi

    # 3) 系统分区是否被 rw 挂载（APP 视角）
    _rw=$(/system/bin/grep -E " /(system|vendor|product|system_ext) " "$_mi" 2>/dev/null | /system/bin/grep -c " rw,")
    _rw=${_rw:-0}
    if [ "$_rw" -gt 0 ]; then
        agd_add "$_g" "mv_rw" "系统分区挂载" "FAIL" "APP 视角下 $_rw 个系统分区是 rw" 1 "app"
    else
        agd_add "$_g" "mv_rw" "系统分区挂载" "OK" "系统分区全部只读" 0 "app"
    fi

    # 4) data_mirror / 沙盒路径暴露
    _mir=$(/system/bin/grep -c "data_mirror" "$_mi" 2>/dev/null)
    _mir=${_mir:-0}
    agd_add "$_g" "mv_mirror" "data_mirror 可见" "$([ "$_mir" -gt 0 ] && echo WARN || echo OK)" \
        "$_mir 条（$([ "$_mir" -gt 0 ] && echo "说明运行在多用户/分身沙盒" || echo "无")）" 0 "app"
}

# ============================================================
#  二、APP 视角的进程属性（/proc/<pid>/status）
# ============================================================
agd_group_procattr() {
    _g="APP 进程属性"

    if [ -z "$AGD_PID" ]; then
        agd_add "$_g" "pa_na" "进程属性" "SKIP" "目标未运行" 0 "app"
        return 0
    fi

    _st="/proc/$AGD_PID/status"
    [ -r "$_st" ] || { agd_add "$_g" "pa_na" "进程属性" "FAIL" "无法读取 status" 0 "app"; return 0; }

    # Seccomp（游戏进程自己的）
    _sec=$(/system/bin/grep -i "^Seccomp:" "$_st" 2>/dev/null | awk '{print $2}')
    case "$_sec" in
        2) agd_add "$_g" "pa_seccomp" "Seccomp 过滤" "OK" "过滤模式(2) · 与正常应用一致" 1 "app" ;;
        1) agd_add "$_g" "pa_seccomp" "Seccomp 过滤" "WARN" "严格模式(1) · 少见" 0 "app" ;;
        0) agd_add "$_g" "pa_seccomp" "Seccomp 过滤" "FAIL" "已禁用(0) · ACE 会直接判定可疑" 1 "app" ;;
        *) agd_add "$_g" "pa_seccomp" "Seccomp 过滤" "WARN" "未知(${_sec:-空})" 0 "app" ;;
    esac

    # TracerPid（谁在调试它）
    _tp=$(/system/bin/grep -i "^TracerPid:" "$_st" 2>/dev/null | awk '{print $2}')
    _tp=${_tp:-0}
    if [ "$_tp" = "0" ]; then
        agd_add "$_g" "pa_tracer" "被调试状态" "OK" "无 TracerPid 附加" 1 "app"
    else
        _tn=$(cat "/proc/$_tp/cmdline" 2>/dev/null | tr '\0' ' ')
        agd_add "$_g" "pa_tracer" "被调试状态" "FAIL" "被 PID $_tp 附加：${_tn:-未知进程}" 1 "app"
    fi

    # NoNewPrivs
    _nnp=$(/system/bin/grep -i "^NoNewPrivs:" "$_st" 2>/dev/null | awk '{print $2}')
    agd_add "$_g" "pa_nnp" "提权限制" "INFO" "NoNewPrivs=${_nnp:-未知}" 0 "app"

    # 进程 UID/GID 集合
    _uidline=$(/system/bin/grep -i "^Uid:" "$_st" 2>/dev/null | head -n1)
    agd_add "$_g" "pa_uidline" "UID 集合" "INFO" "${_uidline:-未知}" 0 "app"

    # 线程数（注入常伴随异常线程）
    _thr=$(/system/bin/grep -i "^Threads:" "$_st" 2>/dev/null | awk '{print $2}')
    agd_add "$_g" "pa_threads" "线程数" "INFO" "${_thr:-未知}" 0 "app"
}

# ============================================================
#  三、APP 视角的 maps（注入库检测）
# ============================================================
agd_group_maps() {
    _g="APP 内存映射"

    if [ -z "$AGD_PID" ]; then
        agd_add "$_g" "mp_na" "内存映射" "SKIP" "目标未运行" 0 "app"
        return 0
    fi

    _mp="/proc/$AGD_PID/maps"
    [ -r "$_mp" ] || { agd_add "$_g" "mp_na" "内存映射" "FAIL" "无法读取 maps" 1 "app"; return 0; }

    # 1) 可疑注入库（magisk/zygisk/lsposed/riru/frida）
    _inj=$(/system/bin/grep -icE "magisk|zygisk|lsposed|riru|frida|xposed" "$_mp" 2>/dev/null)
    _inj=${_inj:-0}
    if [ "$_inj" -gt 0 ]; then
        agd_add "$_g" "mp_inject" "注入库" "FAIL" "APP 内存中发现 $_inj 条注入模块映射" 1 "app"
        _smp=$(/system/bin/grep -iE "magisk|zygisk|lsposed|riru|frida|xposed" "$_mp" 2>/dev/null \
               | awk '{print $NF}' | sort -u | head -n4 | tr '\n' ' ')
        [ -n "$_smp" ] && agd_add "$_g" "mp_inject_s" "注入来源" "FAIL" "$_smp" 1 "app"
    else
        agd_add "$_g" "mp_inject" "注入库" "OK" "APP 内存中无 magisk/zygisk/xposed/frida 映射" 1 "app"
    fi

    # 2) 非系统路径的可执行映射（dirty 注入）
    _anon_exec=$(/system/bin/grep -cE "^[0-9a-f]+-[0-9a-f]+ r-xp 00000000 00:00" "$_mp" 2>/dev/null)
    _anon_exec=${_anon_exec:-0}
    agd_add "$_g" "mp_anon" "匿名可执行段" "$([ "$_anon_exec" -gt 0 ] && echo WARN || echo OK)" \
        "$_anon_exec 条（JIT/ART 常见，过多需关注）" 0 "app"

    # 3) 游戏自身 APK/库是否正常加载
    _own=$(/system/bin/grep -c "$PKG" "$_mp" 2>/dev/null)
    _own=${_own:-0}
    agd_add "$_g" "mp_own" "游戏自身库" "OK" "$_own 条映射来自 $PKG" 0 "app"
}

# ============================================================
#  四、APP 视角的文件可见性（沙盒内能否看到 Root 痕迹）
# ============================================================
agd_group_visibility() {
    _g="沙盒可见性"

    if [ -z "$AGD_PID" ]; then
        agd_add "$_g" "vs_na" "可见性" "SKIP" "目标未运行，无法采样" 0 "app"
        return 0
    fi

    # ---- 第 1 层：挂载可见性（mnt namespace 内的文件系统视图）----
    _nv=$(/system/bin/toybox nsenter -t "$AGD_PID" -m -- /system/bin/sh -c 'ls /data/adb 2>&1' </dev/null 2>&1)
    _nv_cnt=$(printf '%s' "$_nv" | wc -l)
    case "$_nv" in
        *"Permission denied"*|*"No such file"*)
            agd_add "$_g" "vs_mnt" "挂载可见性" "OK" "/data/adb 在 APP 挂载命名空间中不存在或被拒" 1 "app" ;;
        *)
            agd_add "$_g" "vs_mnt" "挂载可见性" "WARN" "/data/adb 在 APP 挂载视图中可见（$_nv_cnt 项）· 属挂载层暴露" 1 "app" ;;
    esac

    # ---- 第 2 层：SELinux 可达性（该域能否真读）----
    # /data/adb 的标签
    _lbl=$(ls -Zd /data/adb 2>/dev/null | awk '{print $1}')
    agd_add "$_g" "vs_label" "/data/adb 标签" "INFO" "${_lbl:-未知}" 0 "app"

    # untrusted_app 域对该类型是否有 allow 规则：
    # 用目标域的 sepolicy 查询不可行，改用「标签类型是否属 app 可读类型」推断
    case "$_lbl" in
        *adb_data_file*|*magisk_file*|*ksu_file*)
            agd_add "$_g" "vs_selinux" "SELinux 拦截" "OK" "标签 ${_lbl} 不被 untrusted_app 域默认可读 → 实际访问会被拒" 1 "app" ;;
        *)
            agd_add "$_g" "vs_selinux" "SELinux 拦截" "WARN" "标签 ${_lbl} 可能被 APP 域读到，需进一步确认" 1 "app" ;;
    esac

    # ---- 综合判定 ----
    case "$_nv" in
        *"Permission denied"*|*"No such file"*)
            _verdict="未暴露"
            _vstate="OK" ;;
        *)
            case "$_lbl" in
                *adb_data_file*|*magisk_file*|*ksu_file*)
                    _verdict="挂载可见但 SELinux 拦截，属低风险（ACE 类工具通常只做挂载扫描，可能命中）"
                    _vstate="WARN" ;;
                *)
                    _verdict="挂载可见且可能被读取，高风险"
                    _vstate="FAIL" ;;
            esac ;;
    esac
    agd_add "$_g" "vs_verdict" "综合结论" "$_vstate" "$_verdict" 1 "app"

    # ---- su 二进制 ----
    _su_vis=""
    for p in /system/bin/su /system/xbin/su /sbin/su /debug_ramdisk/su; do
        if /system/bin/toybox nsenter -t "$AGD_PID" -m -- /system/bin/sh -c "test -e '$p'" </dev/null >/dev/null 2>&1; then
            _su_vis="$_su_vis $p"
        fi
    done
    if [ -n "$_su_vis" ]; then
        agd_add "$_g" "vs_su" "su 二进制" "WARN" "挂载视图可见：$_su_vis（SELinux 未拦时可执行）" 1 "app"
    else
        agd_add "$_g" "vs_su" "su 二进制" "OK" "APP 挂载视图中不存在" 1 "app"
    fi

    # ---- 模块目录 ----
    _m=$(/system/bin/toybox nsenter -t "$AGD_PID" -m -- /system/bin/sh -c 'ls /data/adb/modules 2>&1' </dev/null 2>&1)
    case "$_m" in
        *"Permission denied"*|*"No such"*)
            agd_add "$_g" "vs_mods" "模块目录" "OK" "APP 视图不可见" 1 "app" ;;
        *)
            _n=$(printf '%s' "$_m" | /system/bin/grep -c .)
            agd_add "$_g" "vs_mods" "模块目录" "WARN" "APP 挂载视图可见 $_n 个模块名" 1 "app" ;;
    esac

    # ---- 更可靠的一层：目标进程 maps 里是否真引用过 /data/adb ----
    _open=$(/system/bin/grep -c "/data/adb" "/proc/$AGD_PID/maps" 2>/dev/null)
    _open=${_open:-0}
    if [ "$_open" -gt 0 ]; then
        agd_add "$_g" "vs_open" "实际访问痕迹" "FAIL" "游戏内存映射中引用 /data/adb $_open 次（说明真的读到了）" 1 "app"
    else
        agd_add "$_g" "vs_open" "实际访问痕迹" "OK" "游戏内存映射未引用 /data/adb" 1 "app"
    fi
}

# ============================================================
#  五、硬件/系统属性一致性（APP 从 getprop 拿到的值）
# ============================================================
agd_group_hwprops() {
    _g="属性一致性"

    # 这些是 APP 通过 SystemProperties 能读到的
    _s1=$(/system/bin/getprop ro.serialno 2>/dev/null)
    _s2=$(/system/bin/getprop ro.boot.serialno 2>/dev/null)
    if [ "$_s1" = "$_s2" ]; then
        agd_add "$_g" "hw_serial" "序列号一致性" "OK" "ro.serialno 与 ro.boot.serialno 相同" 1 "app"
    else
        agd_add "$_g" "hw_serial" "序列号一致性" "FAIL" "两路不一致：$_s1 / $_s2（ACE 会交叉比对）" 1 "app"
    fi

    # 构建指纹里是否内嵌了当前序列号（伪装的破绽）
    _fp=$(/system/bin/getprop ro.build.fingerprint 2>/dev/null)
    case "$_fp" in
        *"$_s1"*)
            agd_add "$_g" "hw_fp" "构建指纹" "FAIL" "fingerprint 内嵌了当前序列号，易被识别" 1 "app" ;;
        *)
            agd_add "$_g" "hw_fp" "构建指纹" "OK" "未发现异常内嵌" 0 "app" ;;
    esac

    # 品牌/型号/设备代号 内部一致性
    _brand=$(/system/bin/getprop ro.product.brand 2>/dev/null)
    _model=$(/system/bin/getprop ro.product.model 2>/dev/null)
    _dev=$(/system/bin/getprop ro.product.device 2>/dev/null)
    agd_add "$_g" "hw_model" "品牌型号" "INFO" "brand=$_brand model=$_model device=$_dev" 0 "app"

    # 平台
    _hw=$(/system/bin/getprop ro.hardware 2>/dev/null)
    _soc=$(/system/bin/getprop ro.soc.manufacturer 2>/dev/null)
    agd_add "$_g" "hw_soc" "SoC 平台" "INFO" "hardware=$_hw soc=${_soc:-未知}" 0 "app"

    # Bootloader（APP 可读）
    _bl=$(/system/bin/getprop ro.boot.verifiedbootstate 2>/dev/null)
    _lk=$(/system/bin/getprop ro.boot.flash.locked 2>/dev/null)
    if [ "$_bl" = "green" ] && [ "$_lk" = "1" ]; then
        agd_add "$_g" "hw_bl" "Bootloader" "OK" "verifiedbootstate=green 且 flash 已锁" 1 "app"
    else
        agd_add "$_g" "hw_bl" "Bootloader" "WARN" "verifiedbootstate=${_bl:-未知} locked=${_lk:-未知}" 1 "app"
    fi

    # selinux 运行态
    _se=$(/system/bin/getenforce 2>/dev/null)
    _se_l=$(printf '%s' "$_se" | tr 'A-Z' 'a-z')
    agd_add "$_g" "hw_se" "SELinux" "$([ "$_se_l" = "enforcing" ] && echo OK || echo WARN)" "${_se:-未知}" 0 "app"

    # 模拟器特征
    _emu=0
    /system/bin/getprop ro.kernel.qemu 2>/dev/null | /system/bin/grep -q "1" && _emu=$((_emu+1))
    /system/bin/getprop ro.hardware 2>/dev/null | /system/bin/grep -qiE "goldfish|ranchu|qemu" && _emu=$((_emu+1))
    /system/bin/getprop ro.product.model 2>/dev/null | /system/bin/grep -qiE "sdk|emulator|generic" && _emu=$((_emu+1))
    agd_add "$_g" "hw_emu" "模拟器特征" "$([ "$_emu" -gt 0 ] && echo FAIL || echo OK)" "命中 $_emu 项" 1 "app"
}

# ============================================================
#  模块自检（合并为单一分组，只看是否正常运行）
# ============================================================
AG_MOD_GROUP="模块自检"

agd_module() {
    # ---- 1) 主服务与子进程 ----
    _ps=$(/system/bin/toybox ps -A -o PID,ARGS 2>/dev/null)

    _chk_proc() {  # $1=匹配串 $2=中文名 $3=作用
        _line=$(printf '%s' "$_ps" | /system/bin/grep -F "$1" | /system/bin/grep -v grep | head -n1)
        if [ -n "$_line" ]; then
            _pid=$(printf '%s' "$_line" | awk '{print $1}')
            agd_add "$AG_MOD_GROUP" "m_$1" "$2" "OK" "PID $_pid · $3" 1 "module"
        else
            agd_add "$AG_MOD_GROUP" "m_$1" "$2" "FAIL" "未运行 · $3" 1 "module"
        fi
    }

    _chk_proc "service.sh"           "主服务"     "调度全部子系统"
    _chk_proc "ag_shadow_lifecycle"  "遮蔽生命周期" "游戏运行时挂载"
    _chk_proc "ag_guard_inside"      "守护反制"   "清理举报缓存"
    _chk_proc "ag_housekeeping_loop" "后台维护"   "反探测与反调试"
    _chk_proc "ag_prop_daemon.sh"    "卡片守护"   "同步 KSU 卡片"

    # ---- 2) 授权 ----
    ag_auth_validate_silent 2>/dev/null
    if [ "${AG_AUTH_OK:-0}" = "1" ]; then
        agd_add "$AG_MOD_GROUP" "m_auth" "授权状态" "OK" "$(ag_auth_plan_text)" 1 "module"
    else
        agd_add "$AG_MOD_GROUP" "m_auth" "授权状态" "FAIL" "${AG_AUTH_REASON:-未授权}" 1 "module"
    fi

    # ---- 3) 指纹是否已生效 ----
    if [ "${ENABLE_IDENTITY:-1}" = "1" ] && ag_identity_load 2>/dev/null; then
        _cur_s=$(/system/bin/getprop ro.serialno 2>/dev/null)
        if [ "$_cur_s" = "$AG_SERIAL" ]; then
            agd_add "$AG_MOD_GROUP" "m_fp" "指纹已生效" "OK" "SERIAL=$_cur_s" 1 "module"
        else
            agd_add "$AG_MOD_GROUP" "m_fp" "指纹已生效" "FAIL" "未生效 当前=$_cur_s" 1 "module"
        fi
    else
        agd_add "$AG_MOD_GROUP" "m_fp" "指纹已生效" "SKIP" "指纹功能已关闭" 0 "module"
    fi

    # ---- 4) 遮蔽挂载（游戏运行时才挂） ----
    if [ "${ENABLE_SHADOW:-1}" = "1" ]; then
        _base=$(ag_find_game_dir 2>/dev/null)
        _mnt=$(/system/bin/toybox mount 2>/dev/null | /system/bin/grep -c "$PKG")
        _mnt=${_mnt:-0}
        _gpid=$(ag_find_game_pid 2>/dev/null)
        if [ -n "$_gpid" ]; then
            if [ "$_mnt" -gt 0 ]; then
                agd_add "$AG_MOD_GROUP" "m_shadow" "遮蔽挂载" "OK" "游戏运行中 · 已挂 $_mnt 条" 1 "module"
            else
                agd_add "$AG_MOD_GROUP" "m_shadow" "遮蔽挂载" "FAIL" "游戏运行中但无挂载" 1 "module"
            fi
        else
            agd_add "$AG_MOD_GROUP" "m_shadow" "遮蔽挂载" "OK" "游戏未运行 · 待机 $_mnt 条" 0 "module"
        fi
    else
        agd_add "$AG_MOD_GROUP" "m_shadow" "遮蔽挂载" "SKIP" "功能已关闭" 0 "module"
    fi

    # ---- 5) 运行依赖 ----
    _miss=""
    for d in /data/adb/ksu/bin/resetprop /system/bin/getprop /system/bin/toybox; do
        [ -x "$d" ] || _miss="$_miss ${d##*/}"
    done
    if [ -z "$_miss" ]; then
        agd_add "$AG_MOD_GROUP" "m_deps" "运行依赖" "OK" "resetprop/getprop/toybox 齐全" 1 "module"
    else
        agd_add "$AG_MOD_GROUP" "m_deps" "运行依赖" "FAIL" "缺失:$_miss" 1 "module"
    fi

    # ---- 6) 探针 APK ----
    if [ -f "$MODDIR/script/probe.sh" ]; then
        _pst=$(/system/bin/sh "$MODDIR/script/probe.sh" status 2>/dev/null | head -n1)
        if [ "$_pst" = "installed" ]; then
            agd_add "$AG_MOD_GROUP" "m_probe" "探针 APK" "OK" "已安装" 0 "module"
        else
            agd_add "$AG_MOD_GROUP" "m_probe" "探针 APK" "WARN" "未安装，环境检测将不可用" 1 "module"
        fi
    fi
}

# ============================================================
#  入口
# ============================================================
ag_diag_all() {
    # ---- 1) 优先：APK 探针（普通应用身份实测）----
    # probe.sh items 直接返回纯 JSON 数组内容
    _probe_arr=""
    if [ -f "$MODDIR/script/probe.sh" ]; then
        _pst=$(/system/bin/sh "$MODDIR/script/probe.sh" status 2>/dev/null | head -n1)
        if [ "$_pst" = "installed" ]; then
            _probe_arr=$(/system/bin/sh "$MODDIR/script/probe.sh" items 2>/dev/null)
        fi
    fi

    agd_begin

    # 探针结果直接作为数组前段
    case "$_probe_arr" in
        *'"group"'*)
            AG_DIAG_JSON="$_probe_arr"
            AG_DIAG_FIRST=0 ;;
    esac

    # ---- 属性对比（APP 视角实测值 vs 真机/伪装基准）----
    _diff_arr=$(ag_diff_props_items "$_probe_arr" 2>/dev/null)
    case "$_diff_arr" in
        *'"group"'*)
            if [ "$AG_DIAG_FIRST" = "1" ]; then
                AG_DIAG_JSON="$_diff_arr"
                AG_DIAG_FIRST=0
            else
                AG_DIAG_JSON="$AG_DIAG_JSON,$_diff_arr"
            fi ;;
    esac

    # 探针不可用时才用 root 推断兜底
    if [ "$AG_DIAG_FIRST" = "1" ]; then
        agd_find_target
        agd_group_context
        agd_group_mountview
        agd_group_procattr
        agd_group_maps
        agd_group_visibility
    fi

    agd_end
}
