#!/system/bin/sh

# >>> AG-AUTH-GUARD >>>
# 授权闸门（性能优化版）
#   1) 同进程内复用：_AG_AUTH_GUARDED=1 直接跳过
#   2) 跨进程复用：60 秒内通过的标记文件，避免每次 source 都跑 sha256
#   3) 缓存失效才真正校验
if [ "${_AG_AUTH_GUARDED:-0}" != "1" ]; then
    _ag_gcache="/data/adb/ace_guard/auth/.guardok"
    _ag_gok=0
    if [ -f "$_ag_gcache" ]; then
        _ag_gt=$(cat "$_ag_gcache" 2>/dev/null)
        _ag_now=$(/system/bin/date +%s)
        # 60 秒内的标记视为有效
        case "$_ag_gt" in
            ''|*[!0-9]*) : ;;
            *) [ $(( _ag_now - _ag_gt )) -lt 60 ] && _ag_gok=1 ;;
        esac
    fi
    if [ "$_ag_gok" != "1" ]; then
        if [ -f "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh" ]; then
            . "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh"
            if ! ag_auth_guard "${0##*/}" 2>/dev/null; then
                echo "此设备未授权，功能已冻结" >&2
                exit 1
            fi
            /system/bin/date +%s > "$_ag_gcache" 2>/dev/null
        fi
    fi
fi
_AG_AUTH_GUARDED=1
# <<< AG-AUTH-GUARD <<<

# ============================================================
#  ACE Guard —— 设备身份（指纹 + Android ID 一体）
#
#  v1.9.0 起 ADID 不再单列：SERIAL / IMEI / CHIPECID / ADID
#  同属「设备身份证明」，统一在 data/identity 落盘、统一轮换、
#  统一展示、统一自检。原 data/adid 与 data/original_adid 会被
#  自动迁移（见 ag_identity_migrate_legacy）。
#
#  背景：
#    ADID 存放在各用户的 settings secure 库，
#    即 /data/system/users/<uid>/settings_secure.xml，
#    每个用户空间（user0 / user11 / user999 ...）各一份，互相独立。
#    读取入口：Settings.Secure.getString(cr, "android_id")
#             -> SettingsProvider GET_secure -> 内存缓存 -> XML
#
#  策略（与属性指纹一致）：
#    生成一次后固定保存，不随开机轮换；
#    仅由 Action / WebUI / 命令行显式触发时才换新值。
# ============================================================

AG_IDENTITY_FILE="$DATA_DIR/identity"
AG_IDENTITY_TMP="$DATA_DIR/.identity.$$"
# 原始 ADID 备份（首次修改前保存，卸载时恢复）
AG_ADID_ORIG="${AG_ADID_ORIG:-$DATA_DIR/original_adid}"
# 旧版单列落盘文件（自动迁移后删除）
AG_ADID_LEGACY="$DATA_DIR/adid"

# 内存中的身份（全局，与 AG_SERIAL 等同级）
AG_SERIAL=""
AG_IMEI=""
AG_CHIPECID=""
AG_ADID=""
# ADID 只对「当前用户」有意义：属性类指纹是全局的，ADID 是每用户一份。
# 下面三者为最近一次 ag_adid_apply 的生效结果，供上层展示。
AG_ADID_USER=""
AG_ADID_ACTIVE_USERS=""
# 归属用户：身份文件里记录的 ADID 只取这个用户的那一份（默认 user0）。
# 分身/工作空间 (user999 / user10) 的 ADID 各自独立写，不参与落盘。
PRIMARY_USER="${AG_PRIMARY_USER:-0}"

# ============================================================
#  一、基础生成器 / 校验器
# ============================================================

# ---------- 生成 16 位小写 hex（Android 真实 ADID 格式）----------
ag_gen_adid() {
    local v
    v=$(/system/bin/toybox od -An -N8 -tx1 /dev/urandom 2>/dev/null | /system/bin/toybox tr -d ' \r\n')
    printf '%s' "$v"
}

# ---------- 校验 16 位小写 hex ----------
ag_valid_adid() {
    printf '%s\n' "$1" | /system/bin/grep -Eq '^[0-9a-f]{16}$'
}

# ---------- 枚举设备上所有 Android 用户 ----------
ag_list_users() {
    local d u
    for d in /data/system/users/[0-9]*; do
        [ -d "$d" ] || continue
        u="${d##*/}"
        case "$u" in
            ''|*[!0-9]*) continue ;;
        esac
        echo "$u"
    done
}

# ---------- 读取某用户当前 ADID ----------
ag_adid_get() {
    /system/bin/settings --user "$1" get secure android_id 2>/dev/null
}

# ---------- 判断用户是否为活动状态 ----------
# 非活动用户（未被启动过的分身/工作空间）无法通过 settings 访问，
# 这不是错误，而是正常情况，应跳过并记录。
ag_user_active() {
    local u="$1"
    /system/bin/settings --user "$u" get secure android_id >/dev/null 2>&1 && return 0
    /system/bin/settings --user "$u" list secure 2>/dev/null | grep -q "android_id" && return 0
    /system/bin/pm list users 2>/dev/null | grep -q "UserInfo{$u:" && \
        /system/bin/pm list users 2>/dev/null | grep "UserInfo{$u:" | grep -q "running" && return 0
    return 1
}

# ---------- 备份某用户的原始 ADID（只在首次备份，绝不覆盖）----------
ag_adid_backup_orig() {
    local u="$1" cur
    [ -n "$u" ] || return 1
    [ -r "$AG_ADID_ORIG" ] && grep -q "^${u}=" "$AG_ADID_ORIG" 2>/dev/null && return 0
    cur=$(ag_adid_get "$u")
    case "$cur" in
        ''|*[!0-9a-f]*) return 1 ;;
    esac
    [ ${#cur} -eq 16 ] || return 1
    mkdir -p "$DATA_DIR" 2>/dev/null
    printf '%s=%s\n' "$u" "$cur" >> "$AG_ADID_ORIG" 2>/dev/null
    chmod 600 "$AG_ADID_ORIG" 2>/dev/null
    command -v ag_log >/dev/null 2>&1 && \
        ag_log INFO "  [ADID] 已备份 user$u 原始值 $cur"
    return 0
}

# ---------- 恢复某用户的原始 ADID ----------
ag_adid_restore_orig() {
    local u="$1" v
    [ -r "$AG_ADID_ORIG" ] || return 1
    v=$(grep "^${u}=" "$AG_ADID_ORIG" 2>/dev/null | head -n1 | cut -d= -f2)
    [ -n "$v" ] || return 1
    ag_adid_set "$u" "$v"
    return 0
}

# ---------- 写入某用户 ADID ----------
ag_adid_set() {
    /system/bin/settings --user "$1" put secure android_id "$2" >/dev/null 2>&1
}

# ============================================================
#  二、身份持久化（SERIAL / IMEI / CHIPECID / ADID 同一文件）
# ============================================================

# 从 identity 文件读取指定 key（兼容旧格式）
ag_identity_get_kv() {
    local want="$1" k v
    [ -r "$AG_IDENTITY_FILE" ] || return 1
    while IFS='=' read -r k v; do
        v=$(printf '%s' "$v" | /system/bin/toybox tr -d '\r\n')
        [ "$k" = "$want" ] && { printf '%s' "$v"; return 0; }
    done < "$AG_IDENTITY_FILE"
    return 1
}

# 兼容旧函数名：从保存文件读取某用户的已存 ADID
# 旧版用 data/adid 每行 "用户号=ADID"；新版只保留当前用户的一份 ADID
ag_adid_load_for() {
    local u="$1" v
    v=$(ag_identity_get_kv ADID 2>/dev/null)
    if [ -n "$v" ] && ag_valid_adid "$v"; then
        # 旧版未记录用户号时，按调用方传入的用户判定归属
        local su
        su=$(ag_identity_get_kv ADID_USER 2>/dev/null)
        [ -z "$su" ] || [ "$su" = "$u" ] || return 1
        printf '%s' "$v"
        return 0
    fi
    return 1
}

# 保存某用户的 ADID 到统一身份文件
ag_adid_save_for() {
    local u="$1" v="$2"
    AG_ADID="$v"
    AG_ADID_USER="$u"
    ag_identity_save
}

# ---------- 加载身份 ----------
ag_identity_load() {
    AG_SERIAL=""; AG_IMEI=""; AG_CHIPECID=""; AG_ADID=""; AG_ADID_USER=""
    [ -r "$AG_IDENTITY_FILE" ] || return 1
    local k v
    while IFS='=' read -r k v; do
        v=$(printf '%s' "$v" | /system/bin/toybox tr -d '\r\n')
        case "$k" in
            SERIAL)    AG_SERIAL="$v" ;;
            IMEI)      AG_IMEI="$v" ;;
            CHIPECID)  AG_CHIPECID="$v" ;;
            ADID)      AG_ADID="$v" ;;
            ADID_USER) AG_ADID_USER="$v" ;;
        esac
    done < "$AG_IDENTITY_FILE"
    [ -n "$AG_SERIAL" ] && [ -n "$AG_IMEI" ] && [ -n "$AG_CHIPECID" ]
}

# ---------- 保存身份（四项一体，保持旧格式兼容）----------
ag_identity_save() {
    local tmp="$AG_IDENTITY_TMP"
    local adid_user="${AG_ADID_USER:-0}"
    case "$adid_user" in ''|*[!0-9]*) adid_user=0 ;; esac
    ( umask 077
      printf 'SERIAL=%s\nIMEI=%s\nCHIPECID=%s\nADID=%s\nADID_USER=%s\n' \
          "$AG_SERIAL" "$AG_IMEI" "$AG_CHIPECID" "$AG_ADID" "$adid_user" > "$tmp" ) || return 1
    /system/bin/chmod 0600 "$tmp" 2>/dev/null
    /system/bin/toybox mv -f "$tmp" "$AG_IDENTITY_FILE"
}

# ---------- 旧数据迁移：data/adid -> identity ADID ----------
# 幂等；迁移完成后把旧文件改名为 .migrated 保留，不直接删除。
# 注意：必须先把 identity 里已有的 SERIAL/IMEI/CHIPECID 读进内存，
#       否则 ag_identity_save 会把内存里的空值写回去（v1.9.0 修复项）。
ag_identity_migrate_legacy() {
    [ -f "$AG_ADID_LEGACY" ] || return 0
    ag_identity_load >/dev/null 2>&1
    local cur0 saved
    saved=$(grep "^0=" "$AG_ADID_LEGACY" 2>/dev/null | head -n1 | cut -d= -f2)
    [ -n "$saved" ] || saved=$(head -n1 "$AG_ADID_LEGACY" 2>/dev/null | cut -d= -f2)
    cur0=$(ag_adid_get 0)
    local v=""
    ag_valid_adid "$cur0" && v="$cur0"
    [ -z "$v" ] && ag_valid_adid "$saved" && v="$saved"
    if [ -n "$v" ]; then
        AG_ADID="$v"; AG_ADID_USER=0
        ag_identity_save >/dev/null 2>&1
        command -v ag_log >/dev/null 2>&1 && \
            ag_log INFO "  [ADID] 旧数据已并入 identity：$v"
    fi
    /system/bin/toybox mv -f "$AG_ADID_LEGACY" "$AG_ADID_LEGACY.migrated" 2>/dev/null
    return 0
}

# ============================================================
#  三、属性指纹生成 / 校验 / 轮换（原有实现）
# ============================================================

ag_identity_generate() {
    ag_identity_load && [ "$ROTATE_ON_BOOT" = "0" ] && return 0
    AG_SERIAL=$(ag_gen_serial "$SERIAL_MODE") || return 1
    ag_valid_serial "$AG_SERIAL" || return 1
    AG_IMEI=$(ag_gen_imei "${IMEI_PREFIX:-86916}") || return 1
    AG_CHIPECID=$(ag_gen_chipecid "$CHIPECID_LEN") || return 1
    ag_valid_chipecid "$AG_CHIPECID" "$CHIPECID_LEN" || return 1
    ag_identity_save || return 1
    ag_log INFO "指纹已生成 SERIAL=$AG_SERIAL CHIPECID=$AG_CHIPECID"
}

# 确保已有一组合法值；不合法则重生成
ag_identity_ensure() {
    ag_identity_migrate_legacy
    ag_identity_load || { ag_identity_generate; return $?; }
    local bad=0
    ag_valid_serial "$AG_SERIAL" || bad=1
    ag_valid_imei "$AG_IMEI" || bad=1
    ag_valid_chipecid "$AG_CHIPECID" "$CHIPECID_LEN" || bad=1
    if [ "$bad" = "1" ]; then
        ag_log WARN "已有指纹不合法，重新生成"
        ag_identity_generate
    fi
    return 0
}

# ---------- 属性指纹轮换（只动 SERIAL/IMEI/CHIPECID）----------
ag_identity_rotate() {
    local os="" oi="" oc=""
    ag_identity_load
    os="$AG_SERIAL"; oi="$AG_IMEI"; oc="$AG_CHIPECID"

    # 真机原始值（首次安装快照），用于日志溯源
    local rs="" ri="" rc=""
    local snap="/data/adb/ace_guard/auth/original_identity"
    if [ -f "$snap" ]; then
        rs=$(sed -n 's/^REAL_SERIAL=//p'   "$snap" 2>/dev/null)
        ri=$(sed -n 's/^REAL_IMEI=//p'     "$snap" 2>/dev/null)
        rc=$(sed -n 's/^REAL_CHIPECID=//p' "$snap" 2>/dev/null)
    fi

    local t=0
    while [ $t -lt 10 ]; do
        AG_SERIAL=$(ag_gen_serial "$SERIAL_MODE")
        ag_valid_serial "$AG_SERIAL" && [ "$AG_SERIAL" != "$os" ] && break
        t=$((t + 1))
    done
    t=0
    while [ $t -lt 10 ]; do
        AG_IMEI=$(ag_gen_imei "${IMEI_PREFIX:-86916}")
        [ "$AG_IMEI" != "$oi" ] && break
        t=$((t + 1))
    done
    t=0
    while [ $t -lt 10 ]; do
        AG_CHIPECID=$(ag_gen_chipecid "$CHIPECID_LEN")
        [ "$AG_CHIPECID" != "$oc" ] && break
        t=$((t + 1))
    done
    ag_identity_save || return 1

    # 三段式溯源日志：真机 -> 旧伪装 -> 新伪装
    ag_log INFO "========== 指纹轮换 =========="
    ag_log INFO "  [SERIAL]   真机 ${rs:-无快照}  ->  旧伪装 ${os:-无}  ->  新伪装 $AG_SERIAL"
    ag_log INFO "  [IMEI]     真机 ${ri:-无快照}  ->  旧伪装 ${oi:-无}  ->  新伪装 $AG_IMEI"
    ag_log INFO "  [CHIPECID] 真机 ${rc:-无快照}  ->  旧伪装 ${oc:-无}  ->  新伪装 $AG_CHIPECID"
    ag_log INFO "  设备码: $(ag_auth_device_id 2>/dev/null)"
    ag_log INFO "=============================="
    return 0
}

# ---------- 应用属性指纹（带逐属性变更日志）----------
ag_identity_apply() {
    [ "$ENABLE_IDENTITY" = "1" ] || return 0
    ag_identity_load || return 1
    ag_find_resetprop || { ag_log ERROR "resetprop 不可用"; return 1; }

    local n=0 fail=0 before after key val

    # 真机值对照（首次安装快照）
    local _snap="/data/adb/ace_guard/auth/original_identity"
    if [ -f "$_snap" ]; then
        ag_log INFO "  [真机] SERIAL=$(sed -n 's/^REAL_SERIAL=//p' "$_snap" 2>/dev/null) IMEI=$(sed -n 's/^REAL_IMEI=//p' "$_snap" 2>/dev/null)"
    fi
    ag_log INFO "---------- 指纹应用开始 ----------"

    # 写入单个属性并记录变更
    # $1=属性名 $2=目标值 $3=分类标签
    ag_setprop_logged() {
        key="$1"; val="$2"
        before=$(/system/bin/getprop "$key" 2>/dev/null)

        # 方案C 保护：属性从未存在时禁止创建。
        # 创建新属性会让 prop_area 的 bytes_used 增长且永不回收，
        # 形成"属性区空洞"，被检测工具判定为属性被动态修改过。
        if [ -z "$before" ] && ! /system/bin/getprop 2>/dev/null | /system/bin/grep -q "\[$key\]"; then
            ag_log WARN "  [$3] $key : 属性不存在，跳过（避免属性区空洞）"
            return 0
        fi

        [ -z "$before" ] && before="（空值）"

        if "$RESETPROP" "$key" "$val" >/dev/null 2>&1; then
            n=$((n + 1))
            after=$(/system/bin/getprop "$key" 2>/dev/null)
            if [ "$before" = "$after" ]; then
                ag_log INFO "  [$3] $key : $before （未变）"
            else
                ag_log INFO "  [$3] $key : $before  ->  $after"
            fi
        else
            fail=$((fail + 1))
            ag_log ERROR "  [$3] $key : 写入失败（原值=$before）"
        fi
    }

    # --- 序列号 ---
    # v1.9.6 恢复：游戏会通过系统接口（Build.getSerial / Settings 等）
    # 读序列号，这些接口在系统进程域执行，能读到 ro.serialno /
    # ro.boot.serialno，因此两个属性都必须纳入身份指纹覆盖。
    ag_setprop_logged "ro.serialno"      "$AG_SERIAL" "序列号"
    ag_setprop_logged "ro.boot.serialno" "$AG_SERIAL" "序列号"
    # 厂商冗余序列号（默认属性值会暴露真机身份，一并覆盖）
    for p in $SERIAL_PROPS; do
        [ -n "$p" ] || continue
        ag_setprop_logged "$p" "$AG_SERIAL" "序列号(厂商)"
    done

    # --- GSM 基带序列号（21 位混合串，格式与普通序列号不同，独立生成）---
    # v1.9.4 修复：vendor.gsm.serial 此前漏覆盖，泄露真机基带序列号。
    local _gsm
    _gsm=$(ag_gen_gsmserial 2>/dev/null)
    if ag_valid_gsmserial "$_gsm"; then
        for p in $GSMSERIAL_PROPS; do
            [ -n "$p" ] || continue
            ag_setprop_logged "$p" "$_gsm" "GSM序列号"
        done
    else
        ag_log WARN "  GSM序列号生成失败，跳过该组覆盖"
    fi

    # --- 芯片 ID ---
    ag_setprop_logged "ro.boot.chipecid" "$AG_CHIPECID" "芯片ID"
    # ro.boot.chipid 是 chipecid 的后 8 位（真机 dbc0b43f = 0000047bdbc0b43f 后8位），
    # v1.9.6 补：此属性此前漏覆盖，泄露原始芯片 ID 后 8 位，必须与 chipecid 保持一致。
    local _chipid8
    _chipid8=$(printf '%s' "$AG_CHIPECID" | /system/bin/cut -c9-16 2>/dev/null)
    [ -n "$_chipid8" ] && ag_setprop_logged "ro.boot.chipid" "$_chipid8" "芯片ID(短)"

    # --- IMEI 组 ---
    local p
    for p in $IMEI_PROPS; do
        [ -n "$p" ] || continue
        ag_setprop_logged "$p" "$AG_IMEI" "IMEI"
    done

    # 兼容：系统里若已存在其它含 imei 的属性，一并覆盖
    #
    # 方案C（v1.7.1）：收窄补充范围。
    #   - 跳过 ro.* 前缀：构建期只读属性，改写仅内存生效，
    #     检测工具通常不读取，写它只会扩大属性写入面。
    #   - 跳过 persist.* 中未在 IMEI_PROPS 白名单里的项。
    #   - 只补写运行时属性（ril.* / gsm.* 等）。
    local extra
    extra=$(/system/bin/getprop 2>/dev/null | /system/bin/grep -i imei \
            | /system/bin/sed -n 's/^\[\([^]]*\)\].*/\1/p')
    for p in $extra; do
        case " $IMEI_PROPS " in
            *" $p "*) continue ;;     # 已在主列表，前面已写
        esac
        case "$p" in
            ro.*)     continue ;;     # 构建期只读属性，跳过
            persist.*) continue ;;    # 持久化属性，只走白名单
            ctl.*)    continue ;;     # 控制块，禁止触碰
        esac
        ag_setprop_logged "$p" "$AG_IMEI" "IMEI补充"
    done

    ag_log INFO "---------- 指纹应用完成: 成功=$n 失败=$fail ----------"
    return 0
}

# ============================================================
#  四、ADID 应用（每用户一份，归属当前用户）
# ============================================================

# ---------- 应用：给所有用户写 ADID（不存在则生成）----------
# $1=keep 保留已存值（默认）  $2=rotate/random 强制换新
ag_adid_apply() {
    local mode="${1:-keep}"

    # 写入前先备份各用户原始 ADID（仅首次）
    local _u
    for _u in $(ag_list_users); do
        ag_user_active "$_u" 2>/dev/null && ag_adid_backup_orig "$_u"
    done
    local u cur saved newval acted=0 skipped=0
    local act_users="" primary_v="" primary_u=""

    ag_identity_load >/dev/null 2>&1
    saved=$(ag_identity_get_kv ADID 2>/dev/null)
    local saved_u
    saved_u=$(ag_identity_get_kv ADID_USER 2>/dev/null)
    case "$saved_u" in ''|*[!0-9]*) saved_u=0 ;; esac

    ag_log INFO "---------- ADID 应用开始（模式=$mode）----------"

    for u in $(ag_list_users); do
        # 非活动用户跳过（无法通过 settings 写入，属正常情况）
        if ! ag_user_active "$u"; then
            ag_log INFO "  [user$u] 跳过（用户未运行/未初始化）"
            skipped=$((skipped + 1))
            continue
        fi

        cur=$(ag_adid_get "$u")

        if [ "$mode" = "rotate" ] || [ "$mode" = "random" ]; then
            # 强制换新，且不能与旧值相同
            local t=0
            while [ $t -lt 10 ]; do
                newval=$(ag_gen_adid)
                ag_valid_adid "$newval" && [ "$newval" != "$cur" ] && break
                t=$((t + 1))
            done
        else
            # 保留模式：优先生效用户的已存值；其余用户沿用自己系统的现值。
            # v1.9.0 修复：以前是「谁最后被遍历到就存谁」，分身用户
            # (user999 等) 会覆盖主用户的记录，导致页面显示错乱。
            if [ "$u" = "$PRIMARY_USER" ] && [ -n "$saved" ] \
               && ag_valid_adid "$saved" ; then
                newval="$saved"
            elif [ -n "$cur" ] && ag_valid_adid "$cur"; then
                # 系统已有合法值，直接记录，不改动
                acted=$((acted + 1))
                act_users="${act_users}${act_users:+ }$u"
                [ "$u" = "$PRIMARY_USER" ] && { primary_u="$u"; primary_v="$cur"; }
                ag_log INFO "  [user$u] android_id : $cur （保持系统原值）"
                continue
            else
                newval=$(ag_gen_adid)
            fi
        fi

        ag_valid_adid "$newval" || {
            ag_log ERROR "  [user$u] 生成失败，跳过"
            continue
        }

        # 写入
        if ag_adid_set "$u" "$newval"; then
            acted=$((acted + 1))
            act_users="${act_users}${act_users:+ }$u"
            [ "$u" = "$PRIMARY_USER" ] && { primary_u="$u"; primary_v="$newval"; }
            if [ -z "$cur" ]; then
                ag_log INFO "  [user$u] android_id : （未设置）  ->  $newval"
            elif [ "$cur" = "$newval" ]; then
                ag_log INFO "  [user$u] android_id : $cur （未变）"
            else
                ag_log INFO "  [user$u] android_id : $cur  ->  $newval"
            fi
        else
            ag_log ERROR "  [user$u] android_id 写入失败（原值=$cur）"
        fi
    done

    # 记录本轮生效结果，供展示使用
    # v1.9.0：只把「归属用户」那份写进 identity，否则分身用户
    # (user999 / user10) 会反复覆盖主用户记录，页面显示来回跳。
    AG_ADID_ACTIVE_USERS="$act_users"
    if [ -n "$primary_v" ]; then
        AG_ADID="$primary_v"; AG_ADID_USER="$primary_u"
        ag_adid_save_for "$primary_u" "$primary_v"
    elif [ -n "$saved" ] && ag_valid_adid "$saved"; then
        # 归属用户本轮未参与（未运行），保持原记录不动
        AG_ADID="$saved"; AG_ADID_USER="${saved_u:-$PRIMARY_USER}"
    fi

    ag_log INFO "---------- ADID 应用完成: 处理 $acted 个，跳过 $skipped 个 ----------"
    return 0
}

# ---------- 仅为已初始化用户确保 ADID（供 service 启动时轻量调用）----------
ag_adid_ensure() {
    local u cur saved nv
    ag_identity_load >/dev/null 2>&1
    saved=$(ag_identity_get_kv ADID 2>/dev/null)
    for u in $(ag_list_users); do
        ag_user_active "$u" || continue
        cur=$(ag_adid_get "$u")
        if [ -n "$cur" ] && ag_valid_adid "$cur"; then
            # 系统已有值：只在归属用户身上回填记录
            if [ "$u" = "$PRIMARY_USER" ] \
               && { [ -z "$saved" ] || ! ag_valid_adid "$saved"; }; then
                ag_adid_save_for "$u" "$cur"
            fi
            continue
        fi
        if [ -n "$saved" ] && ag_valid_adid "$saved"; then
            ag_adid_set "$u" "$saved" && ag_log INFO "ADID[user$u] 已恢复: $saved"
        else
            nv=$(ag_gen_adid)
            ag_valid_adid "$nv" || continue
            ag_adid_set "$u" "$nv" && ag_adid_save_for "$u" "$nv" \
                && ag_log INFO "ADID[user$u] 首次生成: $nv"
        fi
    done
    return 0
}

# ============================================================
#  五、统一入口（指纹 + ADID 一体）
# ============================================================

# 一键生成：属性指纹 + ADID（无值才生成）
ag_identity_init_all() {
    ag_identity_migrate_legacy
    ag_identity_ensure || return 1
    [ "$ENABLE_ADID" = "1" ] && ag_adid_ensure
    return 0
}

# 一键应用：写属性 + 写 ADID
# $1=keep|rotate|random
ag_identity_apply_all() {
    local mode="${1:-keep}"
    if [ "$ENABLE_IDENTITY" = "1" ]; then
        ag_identity_load
        ag_identity_apply
    fi
    if [ "$ENABLE_ADID" = "1" ]; then
        case "$mode" in
            rotate|random) ag_adid_apply "$mode" ;;
            *)             ag_adid_apply keep   ;;
        esac
    fi
    return 0
}

# 一键轮换：属性指纹 + ADID 同时换新（Action / WebUI 走这里）
ag_identity_rotate_all() {
    local os="" oi="" oc="" oa="" oau=""
    ag_identity_load >/dev/null 2>&1
    os="$AG_SERIAL"; oi="$AG_IMEI"; oc="$AG_CHIPECID"
    oa=$(ag_identity_get_kv ADID 2>/dev/null)
    oau=$(ag_identity_get_kv ADID_USER 2>/dev/null)

    ag_identity_rotate || return 1

    local newa=""
    if [ "$ENABLE_ADID" = "1" ]; then
        ag_adid_apply rotate
        newa=$(ag_adid_get "${oau:-0}" 2>/dev/null)
        [ -n "$newa" ] || newa="$AG_ADID"
        ag_log INFO "  [ADID]     旧伪装 ${oa:-无}  ->  新伪装 ${newa:-无}（user${oau:-0}）"
    fi
    ag_log INFO "  [身份] SERIAL=$AG_SERIAL CHIPECID=$AG_CHIPECID ADID=${newa:-$AG_ADID}"
    return 0
}

# ============================================================
#  六、展示 / 自检
# ============================================================

# ---------- 显示当前状态 ----------
ag_adid_show() {
    local u cur saved state
    echo "用户     当前 android_id      已存记录              状态"
    echo "-------  ------------------  --------------------  --------"
    saved=$(ag_identity_get_kv ADID 2>/dev/null)
    for u in $(ag_list_users); do
        cur=$(ag_adid_get "$u")
        [ -z "$cur" ] && cur="（未设置）"
        [ -z "$saved" ] && saved="（无）"
        if ag_user_active "$u"; then state="活动"; else state="未运行"; fi
        printf 'user%-4s  %-18s  %-20s  %s\n' "$u" "$cur" "$saved" "$state"
    done
}

# ---------- 身份一致性自检（属性 + ADID 同框判断）----------
# 输出：每个异常一行，正常时不输出
ag_identity_selftest() {
    local bad="" cur0 cur_a
    ag_identity_load >/dev/null 2>&1

    [ -n "$AG_SERIAL" ] || bad="$bad SERIAL:未生成"
    [ -n "$AG_IMEI" ]   || bad="$bad IMEI:未生成"

    cur0=$(/system/bin/getprop ro.serialno 2>/dev/null)
    [ "$cur0" = "$AG_SERIAL" ] || bad="$bad SERIAL:未生效($cur0)"

    if [ "$ENABLE_ADID" = "1" ]; then
        cur_a=$(ag_adid_get 0 2>/dev/null)
        if [ -z "$cur_a" ]; then
            bad="$bad ADID:未设置"
        elif [ -r "$AG_ADID_ORIG" ] && \
             [ "$cur_a" = "$(grep '^0=' "$AG_ADID_ORIG" 2>/dev/null | cut -d= -f2)" ]; then
            bad="$bad ADID:仍是原始值"
        fi
    fi
    [ -z "$bad" ] || printf '%s\n' "${bad# }"
    [ -z "$bad" ]
}

# ============================================================
#  七、身份属性清单（全量，供 WebUI 首页/授权页展示）
#
#  输出格式：每行「属性名<TAB>中文名<TAB>当前值<TAB>类别」
#  只列「实际会被覆盖」的身份属性，空值属性不列。
# ============================================================
ag_identity_prop_list() {
    _p1=""
    # 序列号类（SERIAL_PROPS 为用户可配置，逐个展开）
    _pv=$(_ag_getprop ro.serialno)
    [ -n "$_pv" ] && printf 'ro.serialno\t序列号\t%s\t序列号\n' "$_pv"
    _pv=$(_ag_getprop ro.boot.serialno)
    [ -n "$_pv" ] && printf 'ro.boot.serialno\t启动序列号\t%s\t序列号\n' "$_pv"
    for _p1 in $SERIAL_PROPS; do
        [ -n "$_p1" ] || continue
        _pv=$(_ag_getprop "$_p1")
        [ -n "$_pv" ] && printf '%s\t厂商序列号\t%s\t序列号\n' "$_p1" "$_pv"
    done

    # 芯片类
    _pv=$(_ag_getprop ro.boot.chipecid)
    [ -n "$_pv" ] && printf 'ro.boot.chipecid\t芯片ID\t%s\t芯片\n' "$_pv"
    _pv=$(_ag_getprop ro.boot.chipid)
    [ -n "$_pv" ] && printf 'ro.boot.chipid\t芯片ID(短)\t%s\t芯片\n' "$_pv"

    # IMEI 类
    for _p1 in $IMEI_PROPS; do
        [ -n "$_p1" ] || continue
        _pv=$(_ag_getprop "$_p1")
        [ -n "$_pv" ] && printf '%s\tIMEI\t%s\tIMEI\n' "$_p1" "$_pv"
    done

    # GSM 基带序列号
    for _p1 in $GSMSERIAL_PROPS; do
        [ -n "$_p1" ] || continue
        _pv=$(_ag_getprop "$_p1")
        [ -n "$_pv" ] && printf '%s\tGSM基带序列号\t%s\tGSM\n' "$_p1" "$_pv"
    done

    # ADID
    if [ "${ENABLE_ADID:-1}" = "1" ]; then
        _pv=$(ag_adid_get "${PRIMARY_USER:-0}" 2>/dev/null)
        [ -n "$_pv" ] && printf 'android_id\t安卓ID\t%s\tADID\n' "$_pv"
    fi
}

# 内部：读属性（隔离 getprop 路径）
_ag_getprop() {
    /system/bin/getprop "$1" 2>/dev/null
}

# 属性名 -> 中文名映射（供前端展示，未命中时返回属性名本身）
_ag_prop_cname() {
    case "$1" in
        ro.serialno)                     echo "序列号" ;;
        ro.boot.serialno)                echo "启动序列号" ;;
        ro.boot.chipecid)                echo "芯片ID" ;;
        ro.boot.chipid)                  echo "芯片ID(短)" ;;
        persist.radio.imei)              echo "IMEI 1" ;;
        persist.radio.imei1)             echo "IMEI 1" ;;
        persist.radio.imei2)             echo "IMEI 2" ;;
        persist.radio.imei9)             echo "IMEI 9" ;;
        vendor.gsm.serial)               echo "GSM基带序列号" ;;
        ro.vendor.gsm.serial)            echo "GSM基带序列号(ro)" ;;
        ro.vendor.oplus.radio.serialno)  echo "厂商序列号(radio)" ;;
        vendor.oplus.caihong.serialno)   echo "厂商序列号(彩虹)" ;;
        persist.sys.oplus.serialno)      echo "厂商序列号(sys)" ;;
        android_id)                      echo "安卓ID" ;;
        ril.gsm.imei)                    echo "IMEI(ril)" ;;
        gsm.serial)                      echo "GSM序列号" ;;
        ro.ril.oem.imei)                 echo "OEM IMEI" ;;
        ro.ril.oem.imei1)                echo "OEM IMEI 1" ;;
        *)                               echo "$1" ;;
    esac
}
