#!/system/bin/sh
# ============================================================
#  ACE Guard —— adid.sh（兼容层）
#
#  v1.9.0：ADID 已并入设备身份模块，四项（SERIAL / IMEI /
#  CHIPECID / ADID）统一在 script/identity.sh 实现、统一落盘到
#  data/identity、统一轮换、统一自检。
#
#  本文件只保留壳，让历史调用点（service.sh / action.sh /
#  bin/ag_webui.sh / 旧任务脚本）里的 ". script/adid.sh" 不报错。
#  新代码请直接依赖 identity.sh 的 ag_identity_* / ag_adid_*。
# ============================================================

[ "${_AG_ADID_SHIM:-0}" = "1" ] && return 0 2>/dev/null
_AG_ADID_SHIM=1

_ag_adid_shim_load() {
    local f
    for f in \
        "${MODDIR:-/data/adb/modules/ace_guard}/script/identity.sh" \
        "/data/adb/modules/ace_guard/script/identity.sh" ; do
        [ -f "$f" ] && { . "$f" 2>/dev/null; return 0; }
    done
    return 1
}

if ! command -v ag_identity_load >/dev/null 2>&1; then
    _ag_adid_shim_load || {
        echo "adid.sh: identity.sh 缺失，身份功能不可用" >&2
    }
fi

# 兼容变量名（旧脚本可能直接引用）
AG_ADID_LEGACY="${AG_ADID_LEGACY:-$DATA_DIR/adid}"
AG_IDENTITY_FILE="${AG_IDENTITY_FILE:-$DATA_DIR/identity}"
