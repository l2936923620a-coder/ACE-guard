#!/system/bin/sh

# >>> AG-AUTH-GUARD >>>
# 授权闸门（性能优化版）
#   1) 同进程内复用：_AG_AUTH_GUARDED=1 直接跳过
#   2) 跨进程复用：60 秒内通过的标记文件，避免每次 source 都跑 sha256
#   3) 缓存失效才真正校验
if [ "${_AG_AUTH_GUARDED:-0}" != "1" ]; then
    _ag_gcache="/data/adb/ace_guard/auth/.guardok"
    _ag_gok=0
    if [ -f "$_ag_gcache" ]; then
        _ag_gt=$(cat "$_ag_gcache" 2>/dev/null)
        _ag_now=$(/system/bin/date +%s)
        # 60 秒内的标记视为有效
        case "$_ag_gt" in
            ''|*[!0-9]*) : ;;
            *) [ $(( _ag_now - _ag_gt )) -lt 60 ] && _ag_gok=1 ;;
        esac
    fi
    if [ "$_ag_gok" != "1" ]; then
        if [ -f "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh" ]; then
            . "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh"
            if ! ag_auth_guard "${0##*/}" 2>/dev/null; then
                echo "此设备未授权，功能已冻结" >&2
                exit 1
            fi
            /system/bin/date +%s > "$_ag_gcache" 2>/dev/null
        fi
    fi
fi
_AG_AUTH_GUARDED=1
# <<< AG-AUTH-GUARD <<<

# ============================================================
#  ACE Guard 清理与守护模块
#  清理逻辑来自机主提供的 上号.sh，原样移植
# ============================================================

# ---------- 定位游戏数据目录 ----------
# 判断标准：目录存在 + 归属为 app uid（u0_a*/u11_a* 等），排除被误建的 root 空目录
ag_game_dirs() {
    local d seen="" ou
    for d in /data_mirror/data_ce/null/*/"$PKG" \
             /data/user/*/"$PKG" \
             /data/data/"$PKG"; do
        [ -d "$d" ] || continue
        case "$seen" in
            *"|$d|"*) continue ;;
        esac
        # 必须是真实 app 数据目录：owner 不能是 root
        ou=$(/system/bin/stat -c %u "$d" 2>/dev/null)
        [ -z "$ou" ] && continue
        [ "$ou" = "0" ] && continue
        seen="$seen|$d|"
        echo "$d"
    done
}

# ---------- 清理 ano_tmp ----------
ag_clean_ano_tmp() {
    local n=0 d
    for d in /data/user/*/"$PKG"/files/ano_tmp; do
        [ -e "$d" ] || continue
        /system/bin/toybox rm -rf "$d" 2>/dev/null && n=$((n+1))
    done
    for d in /data_mirror/data_ce/null/*/"$PKG"/files/ano_tmp; do
        [ -e "$d" ] || continue
        /system/bin/toybox rm -rf "$d" 2>/dev/null && n=$((n+1))
    done
    echo "$n"
}

# ---------- 清理行为日志 ----------
ag_clean_behavior_logs() {
    local n=0

    /system/bin/toybox rm -rf /data/system/dropbox/* 2>/dev/null && n=$((n+1))
    /system/bin/toybox rm -rf /data/system/usagestats/* 2>/dev/null && n=$((n+1))
    /system/bin/toybox rm -rf /data/system/appops.xml 2>/dev/null && n=$((n+1))
    /system/bin/toybox rm -rf /data/system/ifw/* 2>/dev/null && n=$((n+1))
    /system/bin/toybox rm -rf /data/system/ndebugsocket/* 2>/dev/null && n=$((n+1))
    /system/bin/toybox rm -rf /data/anr/* 2>/dev/null && n=$((n+1))
    /system/bin/toybox rm -rf /data/tombstones/* 2>/dev/null && n=$((n+1))
    /system/bin/toybox rm -rf /data/misc/logd/* 2>/dev/null && n=$((n+1))
    /system/bin/toybox rm -rf /data/misc/update_engine/log/* 2>/dev/null && n=$((n+1))

    echo "$n"
}

# ---------- 空目录源（守护层 LOCK_DIRS bind 依赖）----------
# 源目录必须放在不带模块特征的位置：
#   mountinfo 的第 4 字段(root field)会原样写出 bind 源路径，
#   若放在 $DATA_DIR(/data/adb/modules/ace_guard) 下，
#   普通 App 读 /proc/self/mountinfo 就能看到模块名。
# 改用 /data/local/tmp/.<随机token>，与 shadow.sh 的遮蔽根同一策略。
AG_EMPTY_ROOT=""
AG_EMPTY_STATE="$DATA_DIR/.empty_root"

ag_empty_init() {
    [ -n "$AG_EMPTY_ROOT" ] && [ -d "$AG_EMPTY_ROOT" ] && return 0
    if [ -r "$AG_EMPTY_STATE" ]; then
        AG_EMPTY_ROOT=$(/system/bin/toybox cat "$AG_EMPTY_STATE" 2>/dev/null | /system/bin/toybox tr -d '\r\n')
    fi
    if [ -z "$AG_EMPTY_ROOT" ] || [ ! -d "$AG_EMPTY_ROOT" ]; then
        local tok
        tok=$(/system/bin/toybox od -An -N5 -tx1 /dev/urandom 2>/dev/null | /system/bin/toybox tr -d ' \r\n')
        [ -n "$tok" ] || tok="tmp$$"
        AG_EMPTY_ROOT="/data/local/tmp/.$tok"
        /system/bin/mkdir -p "$AG_EMPTY_ROOT" 2>/dev/null
        /system/bin/chmod 700 "$AG_EMPTY_ROOT" 2>/dev/null
        ( umask 077; printf '%s' "$AG_EMPTY_ROOT" > "$AG_EMPTY_STATE" ) 2>/dev/null
    fi
    [ -d "$AG_EMPTY_ROOT" ]
}

ag_empty_for() {
    local tag="${1:-default}" d
    ag_empty_init || return 1
    d="$AG_EMPTY_ROOT/$tag"
    [ -d "$d" ] || { /system/bin/mkdir -p "$d" 2>/dev/null; /system/bin/chmod 700 "$d" 2>/dev/null; }
    [ -d "$d" ] && printf '%s' "$d"
}

# 守护层启动前的准备
ag_prepare_empty() {
    ag_empty_init >/dev/null 2>&1
    return 0
}

# ---------- 悬空挂载清扫 ----------
# 挂载点已不存在的条目（app 数据迁到 CE 镜像后遗留）会一直挂在表里，
# 且普通 App 从 mountinfo 可见，必须清掉。
ag_sweep_dead_mounts() {
    local m n=0
    /system/bin/toybox mount 2>/dev/null | /system/bin/grep "$PKG" | \
        sed 's/ type.*//' | sed 's/^.* on //' | while read -r m; do
        [ -z "$m" ] && continue
        [ -e "$m" ] && continue
        /system/bin/nsenter --target 1 --mount -- /system/bin/toybox umount -l "$m" 2>/dev/null
        ag_log WARN "清理悬空挂载: $m"
        n=$((n + 1))
    done
    return 0
}

# ---------- 挂载健康检查（housekeeping 每 3 轮调用）----------
ag_check_mounts() {
    local base t d src
    # 游戏未运行时不建立任何游戏相关挂载
    [ -n "$(ag_find_game_pid 2>/dev/null)" ] || return 0
    for base in $(ag_game_dirs); do
        [ -d "$base" ] || continue
        for d in $LOCK_DIRS; do
            t="$base/files/$d"
            [ -d "$t" ] || continue
            /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $t " && continue
            src=$(ag_empty_for "lock_$d")
            [ -n "$src" ] && [ -d "$src" ] || continue
            /system/bin/toybox mount -o bind "$src" "$t" 2>/dev/null
        done
    done
    return 0
}

# ---------- 建立守护层 LOCK_DIRS 挂载（游戏启动时调用）----------
ag_lock_dirs() {
    local base t d src ou n=0
    for base in $(ag_game_dirs); do
        [ -d "$base" ] || continue
        for d in $LOCK_DIRS; do
            t="$base/files/$d"
            [ -d "$t" ] || continue
            /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $t " && continue
            src=$(ag_empty_for "lock_$d")
            [ -n "$src" ] && [ -d "$src" ] || continue
            ou=$(/system/bin/stat -c %u "$base" 2>/dev/null)
            [ -n "$ou" ] && /system/bin/chown "$ou:$ou" "$src" 2>/dev/null
            /system/bin/toybox mount -o bind "$src" "$t" 2>/dev/null
            n=$((n + 1))
        done
    done
    [ "$n" -gt 0 ] && ag_log INFO "锁定下发目录 $n 条"
    return 0
}

# ---------- 恢复游戏目录权限（游戏退出时调用）----------
# 把 ag_guard_inside 锁成 000 的目录恢复为可访问
# 用游戏数据根目录的权限做基准（正常是 771 或 755 的 files 子目录）
ag_unlock_perms() {
    local base t d n=0 ref
    for base in $(ag_game_dirs); do
        [ -d "$base" ] || continue
        # 取 files 目录本身的权限作为参照
        ref=$(/system/bin/stat -c %a "$base/files" 2>/dev/null)
        [ -z "$ref" ] && ref=771
        for d in $ACCUSE_DIRS; do
            t="$base/files/$d"
            [ -d "$t" ] || continue
            [ "$(/system/bin/stat -c %a "$t" 2>/dev/null)" = "0" ] || continue
            /system/bin/chmod "$ref" "$t" 2>/dev/null
            n=$((n + 1))
        done
    done
    [ "$n" -gt 0 ] && ag_log INFO "恢复目录权限 $n 个"
    return 0
}

# ---------- 解除守护层 LOCK_DIRS 挂载 ----------
ag_unlock_dirs() {
    local base t d n=0
    for base in $(ag_game_dirs); do
        [ -d "$base" ] || continue
        for d in $LOCK_DIRS; do
            t="$base/files/$d"
            [ -d "$t" ] || continue
            /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $t " || continue
            /system/bin/nsenter --target 1 --mount -- /system/bin/toybox umount -l "$t" 2>/dev/null || \
                /system/bin/toybox umount -l "$t" 2>/dev/null
            n=$((n + 1))
        done
    done
    [ "$n" -gt 0 ] && ag_log INFO "解除锁目录挂载 $n 条"
    return 0
}

# ============================================================
#  以下移植自 上号.sh
# ============================================================

# 移植自 上号.sh guard_inside
# 改造：整个循环体只在游戏运行时执行（对齐生命周期）
#   闲时（游戏未运行）跳过全部动作：不 pkill、不清缓存、不 chmod 000
ag_guard_inside() {
    ag_prepare_empty
    ag_log INFO "[守护] 举报缓存清理 + 远程下发目录锁定 启动（仅游戏运行时生效）"

    local base d proc

    while true; do
        ag_orphan_check
        # 游戏未运行 → 本轮直接跳过（读状态中心缓存，不额外开销）
        if ! ag_game_running >/dev/null 2>&1; then
            /system/bin/sleep "${GUARD_INTERVAL:-20}"
            continue
        fi

        for base in $(ag_game_dirs); do
            # 1. 终止上报进程（排除自身）
            local self=$$
            for proc in $KILL_PROCS; do
                /system/bin/pgrep -f "$proc" 2>/dev/null | while read -r p; do
                    [ "$p" = "$self" ] && continue
                    [ -r "/proc/$p/cmdline" ] || continue
                    case "$(/system/bin/toybox cat "/proc/$p/cmdline" 2>/dev/null | /system/bin/toybox tr '\0' ' ')" in
                        *ace_guard*) continue ;;
                    esac
                    /system/bin/kill -9 "$p" 2>/dev/null
                done
            done

            # 2. 清理举报缓存目录
            for d in $ACCUSE_DIRS; do
                local t="$base/files/$d"
                [ -d "$t" ] || continue
                if [ -n "$(/system/bin/toybox ls -A "$t" 2>/dev/null)" ]; then
                    /system/bin/toybox rm -rf "$t"/* 2>/dev/null
                fi
            done

            # 3. 目录权限锁 000（外层已确保游戏在运行；退出后由 ag_unlock_perms 恢复）
            for d in $ACCUSE_DIRS; do
                local t="$base/files/$d"
                [ -d "$t" ] || /system/bin/mkdir -p "$t" 2>/dev/null
                [ -d "$t" ] || continue
                local ou
                ou=$(/system/bin/stat -c %u "$base" 2>/dev/null)
                [ -n "$ou" ] && /system/bin/chown -R "$ou:$ou" "$t" 2>/dev/null
                if [ "$(/system/bin/stat -c %a "$t" 2>/dev/null)" != "0" ]; then
                    /system/bin/chmod 000 "$t" 2>/dev/null
                fi
            done

            # 4. 远程下发目录 bind 锁定（外层已确保游戏在运行）
            for d in $LOCK_DIRS; do
                    local t="$base/files/$d"
                    [ -d "$t" ] || /system/bin/mkdir -p "$t" 2>/dev/null
                    [ -d "$t" ] || continue
                    local ou
                    ou=$(/system/bin/stat -c %u "$base" 2>/dev/null)
                    [ -n "$ou" ] && /system/bin/chown -R "$ou:$ou" "$t" 2>/dev/null
                    /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $t " && continue
                    local src
                    src=$(ag_empty_for "lock_$d")
                    [ -n "$src" ] && [ -d "$src" ] || continue
                    [ -n "$ou" ] && /system/bin/chown "$ou:$ou" "$src" 2>/dev/null
                    /system/bin/toybox mount -o bind "$src" "$t" 2>/dev/null
            done

            # 5. 通配清理下发的加密/检测文件
            local f
            for f in "$base/files/"$ACCUSE_PATTERNS; do
                [ -e "$f" ] || continue
                /system/bin/toybox rm -rf "$f" 2>/dev/null
            done
        done

        # 6. 系统日志清理
        /system/bin/toybox dmesg -c >/dev/null 2>&1

        /system/bin/sleep "${GUARD_INTERVAL:-20}"
    done
}

# ---------- 游戏进程状态跟踪 ----------
AG_GAME_WAS_RUNNING=""

ag_check_game_exit() {
    local cur="$1"
    if [ -n "$AG_GAME_WAS_RUNNING" ] && [ -z "$cur" ]; then
        ag_log INFO "游戏退出，${EXIT_CLEAN_DELAY}s 后清理"
        (
            /system/bin/sleep "${EXIT_CLEAN_DELAY:-8}"
            ag_full_clean
        ) &
        AG_GAME_WAS_RUNNING=""
    elif [ -n "$cur" ]; then
        AG_GAME_WAS_RUNNING="$cur"
    fi
}

# ---------- 完整清理 ----------
ag_full_clean() {
    ag_log INFO "开始清理"
    local a b
    a=$(ag_clean_ano_tmp)
    b=$(ag_clean_behavior_logs)
    /system/bin/toybox dmesg -c >/dev/null 2>&1
    ag_log INFO "清理完成 ano_tmp=${a:-0} 行为日志=${b:-0}"
}

# ============================================================
#  以下移植自 上号.sh 其余模块
# ============================================================

# ---------- 系统日志遮蔽 (block_system_log) ----------
ag_block_system_log() {
    [ "$ENABLE_LOG_BLOCK" = "1" ] || return 0
    local base
    for base in $(ag_game_dirs); do
        [ -d "$base/logs" ] && {
            /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $base/logs " || \
                /system/bin/toybox mount --bind /dev/null "$base/logs" 2>/dev/null
        }
        [ -d "$base/cache/log" ] && {
            /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $base/cache/log " || \
                /system/bin/toybox mount --bind /dev/null "$base/cache/log" 2>/dev/null
        }
    done
    /system/bin/toybox dmesg -c >/dev/null 2>&1
}

# ---------- 探针进程查杀 (kill_probe_process) ----------
ag_kill_probe() {
    [ "$ENABLE_KILL_PROBE" = "1" ] || return 0
    local proc self
    self=$$
    for proc in $KILL_PROCS; do
        # 排除自身与调用链，避免 pkill -f 误杀
        /system/bin/pgrep -f "$proc" 2>/dev/null | while read -r p; do
            [ "$p" = "$self" ] && continue
            [ -r "/proc/$p/cmdline" ] || continue
            case "$(/system/bin/toybox cat "/proc/$p/cmdline" 2>/dev/null | /system/bin/toybox tr '\0' ' ')" in
                *ace_guard*|*ag_kill_probe*) continue ;;
            esac
            /system/bin/kill -9 "$p" 2>/dev/null
        done
    done
    return 0
}

# ---------- 行为特征混淆 (behavior_confuse) ----------
ag_behavior_confuse() {
    [ "$ENABLE_BEHAVIOR_MASK" = "1" ] || return 0
    local base sub f
    for base in $(ag_game_dirs); do
        for sub in behavior behavior7 sample touch; do
            for f in "$base/files/$sub"/*; do
                [ -f "$f" ] && /system/bin/toybox rm -f "$f" 2>/dev/null
            done
        done
    done
    return 0
}

# ---------- 临时内存清理 (wipe_temp_memory) ----------
ag_wipe_temp() {
    local base
    for base in $(ag_game_dirs); do
        /system/bin/toybox rm -rf "$base/files/.tmp"/* 2>/dev/null
        /system/bin/toybox rm -rf "$base/cache/.tmp"/* 2>/dev/null
    done
    /system/bin/sync 2>/dev/null
    return 0
}

# ---------- 反调试 (antidebug_watch) ----------
ag_antidebug() {
    [ "$ENABLE_ANTIDEBUG" = "1" ] || return 0
    local pid tracer
    # 只处理针对游戏的注入器，不无脑 kill 所有 TracerPid
    /system/bin/pkill -f "zygisk_inject.*$PKG" 2>/dev/null
    /system/bin/pkill -f "frida-server" 2>/dev/null
    return 0
}

# ---------- 后台守护主循环（合并多个周期性任务）----------
ag_housekeeping_loop() {
    ag_log INFO "后台维护启动"
    local tick=0

    while true; do
        ag_orphan_check
        tick=$((tick + 1))

        # 每轮：探针查杀
        ag_kill_probe

        # 每 2 轮：行为文件混淆
        [ $((tick % 2)) -eq 0 ] && ag_behavior_confuse

        # 每 3 轮：挂载检查修复
        [ $((tick % 3)) -eq 0 ] && ag_check_mounts

        # 每 5 轮：闲时清扫残留挂载（无游戏进程时不应保留任何游戏挂载）
        if [ $((tick % 5)) -eq 0 ]; then
            if [ -z "$(ag_find_game_pid 2>/dev/null)" ]; then
                ag_sweep_dead_mounts
                ag_unlock_dirs
            fi
        fi

        # 每 3 轮：系统日志遮蔽
        [ $((tick % 3)) -eq 0 ] && ag_block_system_log

        # 每 4 轮：临时内存清理
        [ $((tick % 4)) -eq 0 ] && ag_wipe_temp

        # 每 4 轮：反调试
        [ $((tick % 4)) -eq 0 ] && ag_antidebug

        /system/bin/sleep "${HOUSEKEEPING_INTERVAL:-20}"
    done
}
