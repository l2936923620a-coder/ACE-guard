#!/system/bin/sh
# ============================================================
#  ACE Guard 缺失函数补齐 (v1.1.1)
#
#  原模块被引用但从未定义的函数，导致守护层静默失效：
#    ag_empty_for        -> guard_inside LOCK_DIRS bind 全部失败
#    ag_prepare_empty    -> guard_inside 首行报错
#    ag_check_mounts     -> housekeeping 每 3 轮报错
#  clean.sh 中直接内联定义，本文件仅做存在性自检。
# ============================================================

ag_fixup_selfcheck() {
    local miss="" f
    for f in ag_empty_for ag_prepare_empty ag_check_mounts ag_hide_empty; do
        command -v "$f" >/dev/null 2>&1 || miss="$miss $f"
    done
    [ -z "$miss" ] && return 0
    ag_log ERROR "缺失函数:$miss"
    return 1
}
