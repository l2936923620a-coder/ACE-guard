#!/system/bin/sh
# ============================================================
#  ACE Guard 探针调用器
#
#  原理：
#    探针是独立 APK（com.aceguard.probe），运行在 untrusted_app 域，
#    没有任何 root 权限。模块用 am start 拉起它，它写完结果到
#    /sdcard/Android/data/com.aceguard.probe/files/probe_result.json，
#    模块再以 root 读回。
#
#  这样得到的检测结果 = 一个普通 APP 看到的真实环境，
#  而不是 root 视角下"到处都是痕迹"的假象。
# ============================================================
SELF=$(/system/bin/toybox readlink -f "$0")
MODDIR=$(/system/bin/toybox dirname "$(dirname "$SELF")")

PROBE_PKG="com.aceguard.probe"
PROBE_ACT="com.aceguard.probe/.ProbeActivity"
PROBE_APK_SRC="$MODDIR/probe/aceguard-probe.apk"

# 结果文件可能在两处（取决于存储重定向）
RESULT_PATHS="/sdcard/Android/data/$PROBE_PKG/files/probe_result.json
/storage/emulated/0/Android/data/$PROBE_PKG/files/probe_result.json"

# 超时（秒）
PROBE_TIMEOUT=25

# ---------- 探针是否已安装 ----------
probe_installed() {
    # pm list packages 受包可见性限制，改用 pm path（更可靠）
    _pp=$(/system/bin/pm path "$PROBE_PKG" 2>/dev/null)
    case "$_pp" in
        package:*) return 0 ;;
    esac
    # 兜底：查安装目录
    ls -d /data/app/*/"$PROBE_PKG"-* >/dev/null 2>&1 && return 0
    return 1
}

# ---------- 自动安装 ----------
probe_ensure_installed() {
    if probe_installed; then
        return 0
    fi
    [ -f "$PROBE_APK_SRC" ] || return 1
    echo "正在安装探针 APK..." >&2
    /system/bin/pm install -r -g "$PROBE_APK_SRC" >/dev/null 2>&1
    probe_installed
}

# ---------- 清理旧结果 ----------
probe_clean_result() {
    for p in $RESULT_PATHS; do
        [ -f "$p" ] && rm -f "$p" 2>/dev/null
    done
}

# ---------- 读取结果 ----------
probe_read_result() {
    for p in $RESULT_PATHS; do
        if [ -f "$p" ] && [ -s "$p" ]; then
            cat "$p"
            return 0
        fi
    done
    return 1
}

# ---------- 主入口 ----------
# 返回：0 成功，1 失败。结果 JSON 输出到 stdout
probe_run() {
    if ! probe_ensure_installed; then
        echo '{"ok":false,"error":"探针 APK 未安装且模块内无 APK 文件"}'
        return 1
    fi

    probe_clean_result

    # 强制停止，避免旧进程复用
    /system/bin/am force-stop "$PROBE_PKG" >/dev/null 2>&1
    /system/bin/sleep 1

    # 拉起探针（silent 模式，无界面）
    /system/bin/am start -n "$PROBE_ACT" --ez silent true >/dev/null 2>&1

    # 等待结果文件出现
    _i=0
    while [ "$_i" -lt "$PROBE_TIMEOUT" ]; do
        /system/bin/sleep 1
        _i=$((_i + 1))
        if probe_read_result >/dev/null 2>&1; then
            break
        fi
    done

    # 收尾
    /system/bin/am force-stop "$PROBE_PKG" >/dev/null 2>&1

    _out=$(probe_read_result)
    if [ -z "$_out" ]; then
        echo "{\"ok\":false,\"error\":\"探针未在 ${PROBE_TIMEOUT}s 内返回结果\"}"
        return 1
    fi

    printf '%s' "$_out"
    return 0
}

# ---------- 输出纯 items 数组（给 diag 拼接用）----------
probe_items_only() {
    _raw=$(probe_run) || return 1
    [ -n "$_raw" ] || return 1
    case "$_raw" in
        *'"items":['*)
            _a=${_raw#*'"items":['}
            _a=${_a%%'],"count"'*}
            if [ -n "$_a" ]; then
                printf '%s' "$_a"
                return 0
            fi ;;
    esac
    return 1
}

# ---------- 命令行 ----------
case "$1" in
    run)     probe_run ;;
    items)   probe_items_only ;;
    status)
        if probe_installed; then
            echo "installed"
            _v=$(/system/bin/dumpsys package "$PROBE_PKG" 2>/dev/null | /system/bin/grep -m1 "versionName=" | tr -d ' ')
            echo "$_v"
        else
            echo "not_installed"
        fi ;;
    install) probe_ensure_installed && echo "ok" || echo "fail" ;;
    uninstall)
        /system/bin/pm uninstall "$PROBE_PKG" >/dev/null 2>&1
        echo "done" ;;
    *)
        echo "usage: $0 run|status|install|uninstall"
        exit 1 ;;
esac
