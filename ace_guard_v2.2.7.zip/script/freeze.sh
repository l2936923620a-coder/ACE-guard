#!/system/bin/sh
# ============================================================
#  ACE Guard 功能暂停模块
#
#  作用：
#    当检测到需要更新或使用条件不满足时，暂时停止模块的
#    全部后台功能，避免继续占用系统资源。
#
#  对用户的影响：
#    · 模块的保护功能会暂停，游戏环境恢复为原始状态
#    · 模块卡片与更新提示会正常显示，方便你及时更新
#    · 更新完成并重启后，功能会自动恢复，无需手动操作
#
#  说明：
#    暂停只影响模块自身的后台服务，不会改动系统其他部分，
#    也不会影响你设备上的其他应用。
# ============================================================

# 冻结执行器依赖的目录（notice.sh 未加载时兜底）
AG_NOTICE_DIR="${AG_NOTICE_DIR:-/data/adb/ace_guard/notice}"
AG_NOTICE_LOG="${AG_NOTICE_LOG:-$AG_NOTICE_DIR/notice.log}"
AG_AUTH_DIR="${AG_AUTH_DIR:-/data/adb/ace_guard/auth}"
MODDIR="${MODDIR:-/data/adb/modules/ace_guard}"
# ag_log 内部会做数值比较，未初始化会报 bad number
LOG_LEVEL="${LOG_LEVEL:-1}"
mkdir -p "$AG_NOTICE_DIR" 2>/dev/null

AG_FREEZE_MARK="$AG_NOTICE_DIR/.frozen"
# ============================================================
#  进程分类：本体进程（冻结时保留） vs 业务进程（冻结时终止）
#
#  设计原则（用户要求）：
#    冻结只冻结「模块功能」，不影响「模块本体」。
#    本体包括：卡片刷新、版本监控、篡改检测、WebUI 调用。
#    只有真正干活的业务守护才该被杀。
# ============================================================

# 本体进程关键字（命令或脚本名里出现即视为本体，永不冻结）
#   ag_prop_daemon.sh   卡片文案守护
#   notice.sh / ag_notice_daemon   版本监控
#   ag_webui.sh         WebUI 后端（用户主动调用）
#   ag_update_probe / ag_update_download_only  下载相关
AG_BODY_PROCS="ag_prop_daemon notice.sh ag_notice_daemon ag_webui.sh ag_cfg_guard_prop ag_freeze"

# 业务进程关键字（这些才是冻结目标）
AG_WORK_PROCS="ag_guard_inside ag_shadow_lifecycle ag_housekeeping_loop ag_mem_check_loop ag_cache_warm.sh service.sh"

# 判断某个命令行是否属于「本体进程」
#   $1 = 完整命令行   返回 0=本体（保留）  1=业务（可杀）
ag_proc_is_body() {
    _line="$1"
    for _k in $AG_BODY_PROCS; do
        case "$_line" in
            *"$_k"*) return 0 ;;
        esac
    done
    return 1
}

# 判断某个命令行是否属于「明确的业务进程」
#   $1 = 完整命令行   返回 0=是业务  1=不是
ag_proc_is_work() {
    _line="$1"
    # 优先用角色标识精确匹配（新启动方式会在命令行里带 ag_role=<函数名>）
    for _k in $AG_WORK_PROCS; do
        case "$_line" in
            *"ag_role=$_k"*) return 0 ;;
        esac
    done
    # 兼容旧式匹配
    for _k in $AG_WORK_PROCS; do
        case "$_line" in
            *"$_k"*) return 0 ;;
        esac
    done
    return 1
}


# 列出本模块所有进程 PID（排除自己）
ag_freeze_pids() {
    _self=$$
    # 白名单机制：只终止明确的「业务进程」，本体进程一律保留。
    # 这样卡片守护、版本监控、篡改检测都能活下来，
    # 冻结后仍能刷卡片、发现版本追平、检测 prop 篡改。
    /system/bin/toybox ps -A -o PID,ARGS 2>/dev/null \
        | /system/bin/grep -F "$MODDIR" \
        | /system/bin/grep -vF "grep" \
        | while IFS= read -r _l; do
              # toybox ps 的列格式不固定，直接取行首第一个数字字段
              _p=$(printf '%s' "$_l" | /system/bin/toybox tr -s ' ' | /system/bin/sed 's/^ *//' | /system/bin/toybox cut -d' ' -f1)
              case "$_p" in ''|*[!0-9]*) continue ;; esac
              [ "$_p" = "$_self" ] && continue

              # 去掉 PID 字段，只看命令行
              _cmd=$(printf '%s' "$_l" | /system/bin/toybox cut -d' ' -f2-)

              # 本体进程：保留
              ag_proc_is_body "$_cmd" && continue

              # 明确的业务进程：终止
              if ag_proc_is_work "$_cmd"; then
                  printf '%s\n' "$_p"
                  continue
              fi

              # 其余含 ace_guard 路径的进程：保守起见保留
              # （宁可少杀，也不要误杀本体导致无法自愈）
          done | /system/bin/toybox sort -u
}

# 终止全部模块进程（两轮，确保子进程也被带走）
ag_freeze_kill_all() {
    _round=0
    while [ "$_round" -lt 2 ]; do
        _round=$(( _round + 1 ))
        _any=0
        for _p in $(ag_freeze_pids); do
            _any=1
            # 先温和终止，再强杀
            /system/bin/toybox kill -TERM "$_p" 2>/dev/null
        done
        [ "$_any" = "0" ] && break
        /system/bin/sleep 1
        for _p in $(ag_freeze_pids); do
            /system/bin/toybox kill -9 "$_p" 2>/dev/null
        done
        /system/bin/sleep 1
    done
    return 0
}

# 还原遮蔽挂载（若已挂载）
ag_freeze_restore_mounts() {
    command -v ag_shadow_stop >/dev/null 2>&1 && ag_shadow_stop >/dev/null 2>&1
    command -v ag_shadow_restore >/dev/null 2>&1 && ag_shadow_restore >/dev/null 2>&1
    if command -v ag_sweep_dead_mounts >/dev/null 2>&1; then
        ag_sweep_dead_mounts >/dev/null 2>&1
    fi
    return 0
}

# 清理 run 目录里的 pid 文件
# 注意：不能删整个 data/run，版本监控还要靠其中的 notice.pid 排除自身
ag_freeze_clear_pids() {
    _run="$MODDIR/data/run"
    if [ -d "$_run" ]; then
        for _f in "$_run"/*.pid; do
            [ -f "$_f" ] || continue
            case "$_f" in
                */notice.pid) continue ;;   # 保留监控自身
            esac
            rm -f "$_f" 2>/dev/null
        done
    fi
    rm -f "$MODDIR/data/service.pid" 2>/dev/null
    rm -f "$AG_AUTH_DIR/.prop_daemon.pid" 2>/dev/null
    rm -rf "$MODDIR/data/.service.lock" 2>/dev/null
    return 0
}

# 主入口：$1=原因（用于标记与日志）
ag_freeze_all() {
    _why="${1:-update}"

    # 标记：防止主流程被任何方式再次拉起
    mkdir -p "$AG_NOTICE_DIR" 2>/dev/null
    {
        echo "REASON=$_why"
        echo "TIME=$(/system/bin/date +%s)"
        echo "MODDIR=$MODDIR"
    } > "$AG_FREEZE_MARK" 2>/dev/null
    chmod 644 "$AG_FREEZE_MARK" 2>/dev/null

    # 先还原挂载（依赖仍在运行的进程，必须在杀之前做）
    ag_freeze_restore_mounts

    # 终止全部进程
    ag_freeze_kill_all

    # 清 pid 文件
    ag_freeze_clear_pids

    command -v ag_log >/dev/null 2>&1 && \
        ag_log WARN "冻结完成：已终止全部模块进程（原因=$_why）"
    # LOG_LEVEL 未初始化时 ag_log 内部比较会报 bad number，直接写文件更稳
    echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') freeze reason=$_why all_procs_killed" \
        >> "$AG_NOTICE_LOG" 2>/dev/null
    return 0
}

# 是否处于冻结状态（供主流程闸门判断，不联网）
ag_is_frozen() {
    [ -f "$AG_FREEZE_MARK" ] && return 0
    return 1
}

# 解除冻结（版本追平后调用）
ag_unfreeze_all() {
    rm -f "$AG_FREEZE_MARK" 2>/dev/null
    command -v ag_log >/dev/null 2>&1 && ag_log INFO "已解除冻结"
    return 0
}
