"use strict";

const BIN = "/data/adb/modules/ace_guard/bin/ag_webui.sh";
const $  = s => document.querySelector(s);

/* ============ 与 KSU / APatch WebUI 的桥 ============ */
function shellQuote(s){
  s = String(s == null ? "" : s);
  if (/^[A-Za-z0-9_\-\/\.:=@%+]+$/.test(s)) return s;
  return "'" + s.replace(/'/g, "'\\''") + "'";
}

function execRaw(cmd, timeoutMs){
  return new Promise((resolve, reject) => {
    const k = globalThis.ksu || globalThis.$APATCH;
    if (!k || typeof k.exec !== "function")
      return reject(new Error("未检测到 WebUI 执行接口"));

    const cb = "__agcb_" + Date.now() + "_" + Math.random().toString(36).slice(2);
    let settled = false;

    // 硬超时：防止 ksu.exec 回调不触发导致 Promise 永久挂起
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      delete globalThis[cb];
      reject(new Error("执行超时（" + ((timeoutMs || 8000) / 1000) + " 秒无响应）"));
    }, timeoutMs || 8000);

    globalThis[cb] = (errno, stdout, stderr) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      delete globalThis[cb];
      resolve({ errno, stdout: stdout || "", stderr: stderr || "" });
    };

    try {
      k.exec(cmd, "{}", cb);
    } catch (e) {
      if (!settled){
        settled = true;
        clearTimeout(timer);
        delete globalThis[cb];
        reject(e);
      }
    }
  });
}

async function api(...args){
  // 末位若是数字则视为超时毫秒数，不算作命令参数
  let timeoutMs = 0;
  if (args.length && typeof args[args.length - 1] === "number"){
    timeoutMs = args.pop();
  }
  const line = "sh " + BIN + " " + args.map(a =>
    shellQuote(typeof a === "object" ? JSON.stringify(a) : a)
  ).join(" ");
  const r = await execRaw(line, timeoutMs || 30000);
  const text = (r.stdout || "").trim();
  const lines = text.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
  for (let i = lines.length - 1; i >= 0; i--){
    let o;
    try { o = JSON.parse(lines[i]); } catch (e) { continue; }
    if (!o || typeof o.ok !== "boolean") continue;
    if (!o.ok) throw new Error(o.message || "操作失败");
    return o.data;
  }
  throw new Error("返回异常: " + (text.slice(-180) || r.stderr.slice(-180) || "无输出"));
}

/* ============ 加载动作 ============ */
let _loaderCount = 0;

/** 全屏加载遮罩 */
function showPageLoader(text){
  _loaderCount++;
  const el = document.querySelector("#pageLoader");
  if (!el) return;
  const t = document.querySelector("#pageLoaderText");
  if (t) t.textContent = text || "处理中…";
  el.classList.add("show");
}

function hidePageLoader(){
  _loaderCount = Math.max(0, _loaderCount - 1);
  if (_loaderCount > 0) return;
  const el = document.querySelector("#pageLoader");
  if (el) el.classList.remove("show");
}

/** 按钮转圈：执行期间给按钮加 loading-btn 类 */
async function withBtnLoading(btn, fn){
  if (!btn) return fn();
  if (btn.dataset.loading === "1") return;
  btn.dataset.loading = "1";
  btn.classList.add("loading-btn");
  // 深色按钮用白圈，浅色按钮用蓝圈
  if (!btn.classList.contains("primary") && !btn.classList.contains("danger")){
    btn.classList.add("ghost");
  }
  try {
    return await fn();
  } finally {
    btn.classList.remove("loading-btn", "ghost");
    delete btn.dataset.loading;
  }
}

/** 卡片内容替换成加载态 */
function setInlineLoading(selector, text){
  const el = document.querySelector(selector);
  if (!el) return;
  el.innerHTML = '<div class="inline-load"><div class="spin"></div><span>'
    + esc(text || "加载中…") + '</span></div>';
}

/** 按钮文字临时替换（用于"重新检测"这类长任务） */
function setBtnText(btn, text){
  if (!btn) return;
  if (!btn.dataset.origText) btn.dataset.origText = btn.textContent;
  if (text === null){
    btn.textContent = btn.dataset.origText || btn.textContent;
  } else {
    btn.textContent = text;
  }
}

/* ============ UI 工具 ============ */
let toastTimer = null;
function toast(msg, bad){
  const t = $("#toast");
  t.textContent = msg;
  t.className = "show" + (bad ? " bad" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.className = ""; }, 2600);
}

function esc(s){
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function copyText(text){
  const done = () => toast("已复制");
  if (navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(text).then(done).catch(() => { fb(); done(); });
  } else { fb(); done(); }
  function fb(){
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.cssText = "position:fixed;opacity:0;left:-9999px";
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand("copy"); } catch (e) {}
    document.body.removeChild(ta);
  }
}

const STATE_CLASS = { OK: "ok", FAIL: "bad", WARN: "warn", SKIP: "skip" };

/* 未授权原因：按后端返回的 code_err 给出明确标题与引导 */
const ERR_INFO = {
  NO_FILE: {
    title: "尚未激活授权",
    desc: "本机没有授权文件。如果你是首次安装，需要用下方设备码向作者索取授权码；如果之前激活过，说明授权文件已被清除，重新粘贴一次授权码即可。",
    action: "input"
  },
  CORRUPT: {
    title: "授权文件损坏",
    desc: "授权文件存在但内容不完整，通常是写入过程中断或存储异常导致。请重新粘贴一次授权码。",
    action: "input"
  },
  TAMPERED: {
    title: "授权文件被修改",
    desc: "授权文件的签名校验未通过，文件内容与签发时不一致。请勿手工编辑授权文件，重新粘贴原始授权码即可恢复。",
    action: "input"
  },
  FP_CHANGED: {
    title: "设备指纹已变化",
    desc: "本机的真机 SERIAL / IMEI / CHIPECID 与激活时不符。换机、刷机、恢复出厂或更换主板都会触发。原授权无法迁移，请用新设备码重新向作者申请。",
    action: "input"
  },
  CODE_BAD: {
    title: "授权码与本机不符",
    desc: "授权码签名无效，或者这串码属于另一台设备。请确认粘贴的是作者针对下方设备码签发的授权码。",
    action: "input"
  },
  EXPIRED: {
    title: "授权已到期",
    desc: "限时授权已过有效期，所有功能已冻结。向作者续期后粘贴新的授权码即可恢复。",
    action: "input"
  },
  CLOCK_ROLL: {
    title: "系统时间异常",
    desc: "检测到系统时间被回拨，或当前时间早于授权记录时间。请在校准网络时间后重新打开本页。",
    action: "none"
  },
  NO_SNAPSHOT: {
    title: "指纹快照异常",
    desc: "无法建立或读取真机指纹快照，设备码不稳定。请重启设备后再试。",
    action: "none"
  },
  EMPTY_INPUT: {
    title: "请输入授权码",
    desc: "授权码不能为空。",
    action: "input"
  },
  UNKNOWN: {
    title: "本机未授权",
    desc: "所有功能已冻结。请把下方设备码发给作者获取授权码。",
    action: "input"
  }
};

function errInfo(code){
  return ERR_INFO[code] || ERR_INFO.UNKNOWN;
}
const STATE_COLOR = {
  OK: "var(--green)", FAIL: "var(--red)",
  WARN: "var(--orange)", SKIP: "var(--text-3)"
};

/* ============ 全局状态 ============ */
const app = { overview: null, activeView: "home", busy: false };

/* ============ 授权遮罩 ============ */
function showLock(show, device, authInfo){
  const el = $("#authLock");
  if (!show){
    el.classList.remove("show");
    return;
  }
  // 保险：明确已授权时绝不显示锁屏（防止调用方误判）
  if (authInfo && authInfo.ok === true){
    el.classList.remove("show");
    return;
  }
  el.classList.add("show");
  if (device) $("#lockDevice").textContent = device;

  const a = authInfo || {};
  const ei = errInfo(a.code_err);

  /* 标题与简述 */
  const t = $("#lockTitle");
  const d = $("#lockDesc");
  if (t) t.textContent = ei.title;
  if (d) d.textContent = ei.desc;

  /* 详细原因（系统返回的原始文案） */
  const r = $("#lockReason");
  if (r){
    if (a.reason){
      r.style.display = "";
      r.textContent = "系统判定：" + a.reason +
        (a.code_err ? "（" + a.code_err + "）" : "");
    } else {
      r.style.display = "none";
    }
  }

  /* 时间/快照这类问题不给输入框，改为「重新检测」 */
  const needInput = ei.action !== "none";
  const f = $("#lockInputField");
  const act = $("#lockActivate");
  const retry = $("#lockRetry");
  if (f) f.style.display = needInput ? "" : "none";
  if (act) act.style.display = needInput ? "" : "none";
  if (retry) retry.style.display = needInput ? "none" : "";
}

function setBadge(text, cls){
  const b = $("#statusBadge");
  b.className = "badge" + (cls ? " " + cls : "");
  b.querySelector("span").textContent = text;
}

function switchView(name){
  app.activeView = name;
  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
  const v = $("#view-" + name);
  if (v) v.classList.add("active");
  document.querySelectorAll(".dock-item").forEach(b => {
    b.classList.toggle("active", b.dataset.top === name);
  });
  window.scrollTo(0, 0);
  if (name === "log") loadLog();
  if (name === "guard"){ refreshProbeBox(); loadDiag(); }
}

/* ============ 首页 ============ */
function renderHome(o){
  const a  = o.auth || {};
  const rt = o.runtime || {};
  const dm = o.daemons || {};
  const id = o.identity || {};
  const sc = o.selfcheck || [];
  const okCount = sc.filter(x => x.state === "OK").length;
  const failCount = sc.filter(x => x.state === "FAIL").length;

  let h = "";

  /* 授权条 */
  if (!a.ok){
    h += `<div class="card" style="border-color:rgba(255,159,10,.42)">
      <div class="card-h"><h2 style="color:var(--orange)">⚠️ 未授权</h2></div>
      <div class="row"><span class="k">设备码</span><span class="v mono">${esc(a.device || "—")}</span></div>
      <div class="row"><span class="k">原因</span><span class="v bad">${esc(a.reason || "")}</span></div>
      <div class="btn-row"><button class="btn primary wide" id="goAuth">前往授权</button></div>
    </div>`;
  } else {
    h += `<div class="card" style="border-color:rgba(48,209,88,.32)">
      <div class="card-h">
        <h2 style="color:var(--green)">✓ ${esc(a.plan || "已授权")}</h2>
        <span class="sub">${a.expire ? esc(a.days_left + " 天") : "permanent"}</span>
      </div>
      <div class="row"><span class="k">设备码</span><span class="v mono">${esc(a.device || "—")}</span></div>
      <div class="row"><span class="k">授权码</span><span class="v mono">${esc(a.code_hint || "—")}</span></div>
    </div>`;
  }

  /* 运行状态 */
  h += `<div class="card">
    <div class="card-h"><h2>运行状态</h2><span class="sub">${esc(o.pkg || "")}</span></div>
    <div class="grid2">
      <div class="stat"><div class="lbl">游戏进程</div>
        <div class="val small ${rt.game_running ? "ok" : "bad"}">${rt.game_running ? "运行中 " + esc(rt.game_pid) : "未运行"}</div></div>
      <div class="stat"><div class="lbl">遮蔽挂载</div>
        <div class="val">${esc(rt.shadow_mounts)}</div></div>
      <div class="stat"><div class="lbl">监听进程</div>
        <div class="val">${esc(rt.callbacks)}</div></div>
      <div class="stat"><div class="lbl">属性校验</div>
        <div class="val small ${rt.props_bad ? "bad" : "ok"}">${rt.props_bad ? "异常" : "正常"}</div></div>
    </div>
  </div>`;

  /* 当前指纹 */
  h += `<div class="card">
    <div class="card-h"><h2>当前指纹</h2><span class="sub">${id.ready ? "active" : "未初始化"}</span></div>
    <div class="row"><span class="k">SERIAL</span>
      <span class="v ${id.ready ? "ok" : "bad"}">${esc(id.serial || "—")}</span></div>
    <div class="row"><span class="k">IMEI</span>
      <span class="v mono">${esc(id.imei || "—")}</span></div>
    <div class="row"><span class="k">CHIPECID</span>
      <span class="v mono">${esc(id.chipecid || "—")}</span></div>
    ${id.adid_enabled === false ? "" : `<div class="row"><span class="k">ADID</span>
      <span class="v mono">${esc(id.adid || "—")}</span></div>`}
  </div>`;

  /* 守护线程 */
  h += `<div class="card">
    <div class="card-h"><h2>守护线程</h2></div>
    <div class="row"><span class="k">主服务</span>
      <span class="v ${dm.service ? "ok" : "bad"}">${dm.service ? "运行中" : "未运行"}</span></div>
    <div class="row"><span class="k">监控循环</span>
      <span class="v ${dm.monitor ? "ok" : "bad"}">${dm.monitor ? "运行中" : "未运行"}</span></div>
    <div class="row"><span class="k">守护反制</span>
      <span class="v ${dm.guard ? "ok" : "bad"}">${dm.guard ? "运行中" : "未运行"}</span></div>
  </div>`;

  /* 自检（独立命令拉取，先占位） */
  h += `<div class="card" id="selfcheckCard">
    <div class="card-h"><h2>自检结果</h2>
      <span class="sub" id="scSub">读取中…</span></div>
    <div id="scBody"><div class="inline-load"><div class="spin"></div><span>正在自检…</span></div></div>
  </div>`;
  const brief = [];
  h += `<div class="btn-row">
      <button class="btn btn-sm wide" data-act="diag">查看完整自检</button>
    </div>`;

  $("#homeBody").innerHTML = h;
  $("#homeLoading").style.display = "none";
  $("#homeBody").style.display = "";

  const goAuth = $("#goAuth");
  if (goAuth) goAuth.onclick = () => showLock(true, a.device, a);
}

/* ============ 完整自检页（中文分组，APP 视角优先） ============ */
const GROUP_ORDER = [
  // ---- APK 探针实测（普通应用身份）----
  "身份与环境", "Root 痕迹", "挂载视图", "沙盒强度", "调试状态",
  "文件可见性", "属性一致性", "进程信息", "包可见性", "网络探针", "设备真实性",
  // ---- 兼容：探针不可用时的 root 推断兜底 ----
  "观察上下文", "APP 挂载视图", "APP 进程属性", "APP 内存映射", "沙盒可见性",
  // ---- 模块自身（已合并为一组）----
  "模块自检"
];

const APP_GROUPS = new Set([
  // 探针实测
  "身份与环境", "Root 痕迹", "挂载视图", "沙盒强度", "调试状态",
  "文件可见性", "属性一致性", "进程信息", "包可见性", "网络探针", "设备真实性",
  // root 推断兜底
  "观察上下文", "APP 挂载视图", "APP 进程属性",
  "APP 内存映射", "沙盒可见性"
]);

function renderDiag(data){
  const box = document.querySelector("#diagBody");
  if (!box) return;

  const items = (data && data.items) || [];
  if (!items.length){
    box.innerHTML = '<div class="loading"><div class="spin"></div><span>暂无数据</span></div>';
    return;
  }

  /* 统计 */
  const st = { OK:0, WARN:0, FAIL:0, SKIP:0, INFO:0 };
  items.forEach(i => { if (st[i.state] !== undefined) st[i.state]++; });

  let h = `<div class="diag-sum">
    <div class="diag-chip ok">正常 ${st.OK}</div>
    <div class="diag-chip warn">注意 ${st.WARN}</div>
    <div class="diag-chip bad">异常 ${st.FAIL}</div>
    <div class="diag-chip skip">跳过 ${st.SKIP}</div>
    <div class="diag-total">共 ${items.length} 项</div>
  </div>`;

  /* 按固定顺序分组 */
  const groups = {};
  items.forEach(i => {
    const g = i.group || "其他";
    (groups[g] = groups[g] || []).push(i);
  });

  const order = GROUP_ORDER.filter(g => groups[g])
    .concat(Object.keys(groups).filter(g => GROUP_ORDER.indexOf(g) < 0));

  order.forEach(gName => {
    const list = groups[gName];
    const bad = list.filter(x => x.state === "FAIL").length;
    const warn = list.filter(x => x.state === "WARN").length;
    const dotCls = bad ? "bad" : (warn ? "warn" : "ok");

    const isApp = APP_GROUPS.has(gName);
    const scopeTag = isApp
      ? '<span class="scope-tag app">探针实测</span>'
      : '<span class="scope-tag mod">模块自检</span>';

    h += `<details class="acc"${bad || warn ? " open" : ""}>
      <summary>
        <span class="dot ${dotCls}"></span>
        <span class="t">${esc(gName)}${scopeTag}</span>
        <span class="sub" style="font-size:11.5px;color:var(--text-3);margin-right:6px">${list.length}</span>
        <svg class="chev" viewBox="0 0 24 24"><path d="m9 6 6 6-6 6"/></svg>
      </summary>
      <div class="body">`;

    list.forEach(it => {
      const col = STATE_COLOR[it.state] || "var(--text-3)";
      const cls = STATE_CLASS[it.state] || "skip";
      const bold = it.important ? "font-weight:700" : "font-weight:500";
      h += `<div class="diag-row">
        <span class="diag-dot" style="background:${col}"></span>
        <div class="diag-txt">
          <div class="diag-name" style="${bold}">${esc(it.name || it.key)}${it.important ? '<span class="diag-imp">重要</span>' : ""}</div>
          <div class="diag-detail ${cls}">${esc(it.detail || "")}</div>
        </div>
      </div>`;
    });

    h += `</div></details>`;
  });

  box.innerHTML = h;
}

/** 检查探针状态并渲染安装入口 */
async function refreshProbeBox(){
  const box = document.querySelector("#probeInstallBox");
  const runBtn = document.querySelector("#btnRunDiag");
  if (!box) return;

  let st = { available: false };
  try { st = await api("probe.status"); } catch (e) {}

  if (st && st.available){
    box.innerHTML =
      '<div style="display:flex;align-items:center;gap:10px;padding:10px 14px;' +
      'border-radius:12px;background:rgba(48,209,88,.1);border:1px solid rgba(48,209,88,.28);font-size:12.5px">' +
        '<span style="color:var(--green);font-weight:600">探针已就绪</span>' +
        '<span style="flex:1"></span>' +
        '<span style="color:var(--text-3)">普通应用身份</span>' +
      '</div>';
    if (runBtn) runBtn.disabled = false;
  } else {
    box.innerHTML =
      '<div style="padding:14px;border-radius:12px;background:rgba(255,159,10,.12);' +
      'border:1px solid rgba(255,159,10,.32)">' +
        '<div style="font-size:12.5px;color:var(--text-2);margin-bottom:10px;line-height:1.6">' +
          '尚未安装探针 APK。环境检测需要它以普通应用身份运行，' +
          '未安装时无法准确检测。' +
        '</div>' +
        '<button class="btn btn-sm primary wide" id="btnInstallProbe">安装探针</button>' +
      '</div>';
    if (runBtn) runBtn.disabled = true;

    const ib = document.querySelector("#btnInstallProbe");
    if (ib) ib.onclick = async () => {
      ib.classList.add("loading-btn");
      ib.disabled = true;
      try {
        const r = await api("probe.install");
        if (r && r.installed){
          toast("探针安装成功，开始检测");
          await refreshProbeBox();
          await loadDiag();
        } else {
          toast("安装失败：" + (r && r.message ? r.message : "未知原因"), true);
        }
      } catch (e) {
        toast("安装失败：" + e.message, true);
      } finally {
        ib.classList.remove("loading-btn");
        ib.disabled = false;
      }
    };
  }
}

async function loadDiag(){
  const box = document.querySelector("#diagBody");
  const btn = document.querySelector("#btnRunDiag");

  if (box) {
    box.innerHTML = '<div class="loading"><div class="spin"></div>'
      + '<span>正在调用探针检测环境…</span></div>';
  }
  setBtnText(btn, "检测中…");
  if (btn) btn.disabled = true;

  try {
    const d = await api("diag");
    renderDiag(d);
  } catch (e) {
    if (box) box.innerHTML =
      '<div style="padding:26px 16px;text-align:center;color:var(--red);font-size:13px">'
      + '检测失败：' + esc(e.message) + '</div>';
  } finally {
    setBtnText(btn, null);
    if (btn) btn.disabled = false;
  }
}

/* ============ 隐蔽页 ============ */
function renderGuard(o){
  const rt = o.runtime || {};
  const dm = o.daemons || {};
  const id = o.identity || {};

  // 「隐蔽」tab 已改为「自检」，这里的旧容器可能不存在，直接跳过
  const gs = $("#guardStats");
  if (!gs) return;

  gs.innerHTML = `
    <div class="stat"><div class="lbl">遮蔽挂载</div><div class="val">${esc(rt.shadow_mounts)}</div></div>
    <div class="stat"><div class="lbl">监听进程</div><div class="val">${esc(rt.callbacks)}</div></div>
    <div class="stat"><div class="lbl">游戏</div><div class="val small ${rt.game_running ? "ok" : "bad"}">${rt.game_running ? "运行中" : "未运行"}</div></div>
    <div class="stat"><div class="lbl">守护</div><div class="val small ${dm.guard ? "ok" : "bad"}">${dm.guard ? "在线" : "离线"}</div></div>`;

  const acc = (title, dotCls, rows) => `
    <details class="acc">
      <summary>
        <span class="dot ${dotCls}"></span>
        <span class="t">${esc(title)}</span>
        <svg class="chev" viewBox="0 0 24 24"><path d="m9 6 6 6-6 6"/></svg>
      </summary>
      <div class="body">${rows}</div>
    </details>`;

  const row = (k, v, cls) =>
    `<div class="row"><span class="k">${esc(k)}</span><span class="v ${cls || ""}">${esc(v)}</span></div>`;

  let h = "";
  h += acc("指纹身份", id.ready ? "ok" : "bad",
    row("制造商/型号覆盖", id.ready ? "已生效" : "未初始化", id.ready ? "ok" : "bad") +
    row("SERIAL", id.serial || "—", id.ready ? "ok" : "bad") +
    row("IMEI", id.imei || "—") +
    row("CHIPECID", id.chipecid || "—"));

  h += acc("遮蔽挂载", rt.shadow_mounts > 0 ? "ok" : "skip",
    row("当前挂载数量", String(rt.shadow_mounts || 0)) +
    row("监听回调进程", String(rt.callbacks || 0)) +
    `<div class="btn-row"><button class="btn btn-sm wide" data-act="mountlist">查看挂载列表</button></div>`);

  h += acc("属性校验", rt.props_bad ? "bad" : "ok",
    row("检测结果", rt.props_bad ? rt.props_bad : "全部属性正常", rt.props_bad ? "bad" : "ok") +
    `<div class="btn-row"><button class="btn btn-sm wide" data-act="scan">输出详细扫描</button></div>`);

  h += acc("运行守护", dm.service ? "ok" : "warn",
    row("主服务", dm.service ? "运行中" : "未运行", dm.service ? "ok" : "bad") +
    row("监控循环", dm.monitor ? "运行中" : "未运行", dm.monitor ? "ok" : "bad") +
    row("守护反制", dm.guard ? "运行中" : "未运行", dm.guard ? "ok" : "bad"));

  $("#guardAcc").innerHTML = h;
}

/* ============ 配置页：指纹值 ============ */
function renderFpValues(o){
  const id = o.identity || {};
  const set = (sel, v) => {
    const el = document.querySelector(sel);
    if (el) el.textContent = v || "—";
  };
  set("#fpSerial", id.serial);
  set("#fpImei",   id.imei);
  set("#fpChip",   id.chipecid);
  set("#fpAdid",   id.adid || o.adid || "");
}

/* ============ 配置页 ============ */
// 配置页开关：只保留没有专属按钮的功能。
// ENABLE_IDENTITY / ENABLE_ADID 已由上方「指纹随机」区的随机按钮覆盖，
// ROTATE_ON_BOOT 同属指纹范畴，均不再重复展示。
const CONF_META = [
  ["ENABLE_SHADOW",         "目录遮蔽"],
  ["ENABLE_GUARD",          "守护反制"],
  ["ENABLE_GREEN_LOCK",     "配置伪装"],
  ["ENABLE_PURGE_WATCH",    "下发文件监控"],
  ["ENABLE_NET_BLOCK",      "网络层阻断"],
  ["ENABLE_MONITOR",        "监控主循环"],
  ["ENABLE_SELFCHECK_BOOT", "开机自检"],
  ["ENABLE_KILL_PROBE",     "反探测进程"],
  ["ENABLE_BEHAVIOR_MASK",  "行为混淆"],
  ["ENABLE_ANTIDEBUG",      "反调试"],
  ["ENABLE_EXIT_CLEAN",     "退出清理"]
];

function renderConf(conf){
  let h = "";
  CONF_META.forEach(([key, label]) => {
    const on = !!conf[key];
    h += `<div class="row">
      <span class="k">${esc(label)}</span>
      <div class="switch ${on ? "on" : ""}" data-conf="${esc(key)}" data-on="${on ? 1 : 0}"></div>
    </div>`;
  });
  $("#confSwitches").innerHTML = h;

  document.querySelectorAll(".switch[data-conf]").forEach(el => {
    el.onclick = async () => {
      if (app.busy) return;
      const key = el.dataset.conf;
      const next = el.dataset.on !== "1";
      app.busy = true;
      el.style.opacity = ".5";
      try {
        await api("conf.set", { key: key, value: next });
        el.classList.toggle("on", next);
        el.dataset.on = next ? "1" : "0";
        toast(key + " → " + (next ? "开" : "关"));
      } catch (e) {
        toast("修改失败：" + e.message, true);
      } finally {
        app.busy = false;
        el.style.opacity = "";
      }
    };
  });
}

/* ============ 日志页 ============ */
async function loadLog(){
  const box = $("#logbox");
  box.textContent = "正在读取…";
  try {
    const d = await api("log.get", { lines: 200 });
    const t = d.text || "";
    box.textContent = t || "暂无日志";
    $("#logCount").textContent = (t ? t.split("\n").length : 0) + " 行";
    box.scrollTop = box.scrollHeight;
  } catch (e) {
    box.textContent = "读取失败：" + e.message;
    $("#logCount").textContent = "—";
  }
}

/* ============ 授权页 ============ */
function renderAuth(a){
  const cls = a.ok ? "var(--green)" : "var(--orange)";
  const sn = a.snapshot || {};
  const ei = a.ok ? null : errInfo(a.code_err);
  let h = `<div class="card-h">
      <h2 style="color:${cls}">${a.ok ? "✓ " + esc(a.plan) : "⚠️ " + esc(ei.title)}</h2>
      <span class="sub">${a.expire ? esc(a.days_left + " 天") : (a.ok ? "permanent" : esc(a.code_err || ""))}</span>
    </div>
    <div class="row"><span class="k">设备码</span>
      <span class="v mono">${esc(a.device || "—")}</span></div>
    <div class="field" style="margin-top:12px">
      <button class="btn btn-sm wide" id="authCopyDev">复制设备码</button>
    </div>`;

  if (a.ok){
    h += `<div class="row"><span class="k">授权码</span>
        <span class="v mono">${esc(a.code_hint || "—")}</span></div>
      <div class="row"><span class="k">状态</span>
        <span class="v ok">${esc(a.reason || "")}</span></div>`;
  } else {
    /* 具体失败原因说明 */
    h += `<div style="background:rgba(255,159,10,.1);border:1px solid rgba(255,159,10,.3);
        border-radius:14px;padding:13px 14px;margin:12px 0;font-size:12.5px;line-height:1.65;color:var(--text-2)">
        <b style="color:var(--orange);display:block;margin-bottom:5px">${esc(ei.title)}</b>
        ${esc(ei.desc)}
      </div>
      <div class="row"><span class="k">系统返回</span>
        <span class="v bad" style="font-size:12px">${esc(a.reason || "")}</span></div>`;

    if (ei.action === "input"){
      h += `<div class="field" style="margin-top:16px">
        <label style="display:block;font-size:12px;color:var(--text-2);margin-bottom:7px;font-weight:600">授权码</label>
        <input class="txt" id="authInput" placeholder="AG-XXXXXXXX-XXXXXXXXXXXXXXXX" autocomplete="off" autocapitalize="characters" spellcheck="false">
      </div>
      <div class="btn-row"><button class="btn primary wide" id="authActivate">激 活</button></div>
      <div id="authPageMsg" style="font-size:13px;margin-top:12px;min-height:18px;color:var(--red)"></div>`;
    } else {
      h += `<div class="btn-row"><button class="btn wide" id="authReverify">重新检测</button></div>`;
    }
  }

  /* 联系方式（明确标注是作者的，避免用户误以为是自己的账号） */
  h += `<div style="margin-top:14px;padding-top:12px;border-top:1px solid var(--border)">
      <div style="font-size:12px;color:var(--text-3);margin-bottom:8px">作者联系方式</div>
      <div class="row"><span class="k">作者 QQ</span>
        <span class="v mono">${esc((a.contact || "").replace(/^QQ\s*/, "") || "3658039852")}</span></div>
      <div class="row"><span class="k">作者纸飞机</span>
        <span class="v mono">${esc(a.telegram || "@xiaochunan67")}</span></div>
    </div>`;

  if (a.ok){
    h += `<div class="btn-row"><button class="btn wide" id="authReverify">重新校验</button></div>`;
  }

  $("#authCard").innerHTML = h;

  /* 真机指纹快照卡片 */
  let s = `<div class="card-h"><h2>真机指纹快照</h2>
      <span class="sub">${sn.ready ? "首装备份" : "未建立"}</span></div>`;
  if (sn.ready){
    s += `<div class="row"><span class="k">SERIAL</span><span class="v mono">${esc(sn.serial)}</span></div>
      <div class="row"><span class="k">IMEI</span><span class="v mono">${esc(sn.imei)}</span></div>
      <div class="row"><span class="k">CHIPECID</span><span class="v mono">${esc(sn.chipecid)}</span></div>
      <div class="row"><span class="k">机型</span><span class="v">${esc(sn.brand)} ${esc(sn.model)}</span></div>
      <div class="hint">设备码由以上三项派生，任一变化授权即失效。快照永久保留，不会被伪装值覆盖。</div>`;
  } else {
    s += `<div class="hint">快照将在下次开机（post-fs-data 阶段）自动建立。</div>`;
  }
  $("#snapshotCard").innerHTML = s;

  /* 云端上报状态 */
  let c = `<div class="card-h"><h2>云端上报</h2>
      <span class="sub">${a.cloud_url ? "已配置" : "未配置"}</span></div>`;
  if (a.cloud_url){
    c += `<div class="row"><span class="k">接口</span><span class="v mono" style="font-size:11px">${esc(a.cloud_url)}</span></div>
      <div class="btn-row"><button class="btn btn-sm wide" data-act="auth.upload">立即上报</button></div>
      <div class="btn-row"><button class="btn btn-sm wide" data-act="auth.uploadlog">查看上报记录</button></div>`;
  } else {
    c += `<div class="hint">未配置 AUTH_URL，模块不会发起任何网络请求。<br>
      需要上传设备指纹/IP 时，在 <span class="mono">config/guard.conf</span> 里填写 AUTH_URL。</div>`;
  }
  $("#cloudCard").innerHTML = c;

  const cpd = $("#authCopyDev");
  if (cpd) cpd.onclick = () => copyText(a.device || "");

  const rev = $("#authReverify");
  if (rev) rev.onclick = async () => {
    rev.disabled = true;
    try { await refresh(); toast("已重新校验"); }
    catch (e) { toast(e.message, true); }
    finally { rev.disabled = false; }
  };

  const act = $("#authActivate");
  if (act) act.onclick = () => doActivate($("#authInput").value, $("#authPageMsg"));
}

async function doActivate(code, msgEl){
  code = (code || "").trim().toUpperCase();
  const setMsg = (t, ok) => {
    if (!msgEl) return;
    msgEl.textContent = t;
    msgEl.className = ok ? "ok" : "";
  };
  if (!code){ setMsg("请输入授权码"); return; }
  setMsg("正在校验…", true);
  try {
    await api("auth.activate", { code: code });
    setMsg("激活成功", true);
    toast("授权激活成功");
    setTimeout(() => { showLock(false); refresh(); }, 500);
  } catch (e) {
    setMsg(e.message || "激活失败");
  }
}

/* ============ 数据刷新 ============ */
async function refresh(){
  const hl = document.querySelector("#homeLoading");
  if (hl && hl.style.display !== "none"){
    hl.innerHTML = '<div class="spin"></div><span>正在读取模块状态…</span>';
  }
  const raw = await api("overview");
  await applyOverview(raw);
}

/* ============ 事件绑定 ============ */
function bind(){
  document.querySelectorAll(".dock-item").forEach(b => {
    b.onclick = () => switchView(b.dataset.top);
  });

  /* 授权遮罩 */
  $("#lockCopy").onclick = () => copyText($("#lockDevice").textContent);
  $("#lockActivate").onclick = () => doActivate($("#lockInput").value, $("#authMsg"));
  const retryBtn = $("#lockRetry");
  if (retryBtn) retryBtn.onclick = async () => {
    retryBtn.disabled = true;
    try { await refresh(); }
    catch (e) { toast(e.message, true); }
    finally { retryBtn.disabled = false; }
  };
  $("#lockInput").addEventListener("keydown", e => {
    if (e.key === "Enter") $("#lockActivate").click();
  });

  /* 日志 */
  $("#btnReloadLog").onclick = loadLog;
  $("#btnClearLog").onclick = async () => {
    try { await api("log.clear"); toast("日志已清空"); loadLog(); }
    catch (e) { toast(e.message, true); }
  };

  /* 诊断：长按标题 3 秒显示后端原始返回 */
  const brand = document.querySelector(".brand-txt h1");
  if (brand){
    let pressTimer = null;
    const showDebug = async () => {
      const lines = [];
      lines.push("ksu 桥: " + (globalThis.ksu ? "ksu" : (globalThis.$APATCH ? "APATCH" : "无")));
      for (const cmd of ["auth.status", "overview"]){
        const t0 = Date.now();
        try {
          const d = await api(cmd);
          lines.push("[" + cmd + "] OK " + (Date.now() - t0) + "ms");
          lines.push(JSON.stringify(d).slice(0, 300));
        } catch (e) {
          lines.push("[" + cmd + "] FAIL " + (Date.now() - t0) + "ms: " + (e.message || e));
        }
      }
      alert(lines.join("\n\n"));
    };
    brand.addEventListener("touchstart", () => {
      pressTimer = setTimeout(showDebug, 1200);
    }, { passive: true });
    brand.addEventListener("touchend", () => clearTimeout(pressTimer));
    brand.addEventListener("touchcancel", () => clearTimeout(pressTimer));
  }

  /* 重新检测全部 */
  const bd = document.querySelector("#btnRunDiag");
  if (bd) bd.addEventListener("click", () => {
    if (!app.busy) loadDiag();
  });

  /* 身份随机按钮（SERIAL / IMEI / CHIPECID / ADID 同属一份身份证明） */
  document.querySelectorAll("[data-fp]").forEach(btn => {
    btn.addEventListener("click", async () => {
      if (app.busy) return;
      const target = btn.dataset.fp;
      const label = { serial:"序列号", imei:"IMEI", chipecid:"芯片ID", adid:"安卓ID", all:"全部身份" }[target] || target;

      app.busy = true;
      btn.disabled = true;
      btn.classList.add("loading-btn");
      try {
        const res = await api("fingerprint.random", { target: target });
        if (target === "all"){
          toast("SERIAL / IMEI / CHIPECID / ADID 已全部随机");
        } else {
          toast(label + " 已随机：" + (res[target] || res.adid || ""));
        }
        await refresh();
      } catch (e) {
        toast(label + " 随机失败：" + e.message, true);
      } finally {
        app.busy = false;
        btn.disabled = false;
        btn.classList.remove("loading-btn");
      }
    });
  });

  /* 动作按钮（事件委托） */
  document.addEventListener("click", async e => {
    const btn = e.target.closest("[data-act]");
    if (!btn || app.busy) return;
    const act = btn.dataset.act;

    if (act === "reboot"){
      if (!confirm("确定重启设备？")) return;
    }

    // diag 走自己的加载逻辑
    if (act === "diag"){
      switchView("guard");
      return;
    }

    app.busy = true;
    setBadge("执行中", "");
    btn.classList.add("loading-btn");
    if (!btn.classList.contains("primary") && !btn.classList.contains("danger")){
      btn.classList.add("ghost");
    }
    try {
      let res;
      if (act === "diag"){
        switchView("guard");
        app.busy = false;
        return;
      }
      if (act === "selfcheck"){
        res = await api("selfcheck");
        const items = res.items || [];
        const bad = items.filter(x => x.state === "FAIL").length;
        toast(bad ? ("自检完成 · " + bad + " 项异常") : "自检完成 · 全部正常", bad > 0);
        await refresh();
      } else if (act === "mountlist"){
        const list = await api("mount.list");
        if (!list.length) toast("当前没有遮蔽挂载");
        else { toast("挂载 " + list.length + " 条"); }
      } else {
        res = await api(act);
        const out = (res && (res.output || res.msg)) || "";
        toast(out ? out.split("\n").filter(Boolean).slice(-1)[0].slice(0, 60) : "已执行");
        if (act !== "reboot") await refresh();
      }
    } catch (err) {
      toast(err.message || "执行失败", true);
      if (/UNLICENSED/.test(err.message || "")) setTimeout(refresh, 400);
    } finally {
      app.busy = false;
      btn.classList.remove("loading-btn", "ghost");
      if (app.overview && app.overview.auth && app.overview.auth.ok){
        const a = app.overview.auth;
        setBadge(a.expire ? (a.days_left + " 天") : "已授权", "ok");
      }
    }
  });
}


/* ============ 远程版本更新检查 ============ */
let _updInfo = null;

/** 显示更新弹窗 */
function showUpdate(info){
  const el = $("#updLock");
  if (!el) return;
  _updInfo = info || {};

  const rv = $("#updRemoteVer");
  const lv = $("#updLocalVer");
  if (rv) rv.textContent = _updInfo.remote_ver || ("v" + (_updInfo.remote_vc || "?"));
  if (lv) lv.textContent = _updInfo.local_ver || ("versionCode " + (_updInfo.local_vc || "?"));

  const log = $("#updChangelog");
  if (log){
    const txt = (_updInfo.changelog || "").trim();
    if (txt){
      log.style.display = "";
      log.textContent = txt;
    } else {
      log.style.display = "none";
    }
  }
  el.classList.add("show");
}

function hideUpdate(){
  const el = $("#updLock");
  if (el) el.classList.remove("show");
}

/** 检查远程版本：需要更新则弹窗 */
async function checkUpdate(){
  let info;
  try {
    /* notice.get 只读本地缓存，不需要网络，给 25 秒余量 */
    info = await api("notice.get", 25000);
  } catch (e) {
    return;  /* 公告未启用或读取失败，不影响主流程 */
  }
  if (!info || info.need_update !== true) {
    hideUpdate();
    return;
  }
  showUpdate(info);

  /* 绑定按钮（只绑一次） */
  /* 立即在线更新：调 action.sh update 直接下载安装 */
  const now = $("#updNow");
  if (now && !now._bound){
    now._bound = true;
    now.onclick = async () => {
      const old = now.textContent;
      now.textContent = "更新中，请勿退出…";
      now.disabled = true;
      try {
        const r = await api("update", 300000);
        toast("更新完成，请重启设备");
        hideUpdate();
      } catch (e) {
        toast("更新失败：" + (e.message || "网络异常"), true);
      } finally {
        now.textContent = old;
        now.disabled = false;
      }
    };
  }

  const dl = $("#updDownload");
  if (dl && !dl._bound){
    dl._bound = true;
    dl.onclick = () => {
      const u = (_updInfo && _updInfo.url) || "";
      if (!u){
        toast("作者尚未提供下载地址");
        return;
      }
      /* WebUI 内用系统浏览器打开 */
      try {
        window.open(u, "_blank");
      } catch (e) {
        const a = document.createElement("a");
        a.href = u; a.target = "_blank"; a.rel = "noopener";
        document.body.appendChild(a); a.click(); a.remove();
      }
    };
  }

  const rc = $("#updRecheck");
  if (rc && !rc._bound){
    rc._bound = true;
    rc.onclick = async () => {
      const old = rc.textContent;
      rc.textContent = "检查中…";
      rc.disabled = true;
      try {
        const n = await api("notice.fetch", 60000);
        if (n && n.need_update === true){
          showUpdate(n);
          toast("仍有新版本");
        } else {
          hideUpdate();
          toast("已是最新版本");
          refresh();
        }
      } catch (e) {
        toast("检查失败：" + (e.message || "网络异常"));
      } finally {
        rc.textContent = old;
        rc.disabled = false;
      }
    };
  }
}

/* ============ 启动 ============ */
async function boot(){
  try { bind(); } catch (e) { /* 个别控件缺失不应阻断后续流程 */ }
  /* 远程版本检查与数据加载互相独立：
     数据加载超时/失败时也要能弹出更新窗口，所以不 await 它 */
  checkUpdate().catch(() => {});
  try {
    await loadAll(true);
  } catch (e) {
    /* 加载失败由 loadAll 内部处理，这里只兜底，避免中断后续逻辑 */
  }
}

/**
 * 加载全部数据
 *   full=true  ：先试 overview（一次拿全）
 *   overview 失败：退化为分步取 auth / runtime / conf
 */
async function loadAll(first){
  // 阶段 1：尝试 overview（带重试）
  for (let i = 0; i < 2; i++){
    try {
      await refresh();
      paintRetry(false);
      return;
    } catch (e) {
      if (i === 0) await new Promise(r => setTimeout(r, 350));
    }
  }

  // 阶段 2：分步兜底
  const st = { auth: null, okAuth: false, okRt: false };

  try {
    st.auth = await api("auth.status");
    st.okAuth = true;
  } catch (e) { /* 授权状态都拿不到 */ }

  // 授权状态拿到了就先定调，绝不误弹未授权
  if (st.okAuth && st.auth){
    if (st.auth.ok === true){
      setBadge("已授权", "ok");
      showLock(false);
    } else {
      setBadge("未授权", "warn");
      showLock(true, st.auth.device, st.auth);
    }
    try { renderAuth(st.auth); } catch (e) {}
  }

  // 试着单独取运行时（可能有独立命令，没有就跳过）
  let o = null;
  try {
    o = await api("overview");
    st.okRt = true;
  } catch (e) { /* 仍失败 */ }

  if (o){
    await applyOverview(o);
    paintRetry(false);
    return;
  }

  // 完全拿不到运行时数据
  paintDegraded(st);
}

/** 异步拉取自检结果并填充首页卡片 */
async function loadSelfcheck(){
  const body = document.querySelector("#scBody");
  const sub = document.querySelector("#scSub");
  if (!body) return;
  try {
    const d = await api("selfcheck");
    const items = (d && d.items) || [];
    if (!items.length){
      body.innerHTML = '<div style="padding:12px 0;color:var(--text-3);font-size:12px">无自检数据</div>';
      if (sub) sub.textContent = "—";
      return;
    }
    const ok = items.filter(x => x.state === "OK").length;
    const bad = items.filter(x => x.state === "FAIL").length;
    if (sub) sub.textContent = ok + " 正常" + (bad ? " · " + bad + " 异常" : "");

    let html = "";
    items.slice(0, 7).forEach(it => {
      const col = STATE_COLOR[it.state] || "var(--text-3)";
      const cls = STATE_CLASS[it.state] || "skip";
      html += `<div class="row">
        <span style="width:8px;height:8px;border-radius:50%;flex:0 0 auto;background:${col}"></span>
        <span class="k">${esc(it.name || it.key)}</span>
        <span class="v ${cls}" style="max-width:56%;font-size:12px">${esc(it.msg || it.detail || "")}</span>
      </div>`;
    });
    body.innerHTML = html;
  } catch (e) {
    body.innerHTML = '<div style="padding:12px 0;color:var(--red);font-size:12px">自检读取失败：'
      + esc(e.message) + '</div>';
    if (sub) sub.textContent = "读取失败";
  }
}

/** 应用 overview 数据（refresh 内部复用） */
async function applyOverview(o){
  if (o && o.auth && o.auth.data && typeof o.auth.ok === "boolean"){
    o.auth = o.auth.data;
  }
  app.overview = o;
  const a = o.auth || {};

  $("#verLine").textContent = (o.version || "—") + " · " + (o.author || "");

  if (a.ok){
    setBadge(a.expire ? (a.days_left + " 天") : "已授权", "ok");
    showLock(false);
  } else {
    setBadge("未授权", "warn");
    showLock(true, a.device, a);
  }

  renderHome(o);
  renderGuard(o);
  renderConf(o.conf || {});
  renderFpValues(o);
  renderAuth(a);

  // 自检独立拉取，不阻塞首页
  loadSelfcheck();
}

/** 降级界面：显示已知的授权信息 + 重试按钮 */
function paintDegraded(st){
  const hl = $("#homeLoading");
  const hb = $("#homeBody");
  if (hb) hb.style.display = "none";
  if (!hl) return;

  const authTxt = (st.okAuth && st.auth)
    ? (st.auth.ok ? ("✓ " + (st.auth.plan || "已授权")) : "⚠️ 未授权")
    : "授权状态未知";

  hl.innerHTML =
    '<div style="text-align:center;padding:26px 16px">' +
      '<div style="font-size:14px;font-weight:600;margin-bottom:8px">' + esc(authTxt) + '</div>' +
      '<div style="font-size:12.5px;color:var(--text-2);line-height:1.7;margin-bottom:16px">' +
        '运行时数据读取超时。<br>模块可能仍在运行，请稍后重试。' +
      '</div>' +
      '<button class="btn btn-sm primary" id="btnRetryLoad" style="min-width:140px">重新加载</button>' +
    '</div>';
  hl.style.display = "";

  const b = document.querySelector("#btnRetryLoad");
  if (b) b.onclick = async () => {
    b.disabled = true;
    b.textContent = "加载中…";
    try { await loadAll(false); }
    finally { b.disabled = false; b.textContent = "重新加载"; }
  };
}

/** 在顶部显示/隐藏重试条 */
function paintRetry(show){
  let bar = document.querySelector("#retryBar");
  if (!show){
    if (bar) bar.remove();
    return;
  }
  if (bar) return;
  const main = document.querySelector("main");
  if (!main) return;
  bar = document.createElement("div");
  bar.id = "retryBar";
  bar.style.cssText = "margin:0 0 10px;padding:10px 14px;border-radius:12px;" +
    "background:rgba(255,159,10,.14);border:1px solid rgba(255,159,10,.32);" +
    "font-size:12.5px;display:flex;align-items:center;gap:10px";
  bar.innerHTML = '<span style="flex:1">数据可能不是最新</span>' +
    '<button class="btn btn-sm" id="btnRetryInline">刷新</button>';
  main.insertBefore(bar, main.firstChild);
  const b = bar.querySelector("#btnRetryInline");
  if (b) b.onclick = async () => {
    b.disabled = true; b.textContent = "…";
    try { await loadAll(false); } finally { b.disabled = false; b.textContent = "刷新"; }
  };
}


/* ============ 底栏随滚动收起/浮现 ============ */
function initDockAutoHide(){
  const dock = document.querySelector(".dock");
  if (!dock) return;

  const THRESHOLD = 6;     // 忽略微小抖动
  const TOP_ZONE = 80;     // 顶部区域始终显示

  let lastY = window.scrollY || 0;
  let hidden = false;
  let ticking = false;

  function setHidden(v){
    if (v === hidden) return;
    hidden = v;
    dock.classList.toggle("dock-hidden", v);
  }

  function evaluate(){
    const y = window.scrollY || 0;
    const delta = y - lastY;

    if (y <= TOP_ZONE){
      // 回到顶部：一定显示
      setHidden(false);
    } else if (delta > THRESHOLD){
      // 向下浏览：收起
      setHidden(true);
    } else if (delta < -THRESHOLD){
      // 向上浏览：浮现
      setHidden(false);
    }
    // 滚到底部不做特殊处理：保持隐藏，让最后一个按钮露出来

    lastY = y;
    ticking = false;
  }

  function onScroll(){
    if (ticking) return;
    ticking = true;
    if (typeof requestAnimationFrame === "function"){
      requestAnimationFrame(evaluate);
    } else {
      setTimeout(evaluate, 16);
    }
  }

  window.addEventListener("scroll", onScroll, { passive: true });
  /* iOS 惯性滚动不一定触发 scroll，补 touchend */
  window.addEventListener("touchend", onScroll, { passive: true });

  /* 切换 tab：强制显示并复位基准，避免停在上一次的收起状态 */
  const nav = document.querySelector(".dock");
  if (nav){
    nav.addEventListener("click", () => {
      setHidden(false);
      lastY = window.scrollY || 0;
    });
  }
}

/* ============ 启动 ============ */
function start(){
  initDockAutoHide();
  boot();
}
if (document.readyState === "loading"){
  document.addEventListener("DOMContentLoaded", start);
} else {
  start();
}
