#!/system/bin/sh
# ============================================================
#  ACE Guard 设置存储
#
#  作用：
#    保存模块运行所需的少量配置信息，让模块在升级后仍能
#    记住当前状态，不需要你重新设置。
#
#  用户须知：
#    · 保存的信息包括当前版本标识与完整性校验值
#    · 这些信息不影响你的个人数据，也不包含隐私内容
#    · 升级模块时这些设置会保留，卸载模块时自动清除
# ============================================================

AG_CFG_KSud="/data/adb/ksu/bin/ksud"
AG_CFG_ID="ace_guard"
AG_CFG_FALLBACK="${MODDIR:-/data/adb/modules/ace_guard}/data/.installed"

# ksud 配置系统是否可用（每个进程只探测一次）
AG_CFG_AVAILABLE=""

# 探测 ksud module config 是否可用
ag_cfg_probe() {
    [ -n "$AG_CFG_AVAILABLE" ] && return 0
    AG_CFG_AVAILABLE="0"
    [ -x "$AG_CFG_KSud" ] || return 1
    # 能列出（哪怕是空）就算可用
    if "$AG_CFG_KSud" module config --internal "$AG_CFG_ID" list >/dev/null 2>&1; then
        AG_CFG_AVAILABLE="1"
        return 0
    fi
    return 1
}

# 读配置：$1=key
ag_cfg_get() {
    _k="$1"
    if ag_cfg_probe; then
        _v=$("$AG_CFG_KSud" module config --internal "$AG_CFG_ID" get "$_k" 2>/dev/null)
        [ -n "$_v" ] && { printf '%s' "$_v"; return 0; }
    fi
    # 回退：键值文件
    if [ -f "$AG_CFG_FALLBACK" ]; then
        _v=$(/system/bin/sed -n "s/^${_k}=//p" "$AG_CFG_FALLBACK" 2>/dev/null | head -n1)
        [ -n "$_v" ] && { printf '%s' "$_v"; return 0; }
    fi
    return 1
}

# 写配置：$1=key $2=value
ag_cfg_set() {
    _k="$1"; _v="$2"
    if ag_cfg_probe; then
        "$AG_CFG_KSud" module config --internal "$AG_CFG_ID" set "$_k" "$_v" >/dev/null 2>&1 \
            && return 0
    fi
    # 回退：键值文件
    _dir=$(/system/bin/toybox dirname "$AG_CFG_FALLBACK" 2>/dev/null)
    mkdir -p "$_dir" 2>/dev/null
    if [ -f "$AG_CFG_FALLBACK" ] && /system/bin/grep -q "^${_k}=" "$AG_CFG_FALLBACK" 2>/dev/null; then
        /system/bin/sed -i "s|^${_k}=.*|${_k}=${_v}|" "$AG_CFG_FALLBACK" 2>/dev/null
    else
        printf '%s=%s\n' "$_k" "$_v" >> "$AG_CFG_FALLBACK" 2>/dev/null
    fi
    chmod 600 "$AG_CFG_FALLBACK" 2>/dev/null
    return 0
}

# 删配置：$1=key
ag_cfg_del() {
    _k="$1"
    if ag_cfg_probe; then
        "$AG_CFG_KSud" module config --internal "$AG_CFG_ID" delete "$_k" >/dev/null 2>&1
    fi
    [ -f "$AG_CFG_FALLBACK" ] && \
        /system/bin/sed -i "/^${_k}=/d" "$AG_CFG_FALLBACK" 2>/dev/null
    return 0
}

# ============================================================
#  卡片描述覆盖（免改 module.prop）
# ============================================================
# KernelSU 官方支持 override.description：设置后管理器直接用这个值
# 替换 module.prop 的 description，不需要也不应该去改 module.prop。
ag_cfg_set_desc() {
    _d="$1"
    if ag_cfg_probe; then
        "$AG_CFG_KSud" module config --internal "$AG_CFG_ID" set override.description "$_d" \
            >/dev/null 2>&1 && return 0
    fi
    return 1
}

ag_cfg_clear_desc() {
    if ag_cfg_probe; then
        "$AG_CFG_KSud" module config --internal "$AG_CFG_ID" delete override.description \
            >/dev/null 2>&1
        return 0
    fi
    return 1
}

# ============================================================
#  版本号：从 module.prop 迁到配置系统
# ============================================================

# 读 module.prop 里的 versionCode（原始值）
ag_cfg_prop_vc() {
    _mp="${MODDIR:-/data/adb/modules/ace_guard}/module.prop"
    /system/bin/sed -n 's/^versionCode=//p' "$_mp" 2>/dev/null | head -n1 | /system/bin/toybox tr -dc '0-9'
}

# 读 module.prop 里的 version 字符串
ag_cfg_prop_ver() {
    _mp="${MODDIR:-/data/adb/modules/ace_guard}/module.prop"
    /system/bin/sed -n 's/^version=//p' "$_mp" 2>/dev/null | head -n1
}

# 已安装版本号
#   基准值：首次安装时从 module.prop 固化进配置，之后作为防篡改参照。
#   版本新旧判定以远程 version.json 为准，配置值只用于检测 prop 是否被改动。
ag_cfg_installed_vc() {
    _v=$(ag_cfg_get "installed.versionCode" 2>/dev/null)
    case "$_v" in
        ''|*[!0-9]*)
            _p=$(ag_cfg_prop_vc)
            case "$_p" in ''|*[!0-9]*) _p=0 ;; esac
            if [ "$_p" -gt 0 ]; then
                ag_cfg_set "installed.versionCode" "$_p"
                ag_cfg_set "installed.version" "$(ag_cfg_prop_ver)"
                ag_cfg_set "installed.prop_mtime" "$(ag_cfg_prop_mtime)"
            fi
            printf '%s' "$_p"
            return 0 ;;
    esac
    printf '%s' "$_v"
}


# module.prop 的修改时间
ag_cfg_prop_mtime() {
    _mp="${MODDIR:-/data/adb/modules/ace_guard}/module.prop"
    /system/bin/toybox stat -c %Y "$_mp" 2>/dev/null || echo 0
}

# 版本一致性检查：永远返回一致
#   版本比对由远程清单负责，本地不做防篡改判定
ag_cfg_verify_prop() {
    return 0
}
AG_TAMPER_LOG="${AG_NOTICE_DIR:-/data/adb/ace_guard/notice}/tamper.log"


# module.prop 篡改检测
#   以远程版本清单为唯一版本基准：
#     · prop 版本等于远程版本，或向远程版本靠拢（升级/降级对齐）→ 采纳为新基线，不算篡改
#     · prop 版本与远程版本无关地改动（例如改成 999）→ 判定篡改并回退
ag_cfg_guard_prop() {
    _cfg=$(ag_cfg_get "installed.versionCode" 2>/dev/null)
    [ -n "$_cfg" ] || return 0
    _prop=$(ag_cfg_prop_vc)
    [ "$_cfg" = "$_prop" ] && return 0

    _mp="${MODDIR:-/data/adb/modules/ace_guard}/module.prop"

    # 远程版本：与 prop 一致即视为正常升级，采纳并刷新基线
    _remote=$(/system/bin/sed -n 's/.*"versionCode"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p' \
        "${AG_NOTICE_DIR:-/data/adb/ace_guard/notice}/version.json" 2>/dev/null | head -n1)
    case "$_remote" in ''|*[!0-9]*) _remote=0 ;; esac

    if [ "$_remote" -gt 0 ] && [ "$_prop" = "$_remote" ]; then
        ag_cfg_set "installed.versionCode" "$_prop"
        ag_cfg_set "installed.version" "$(ag_cfg_prop_ver)"
        ag_cfg_set "installed.prop_mtime" "$(ag_cfg_prop_mtime)"
        echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') UPGRADE_ACCEPTED versionCode ${_cfg}->${_prop} (与远程一致)" \
            >> "$AG_TAMPER_LOG" 2>/dev/null
        if [ -f "${MODDIR:-/data/adb/modules/ace_guard}/.module.prop.orig" ]; then
            /system/bin/sed -i "s|^versionCode=.*|versionCode=${_prop}|" \
                "${MODDIR:-/data/adb/modules/ace_guard}/.module.prop.orig" 2>/dev/null
            _nv=$(ag_cfg_prop_ver)
            [ -n "$_nv" ] && /system/bin/sed -i "s|^version=.*|version=${_nv}|" \
                "${MODDIR:-/data/adb/modules/ace_guard}/.module.prop.orig" 2>/dev/null
        fi
        return 0
    fi

    mkdir -p /data/adb/ace_guard/notice 2>/dev/null
    echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') TAMPER versionCode ${_cfg}->${_prop} (应为 ${_cfg}，实际 ${_prop})" \
        >> "$AG_TAMPER_LOG" 2>/dev/null

    command -v ag_log >/dev/null 2>&1 && \
        ag_log WARN "检测到 module.prop 版本号被修改：$_prop（应为 $_cfg），已强制回退"

    if [ -f "$_mp" ]; then
        /system/bin/sed -i "s|^versionCode=.*|versionCode=${_cfg}|" "$_mp" 2>/dev/null

        _cfgver=$(ag_cfg_get "installed.version" 2>/dev/null)
        if [ -n "$_cfgver" ]; then
            /system/bin/sed -i "s|^version=.*|version=${_cfgver}|" "$_mp" 2>/dev/null
        fi

        _now=$(ag_cfg_prop_vc)
        if [ "$_now" = "$_cfg" ]; then
            echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') REVERTED to $_cfg" \
                >> "$AG_TAMPER_LOG" 2>/dev/null
            if [ -f "${MODDIR:-/data/adb/modules/ace_guard}/.module.prop.orig" ]; then
                /system/bin/sed -i "s|^versionCode=.*|versionCode=${_cfg}|" \
                    "${MODDIR:-/data/adb/modules/ace_guard}/.module.prop.orig" 2>/dev/null
                [ -n "$_cfgver" ] && /system/bin/sed -i "s|^version=.*|version=${_cfgver}|" \
                    "${MODDIR:-/data/adb/modules/ace_guard}/.module.prop.orig" 2>/dev/null
            fi
            return 1
        fi
        return 2
    fi
    return 2
}


# 篡改记录最近 N 条
ag_cfg_tamper_log() {
    [ -f "$AG_TAMPER_LOG" ] || return 0
    /system/bin/toybox tail -n "${1:-20}" "$AG_TAMPER_LOG" 2>/dev/null
}
