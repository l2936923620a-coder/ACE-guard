#!/system/bin/sh
# ============================================================
#  ACE Guard 开机入口
#
#  【卸载拦截 —— 必须在最前面】
#  KernelSU 点击「卸载」只创建 remove 标记，不会执行 uninstall.sh。
#  本模块在 post-fs-data 阶段主动检测该标记，
#  先跑完整清理，再让 KSU 在后续阶段删除模块目录。
#
#  正常启动流程：
#    1. 卸载拦截（remove 标记存在 → 清理后退出）
#    2. 授权闸门 + module.prop 刷新
#    3. 真机指纹快照（必须在指纹注入之前）
#    4. 未授权 → 退出；已授权 → 指纹注入 + 残留清理
# ============================================================

# ---------- 卸载拦截（务必第一个执行）----------
_AG_SELF=$(/system/bin/toybox readlink -f "$0")
_AG_MODDIR=$(/system/bin/toybox dirname "$_AG_SELF")

# ---------- 权限自愈（安装/更新后 zip 解压不保留 Unix 权限位）----------
if [ -d "$_AG_MODDIR" ]; then
    for _f in "$_AG_MODDIR/lib/agcore" "$_AG_MODDIR/lib/agcfg"; do
        [ -f "$_f" ] && [ ! -x "$_f" ] && chmod 755 "$_f" 2>/dev/null
    done
    for _f in "$_AG_MODDIR"/*.sh "$_AG_MODDIR"/bin/*.sh "$_AG_MODDIR"/script/*.sh; do
        [ -f "$_f" ] && [ ! -x "$_f" ] && chmod 755 "$_f" 2>/dev/null
    done
    mkdir -p "$_AG_MODDIR/log" "$_AG_MODDIR/data" "$_AG_MODDIR/data/run" 2>/dev/null
fi

if [ -f "$_AG_MODDIR/remove" ]; then
    echo "[ace_guard] 检测到卸载标记，开始清理残留..." >&2
    /system/bin/sh "$_AG_MODDIR/uninstall.sh" >/dev/null 2>&1
    echo "[ace_guard] 清理完成，等待 KSU 删除模块目录" >&2
    exit 0
fi

MODDIR="$_AG_MODDIR"

. "$MODDIR/script/common.sh"
. "$MODDIR/script/clean.sh"

ag_load_conf

# ---------- 授权子系统 ----------
. "$MODDIR/script/auth.sh"

# 1) 真机指纹快照：首次安装建立，之后不再覆盖。
#    此处系统属性还是真机值（post-fs-data 阶段尚未注入），是最佳采集时机。
ag_auth_snapshot_init

# 2) 授权校验 + 刷新 KSU 卡片文案
ag_auth_validate_silent

# 2.5) 检测 module.prop 是否被篡改（发现即回退）
command -v ag_cfg_guard_prop >/dev/null 2>&1 && {
    ag_cfg_guard_prop >/dev/null 2>&1
    [ $? = 1 ] && ag_log WARN "开机检测：module.prop 版本号被篡改，已自动回退"
}
ag_auth_update_prop 2>/dev/null

# 3) 卡片文案守护（独立进程，setsid 脱离父进程组）。
#    放在未授权分支之前，保证无论授权与否都会持续同步 KSU 卡片。
/system/bin/sh "$MODDIR/bin/ag_prop_daemon.sh" start >/dev/null 2>&1

# 3.5) 远程版本闸门：有新版本则冻结（终止全部进程 + 还原挂载）
. "$MODDIR/script/notice.sh"

# 启动时先按当前本地版本复核一次，清掉可能残留的过期标记
_sig_now=$(ag_notice_local_sig)
_sig_old=$(cat "$AG_NOTICE_DIR/.local_sig" 2>/dev/null)
if [ "$_sig_now" != "$_sig_old" ] && ag_notice_state_load 2>/dev/null; then
    ag_notice_evaluate >/dev/null 2>&1
fi

# 拉起远程版本监控（冻结时必须存活，否则无法自动解冻）
ag_start_notice_monitor() {
    [ -n "${NOTICE_URL:-}" ] || return 0
    _md="$MODDIR"
    _np="$MODDIR/data/run/notice.pid"

    # 单实例：已有存活监控进程则直接返回
    if [ -f "$_np" ]; then
        _oldp=$(/system/bin/toybox cat "$_np" 2>/dev/null | /system/bin/toybox tr -dc '0-9')
        if [ -n "$_oldp" ] && [ -d "/proc/$_oldp" ]; then
            _ol=$(/system/bin/toybox cat "/proc/$_oldp/cmdline" 2>/dev/null | /system/bin/toybox tr '\0' ' ')
            case "$_ol" in
                *notice_monitor*|*ag_notice_daemon*) return 0 ;;
            esac
        fi
        rm -f "$_np" 2>/dev/null
    fi

    mkdir -p "$MODDIR/data/run" "$LOG_DIR" 2>/dev/null

    # 必须是单行命令：ps 里能看到 ag_role=notice_monitor 标识，冻结时才不会被误杀
    _script="MODDIR='$_md'; export MODDIR; . '$_md/script/common.sh' 2>/dev/null; . '$_md/script/notice.sh' 2>/dev/null; ag_load_conf; ag_role=notice_monitor; ag_notice_daemon"
    if command -v setsid >/dev/null 2>&1; then
        setsid /system/bin/sh -c "$_script" </dev/null >>"$LOG_DIR/service.log" 2>&1 &
    else
        nohup /system/bin/sh -c "$_script" </dev/null >>"$LOG_DIR/service.log" 2>&1 &
    fi

    # 等它写出 pid，确认真的起来了
    _i=0
    while [ "$_i" -lt 10 ]; do
        _i=$(( _i + 1 ))
        /system/bin/sleep 1
        if [ -f "$_np" ]; then
            _newp=$(/system/bin/toybox cat "$_np" 2>/dev/null | /system/bin/toybox tr -dc '0-9')
            [ -n "$_newp" ] && [ -d "/proc/$_newp" ] && return 0
        fi
    done
    return 1
}
ag_start_notice_monitor

if ag_notice_need_update; then
    # 已冻结且远程版本未变则不重复杀进程
    _need_freeze=1
    if [ -f "$AG_FREEZE_MARK" ]; then
        _prevvc=$(/system/bin/sed -n 's/^REMOTE_VC=//p' "$AG_FREEZE_FLAG" 2>/dev/null | head -n1)
        case "$_prevvc" in ''|*[!0-9]*) _prevvc=0 ;; esac
        _curvc=$(ag_notice_json_get "$AG_NOTICE_JSON" versionCode num 2>/dev/null)
        case "$_curvc" in ''|*[!0-9]*) _curvc=0 ;; esac
        [ -n "$_prevvc" ] && [ "$_prevvc" = "$_curvc" ] && _need_freeze=0
    fi
    if [ "$_need_freeze" = "1" ]; then
        ag_log WARN "检测到新版本 $AG_N_REMOTE_VER（$AG_N_REMOTE_VC > 本地 $(ag_notice_local_vc)），执行冻结"
        ag_freeze_all "postfs_gate" 2>/dev/null
    fi
    ag_auth_update_prop 2>/dev/null
    ag_start_notice_monitor
    exit 0
fi

if [ "$AG_AUTH_OK" != "1" ]; then
    ag_log WARN "未授权：跳过指纹注入与清理（设备码 $(ag_auth_device_id) / $AG_AUTH_REASON）"
    exit 0
fi

ag_log INFO "授权通过：$(ag_auth_plan_text)"

until [ "$(/system/bin/getprop sys.boot_completed 2>/dev/null)" = "1" ]; do
    /system/bin/sleep 2
done
/system/bin/sleep 15

# 3) 指纹
if [ "$ENABLE_IDENTITY" = "1" ]; then
    if [ "$ROTATE_ON_BOOT" = "1" ]; then
        ag_log INFO "开机轮换指纹"
        ag_identity_generate
    else
        ag_identity_ensure
    fi
    ag_identity_apply
fi

# 4) 清理上次运行残留
[ "$ENABLE_EXIT_CLEAN" = "1" ] && {
    ag_clean_game_private
    ag_clean_system
}

# 5) 云端上报（AUTH_URL 为空时内部直接返回，不发请求）
ag_auth_upload_cloud "boot"

# 6) 注入完成后再次同步卡片，防止 3/4 步耗时导致状态滞后
ag_auth_update_prop 2>/dev/null

ag_log INFO "post-fs-data 完成 SERIAL=$AG_SERIAL"
