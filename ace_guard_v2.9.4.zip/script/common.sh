#!/system/bin/sh
# ============================================================
#  ACE Guard 公共函数库
# ============================================================

MODDIR="${MODDIR:-/data/adb/modules/ace_guard}"
# 四款游戏包名表（多游戏支持），必须在使用前加载
[ -f "$MODDIR/script/games.sh" ] && . "$MODDIR/script/games.sh"
DATA_DIR="$MODDIR/data"
# 配置以加密形式保存，运行时解密后加载
CONF_ENC="$MODDIR/config/guard.dat"
CONF="$MODDIR/config/guard.conf"
LOG_DIR="$MODDIR/log"
LOG_FILE="$LOG_DIR/guard.log"
AGCFG_BIN="$MODDIR/lib/agcfg"


RESETPROP=""
ag_find_resetprop() {
    [ -n "$RESETPROP" ] && [ -x "$RESETPROP" ] && return 0
    for r in /data/adb/ksu/bin/resetprop /data/adb/magisk/resetprop; do
        [ -x "$r" ] && { RESETPROP="$r"; return 0; }
    done
    RESETPROP=$(command -v resetprop 2>/dev/null)
    [ -n "$RESETPROP" ] && return 0
    return 1
}

# ---------- 配置 ----------
ag_load_conf() {
    # 优先从加密配置加载；解密后的内容只存在于当前进程内存
    if [ -x "$AGCFG_BIN" ] && [ -f "$CONF_ENC" ]; then
        _conf_text=$("$AGCFG_BIN" "$CONF_ENC" 2>/dev/null)
        if [ -n "$_conf_text" ]; then
            eval "$_conf_text" 2>/dev/null
        elif [ -f "$CONF" ]; then
            . "$CONF" 2>/dev/null
        fi
    elif [ -f "$CONF" ]; then
        . "$CONF" 2>/dev/null
    fi
    : "${ENABLE_IDENTITY:=1}"
    : "${SERIAL_MODE:=auto}"
    : "${CHIPECID_LEN:=16}"
    : "${ROTATE_ON_BOOT:=0}"
    : "${IMEI_PREFIX:=86916}"
    # 方案C：只保留真正影响检测的核心属性。
    # ro.ril.oem.* 是构建期只读属性（改了也仅内存态，检测通常不读取），
    # 已从默认列表移除，需要时可通过 guard.conf 追加。
    : "${IMEI_PROPS:=persist.radio.imei persist.radio.imei1 persist.radio.imei2 persist.radio.imei9 ril.gsm.imei gsm.serial}"
    # GSM 基带序列号属性（21 位混合串，含字母，格式与普通序列号不同，单独覆盖）
    : "${GSMSERIAL_PROPS:=vendor.gsm.serial ro.vendor.gsm.serial}"
    # 厂商自带的冗余序列号属性（不覆盖会泄露真机序列号）
    : "${SERIAL_PROPS:=ro.vendor.oplus.radio.serialno vendor.oplus.caihong.serialno persist.sys.oplus.serialno}"
    : "${ENABLE_ADID:=1}"
    : "${OWN_IDENTITY:=1}"
    : "${ENABLE_DRMID:=1}"
    : "${DRMID_INTERVAL:=15}"
    : "${ENABLE_MONITOR:=1}"
    : "${ENABLE_AUTO_PURGE:=1}"
    : "${MONITOR_INTERVAL:=5}"
    : "${ALERT_MODE:=both}"
    : "${COUNTER_ACTIONS:=purge rehide}"
    : "${LOG_LEVEL:=1}"
    : "${LOG_MAX_KB:=512}"
    : "${HIDE_MODULES:=kernelsu}"
    : "${PKG:=com.tencent.tmgp.codev}"
    # 四款游戏包名表（多游戏支持）
    : "${RISK_DIRS:=}"
    : "${CACHE_RISK_SUB:=}"
    : "${KILL_PROCS:=}"
    : "${ACCUSE_DIRS:=}"
    : "${LOCK_DIRS:=}"
    : "${ACCUSE_PATTERNS:=}"
    : "${GUARD_INTERVAL:=20}"
    : "${ENABLE_GUARD:=1}"
    : "${ENABLE_GREEN_LOCK:=1}"
    : "${GREEN_CHECK_INTERVAL:=12}"
    : "${ENABLE_NET_BLOCK:=0}"
    : "${BLOCK_KEYWORDS:=}"
    : "${BLOCK_DOMAINS:=}"
    : "${BLOCK_PORTS:=}"
    : "${HOUSEKEEPING_INTERVAL:=20}"
    : "${ENABLE_KILL_PROBE:=1}"
    : "${ENABLE_BEHAVIOR_MASK:=1}"
    : "${ENABLE_LOG_BLOCK:=1}"
    : "${ENABLE_ANTIDEBUG:=1}"
    : "${SHADOW_DIRS:=}"
    : "${ENABLE_SHADOW:=1}"
    : "${LIFECYCLE_INTERVAL:=5}"
    # 状态缓存有效期跟随生命周期轮询
    AG_STATE_TTL="${LIFECYCLE_INTERVAL:-5}"
    : "${ENABLE_PURGE_WATCH:=1}"
    : "${PURGE_PATTERNS:=*accuse*.tmp *report*.snap *remote*.cfg *patch*.tmp *policy*.dat *blacklist*.bin *rules*.bin}"
    : "${PURGE_DIRS:=accuse_data report_upload replay_cache remote_cfg dynamic_rule patch_temp user_report}"
    : "${PURGE_MAXDEPTH:=2}"
    : "${ENABLE_SELFCHECK_BOOT:=1}"
    # 扩展隐藏层（移植自封神榜隐藏环境模块，五项独立开关，默认关闭）
    : "${ENABLE_EXT_BINDMOUNT:=0}"
    : "${ENABLE_EXT_OVERLAY:=0}"
    : "${ENABLE_EXT_SECCOMP:=1}"
    : "${ENABLE_EXT_PROCFAKE:=1}"
    : "${EXT_POLL_INTERVAL:=10}"
    ag_find_resetprop
}

# ---------- 日志 ----------
ag_log() {
    [ "$LOG_LEVEL" -ge 1 ] || return 0
    local lvl="$1"; shift
    local ts
    ts=$(/system/bin/date '+%m-%d %H:%M:%S' 2>/dev/null)
    echo "[$ts][$lvl] $*" >> "$LOG_FILE" 2>/dev/null
    local sz
    sz=$(/system/bin/stat -c %s "$LOG_FILE" 2>/dev/null)
    if [ -n "$sz" ] && [ "$sz" -gt $((LOG_MAX_KB * 1024)) ]; then
        /system/bin/toybox mv -f "$LOG_FILE" "$LOG_FILE.old" 2>/dev/null
    fi
}

ag_log_debug() { [ "$LOG_LEVEL" -ge 2 ] && ag_log DEBUG "$@"; return 0; }

# ---------- 告警 ----------
ag_alert() {
    ag_log ALERT "$1"
    case "$ALERT_MODE" in
        toast|both)
            /system/bin/cmd notification post -S bigtext -t "ACE Guard" ag_alert "1" "$1" \
                >/dev/null 2>&1
            ;;
    esac
}

# ---------- 随机 ----------
ag_rbyte() {
    /system/bin/toybox od -An -N1 -tu1 /dev/urandom 2>/dev/null | /system/bin/toybox tr -d ' \r\n'
}

ag_rfrom() {
    local chars="$1" b n i
    b=$(ag_rbyte)
    case "$b" in ''|*[!0-9]*) return 1 ;; esac
    n=${#chars}
    i=$((b % n))
    printf '%s' "$chars" | /system/bin/cut -c "$((i+1))"
}

AG_UP="ABCDEFGHJKLMNPRSTUVWXYZ"
AG_UPALL="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
AG_LO="abcdefghijkmnopqrstuvwxyz"
AG_NUM="0123456789"

# ---------- IMEI (Luhn) ----------
ag_imei_check() {
    local body="$1" sum=0 i d
    i=1
    while [ "$i" -le 14 ]; do
        d=$(printf '%s' "$body" | /system/bin/cut -c "$i")
        d=$((d + 0))
        if [ $((i % 2)) -eq 0 ]; then
            d=$((d * 2))
            [ "$d" -gt 9 ] && d=$((d - 9))
        fi
        sum=$((sum + d))
        i=$((i + 1))
    done
    echo $(( (10 - (sum % 10)) % 10 ))
}

ag_gen_imei() {
    local prefix="${1:-86916}" body i d chk
    body="$prefix"
    i=$((${#prefix} + 1))
    while [ "$i" -le 14 ]; do
        d=$(ag_rfrom "$AG_NUM") || return 1
        body="${body}${d}"
        i=$((i + 1))
    done
    chk=$(ag_imei_check "$body")
    printf '%s%s' "$body" "$chk"
}

ag_valid_imei() {
    printf '%s\n' "$1" | /system/bin/grep -Eq '^[0-9]{15}$' || return 1
    local body actual expect
    body=$(printf '%s' "$1" | /system/bin/cut -c1-14)
    actual=$(printf '%s' "$1" | /system/bin/cut -c15)
    expect=$(ag_imei_check "$body")
    [ "$actual" = "$expect" ]
}

# ---------- 序列号 ----------
# 探测本机真实序列号格式，决定生成策略
ag_detect_serial_len() {
    local real
    real=$(/system/bin/getprop ro.boot.serialno 2>/dev/null)
    local n=${#real}
    case "$n" in
        8|16) echo "$n" ;;
        *) echo 8 ;;
    esac
}

ag_gen_serial() {
    local mode="${1:-auto}"
    [ "$mode" = "auto" ] && mode=$(ag_detect_serial_len)

    local b1 b2 out
    b1=$(ag_rbyte); b2=$(ag_rbyte)
    case "$b1" in ''|*[!0-9]*) return 1 ;; esac
    case "$b2" in ''|*[!0-9]*) return 1 ;; esac

    if [ "$mode" = "16" ]; then
        # 对齐 OnePlus/Oppo 16 位结构:
        #   [数字+大写字母][4位数字][W+2数字][2大写字母+数字][4位数字]
        local p1 p2 p3 p4 p5
        p1="$(printf '%d' $((b1 % 9 + 1)))$(ag_rfrom "$AG_UP")"
        p2="$(printf '%04d' $(( (b1 * 97 + b2) % 9000 + 1000 )))"
        p3="W$(printf '%02d' $((b2 % 90 + 10)))"
        p4="$(ag_rfrom "$AG_UP")$(ag_rfrom "$AG_UP")$((b1 % 10))"
        p5="$(printf '%04d' $(( (b1 * 257 + b2 * 13) % 10000 )))"
        out="${p1}${p2}${p3}${p4}${p5}"
    else
        # 8 位混合
        local i c
        out=""
        i=1
        while [ "$i" -le 8 ]; do
            case $(( (b1 + i) % 3 )) in
                0) c=$(ag_rfrom "23456789$AG_UPALL") ;;
                1) c=$(ag_rfrom "$AG_LO") ;;
                2) c=$(ag_rfrom "$AG_NUM") ;;
            esac
            out="${out}${c}"
            i=$((i + 1))
        done
    fi
    printf '%s' "$out"
}

ag_valid_serial() {
    local v="$1" n=${#1}
    case "$n" in
        8)  printf '%s\n' "$v" | /system/bin/grep -Eq '^[1-9A-Za-z]{8}$' ;;
        16) printf '%s\n' "$v" | /system/bin/grep -Eq \
                '^[1-9][A-Za-z][0-9A-Za-z]{4}[0-9A-Za-z]{3}[0-9A-Za-z]{3}[0-9]{4}$' ;;
        *)  return 1 ;;
    esac
}

# ---------- chipecid ----------
ag_gen_chipecid() {
    local n="${1:-16}"
    /system/bin/toybox od -An -N$((n / 2)) -tx1 /dev/urandom 2>/dev/null \
        | /system/bin/toybox tr -d ' \r\n'
}

ag_valid_chipecid() {
    printf '%s\n' "$1" | /system/bin/grep -Eq "^[0-9a-f]{${2:-16}}$"
}

# ---------- GSM 基带序列号（vendor.gsm.serial，21 位混合串）----------
# 真机格式示例：00248550612222K300026181
#   结构：8位数字 + 1位大写字母 + 6位数字 + 1位大写字母 + 6位数字
#   （字母位置不固定，这里按「数字为主、穿插 1~2 个校验字母」生成，
#     保证长度与字符集对齐，避免被格式探测识破）
ag_gen_gsmserial() {
    local out i c cap
    out=""
    # 前 14 位纯数字
    i=1
    while [ "$i" -le 14 ]; do
        c=$(ag_rfrom "$AG_NUM") || return 1
        out="${out}${c}"
        i=$((i + 1))
    done
    # 第 15 位大写字母（模拟真机的 K 位置）
    cap=$(ag_rfrom "$AG_UPALL") || return 1
    out="${out}${cap}"
    # 后 6 位纯数字
    i=1
    while [ "$i" -le 6 ]; do
        c=$(ag_rfrom "$AG_NUM") || return 1
        out="${out}${c}"
        i=$((i + 1))
    done
    printf '%s' "$out"
}

# GSM 序列号校验：21 位，字母+数字混合
ag_valid_gsmserial() {
    printf '%s\n' "$1" | /system/bin/grep -Eq '^[0-9A-Za-z]{21}$'
}

# ---------- 身份存储（ADID 已并入，实现见 script/identity.sh）----------
# common.sh 被所有脚本首行 source，identity.sh 必须紧随其后，
# 因此这里做一次静默的自举加载；已加载时为空操作。
if ! command -v ag_identity_load >/dev/null 2>&1; then
    for _idf in \
        "${MODDIR:-/data/adb/modules/ace_guard}/script/identity.sh" \
        "/data/adb/modules/ace_guard/script/identity.sh" ; do
        [ -f "$_idf" ] && { . "$_idf" 2>/dev/null; break; }
    done
    unset _idf
fi
# ==== [已废弃] 以下 ag_identity_apply 是历史遗留副本。 ====
# 实际生效的是 script/identity.sh 里的同名函数（common.sh 自举加载会覆盖）。
# 保留此副本仅为不依赖 source 顺序时的兜底，两份已保持同步。
# ---------- 应用指纹（带逐属性变更日志）----------
ag_identity_apply() {
    [ "$ENABLE_IDENTITY" = "1" ] || return 0
    ag_identity_load || return 1
    ag_find_resetprop || { ag_log ERROR "resetprop 不可用"; return 1; }

    local n=0 fail=0 before after key val

    # 真机值对照（首次安装快照）
    local _snap="/data/adb/ace_guard/auth/original_identity"
    if [ -f "$_snap" ]; then
        ag_log INFO "  [真机] SERIAL=$(sed -n 's/^REAL_SERIAL=//p' "$_snap" 2>/dev/null) IMEI=$(sed -n 's/^REAL_IMEI=//p' "$_snap" 2>/dev/null)"
    fi
    ag_log INFO "---------- 指纹应用开始 ----------"

    # 写入单个属性并记录变更
    # $1=属性名 $2=目标值 $3=分类标签
    ag_setprop_logged() {
        key="$1"; val="$2"
        before=$(/system/bin/getprop "$key" 2>/dev/null)

        # 方案C 保护：属性从未存在时禁止创建。
        # 创建新属性会让 prop_area 的 bytes_used 增长且永不回收，
        # 形成"属性区空洞"，被检测工具判定为属性被动态修改过。
        if [ -z "$before" ] && ! /system/bin/getprop 2>/dev/null | /system/bin/grep -q "\[$key\]"; then
            ag_log WARN "  [$3] $key : 属性不存在，跳过（避免属性区空洞）"
            return 0
        fi

        [ -z "$before" ] && before="（空值）"

        if "$RESETPROP" "$key" "$val" >/dev/null 2>&1; then
            n=$((n + 1))
            after=$(/system/bin/getprop "$key" 2>/dev/null)
            if [ "$before" = "$after" ]; then
                ag_log INFO "  [$3] $key : $before （未变）"
            else
                ag_log INFO "  [$3] $key : $before  ->  $after"
            fi
        else
            fail=$((fail + 1))
            ag_log ERROR "  [$3] $key : 写入失败（原值=$before）"
        fi
    }

    # --- 序列号 ---
    # v1.9.6 恢复：游戏会通过系统接口读序列号，两者都需覆盖。
    ag_setprop_logged "ro.serialno"      "$AG_SERIAL" "序列号"
    ag_setprop_logged "ro.boot.serialno" "$AG_SERIAL" "序列号"
    # 厂商冗余序列号（默认属性值会暴露真机身份，一并覆盖）
    for p in $SERIAL_PROPS; do
        [ -n "$p" ] || continue
        ag_setprop_logged "$p" "$AG_SERIAL" "序列号(厂商)"
    done

    # --- GSM 基带序列号（21 位混合串，格式与普通序列号不同，独立生成）---
    local _gsm
    _gsm=$(ag_gen_gsmserial 2>/dev/null)
    if ag_valid_gsmserial "$_gsm"; then
        for p in $GSMSERIAL_PROPS; do
            [ -n "$p" ] || continue
            ag_setprop_logged "$p" "$_gsm" "GSM序列号"
        done
    else
        ag_log WARN "  GSM序列号生成失败，跳过该组覆盖"
    fi

    # --- 芯片 ID ---
    ag_setprop_logged "ro.boot.chipecid" "$AG_CHIPECID" "芯片ID"
    # ro.boot.chipid 是 chipecid 后 8 位，v1.9.6 补：此前漏覆盖，需与 chipecid 一致
    local _chipid8
    _chipid8=$(printf '%s' "$AG_CHIPECID" | /system/bin/cut -c9-16 2>/dev/null)
    [ -n "$_chipid8" ] && ag_setprop_logged "ro.boot.chipid" "$_chipid8" "芯片ID(短)"

    # --- IMEI 组 ---
    local p
    for p in $IMEI_PROPS; do
        [ -n "$p" ] || continue
        ag_setprop_logged "$p" "$AG_IMEI" "IMEI"
    done

    # 兼容：系统里若已存在其它含 imei 的属性，一并覆盖
    #
    # 方案C（v1.7.1）：收窄补充范围。
    #   - 跳过 ro.* 前缀：构建期只读属性，改写仅内存生效，
    #     检测工具通常不读取，写它只会扩大属性写入面。
    #   - 跳过 persist.* 中未在 IMEI_PROPS 白名单里的项。
    #   - 只补写运行时属性（ril.* / gsm.* 等）。
    local extra
    extra=$(/system/bin/getprop 2>/dev/null | /system/bin/grep -i imei \
            | /system/bin/sed -n 's/^\[\([^]]*\)\].*/\1/p')
    for p in $extra; do
        case " $IMEI_PROPS " in
            *" $p "*) continue ;;     # 已在主列表，前面已写
        esac
        case "$p" in
            ro.*)     continue ;;     # 构建期只读属性，跳过
            persist.*) continue ;;    # 持久化属性，只走白名单
            ctl.*)    continue ;;     # 控制块，禁止触碰
        esac
        ag_setprop_logged "$p" "$AG_IMEI" "IMEI补充"
    done

    ag_log INFO "---------- 指纹应用完成: 成功=$n 失败=$fail ----------"
    return 0
}

# ============================================================
#  守护子进程存活检查（v1.9.3）
#
#  背景：service.sh 用 setsid 拉起守护子进程，这是 KSU 的硬性要求
#  （否则 service.sh 执行完子进程会被一起回收）。代价是主进程异常
#  死亡（被 kill -9、崩溃、模块重启）时，子进程会变成 PPID=1 的
#  孤儿继续跑，下次启动再起一套，造成重复扫描/重复挂载叠加。
#
#  做法：每个守护循环每轮调一次 ag_orphan_check，
#        发现父进程已死就自行退出，不再残留。
# ============================================================

# 记录守护子进程启动时的父进程 PID（由 service.sh 的 ag_spawn 注入）
AG_SPAWN_PARENT="${AG_SPAWN_PARENT:-}"

# 判断给定 PID 是否存活
ag_pid_alive() {
    case "$1" in ''|*[!0-9]*) return 1 ;; esac
    [ -d "/proc/$1" ]
}

# 守护循环每轮调用；父进程已死则退出本进程
#   退出码 0 表示应当继续，非 0 表示已调用 exit
ag_orphan_check() {
    # 未注入父 PID（手工调试直接跑函数）时不干预
    [ -n "$AG_SPAWN_PARENT" ] || return 0

    ag_pid_alive "$AG_SPAWN_PARENT" && return 0

    # 再加一道：主 service.sh 一个都不在，也判定为孤儿
    if /system/bin/toybox ps -A -o ARGS 2>/dev/null \
         | /system/bin/grep -qE '^sh /data/adb/modules/ace_guard/service\.sh$'; then
        return 0
    fi

    # 显式落盘：子 shell 里 LOG_FILE 可能为空，ag_log 会静默失败
    _olog="${LOG_FILE:-${MODDIR:-/data/adb/modules/ace_guard}/log/guard.log}"
    mkdir -p "${_olog%/*}" 2>/dev/null
    printf '[%s][WARN] [守护] 主进程 %s 已退出，本子系统自行结束（防孤儿堆积）\n' \
        "$(/system/bin/date '+%m-%d %H:%M:%S')" "$AG_SPAWN_PARENT" >> "$_olog" 2>/dev/null
    exit 0
}

# ============================================================
#  挂载状态精确统计（v1.9.9）
#
#  旧实现把「遮蔽目录」和「锁目录」的挂载混在一起数，
#  导致界面上看到的是笼统的 mount 总数，无法分辨哪类挂了几个。
#  本函数按目录类型分别统计，返回 JSON 片段供自检与 WebUI 共用。
#
#  输出（stdout，键值对，每行一个）：
#    shadow_bound / shadow_total    遮蔽目录（RISK_DIRS + CACHE_RISK_SUB）
#    lock_bound   / lock_total      锁目录（LOCK_DIRS）
#    green_bound  / green_total     配置伪装（ace_config.xml）
# ============================================================
ag_mount_stat() {
    _ms_game_dirs=$(ag_game_dirs 2>/dev/null)
    _ms_shadow_b=0; _ms_shadow_t=0
    _ms_lock_b=0;   _ms_lock_t=0
    _ms_green_b=0;  _ms_green_t=0
    _ms_mounts=$(/system/bin/toybox mount 2>/dev/null)

    _ms_has_mount() {  # $1=路径
        case "$_ms_mounts" in
            *" on $1 "*) return 0 ;;
        esac
        return 1
    }

    for _ms_base in $_ms_game_dirs; do
        [ -d "$_ms_base" ] || continue

        # --- 遮蔽目录：files/<RISK_DIRS> 与 cache/<CACHE_RISK_SUB> ---
        for _ms_d in $RISK_DIRS; do
            [ -n "$_ms_d" ] || continue
            _ms_t="$_ms_base/files/$_ms_d"
            [ -d "$_ms_t" ] || continue
            _ms_shadow_t=$((_ms_shadow_t + 1))
            _ms_has_mount "$_ms_t" && _ms_shadow_b=$((_ms_shadow_b + 1))
        done
        for _ms_d in $CACHE_RISK_SUB; do
            [ -n "$_ms_d" ] || continue
            _ms_t="$_ms_base/cache/$_ms_d"
            [ -d "$_ms_t" ] || continue
            _ms_shadow_t=$((_ms_shadow_t + 1))
            _ms_has_mount "$_ms_t" && _ms_shadow_b=$((_ms_shadow_b + 1))
        done

        # --- 锁目录：files/<LOCK_DIRS>（可能与其他类型重叠，单独计数）---
        for _ms_d in $LOCK_DIRS; do
            [ -n "$_ms_d" ] || continue
            _ms_t="$_ms_base/files/$_ms_d"
            [ -d "$_ms_t" ] || continue
            _ms_lock_t=$((_ms_lock_t + 1))
            _ms_has_mount "$_ms_t" && _ms_lock_b=$((_ms_lock_b + 1))
        done

        # --- 配置伪装 ---
        if [ "${ENABLE_GREEN_LOCK:-1}" = "1" ]; then
            _ms_t="$_ms_base/shared_prefs/ace_config.xml"
            if [ -f "$_ms_t" ]; then
                _ms_green_t=$((_ms_green_t + 1))
                _ms_has_mount "$_ms_t" && _ms_green_b=$((_ms_green_b + 1))
            fi
        fi
    done

    printf 'shadow_bound=%s\n'  "$_ms_shadow_b"
    printf 'shadow_total=%s\n'  "$_ms_shadow_t"
    printf 'lock_bound=%s\n'    "$_ms_lock_b"
    printf 'lock_total=%s\n'    "$_ms_lock_t"
    printf 'green_bound=%s\n'   "$_ms_green_b"
    printf 'green_total=%s\n'   "$_ms_green_t"
}

# ============================================================
#  守护进程精确统计（v2.0.0）
#
#  旧实现靠 ps ARGS 字符串匹配函数名，但 ag_spawn 用 sh -c 传入
#  整段脚本，一个子进程的 ARGS 会同时命中多个关键词，导致数量放大
#  （实测 1 个子进程被算成 5 个）。
#
#  新实现：ag_spawn 启动时给子进程注入 AG_ROLE=<函数名> 环境变量，
#  这里读 /proc/<pid>/environ 精确计数，绝不会误判。
#
#  输出：每行 key=count
# ============================================================
ag_proc_stat() {
    # v2.0.1：直接读 PID 文件判活，不再遍历 /proc
    # 子进程在 ag_spawn 启动时把自己的 PID 写入 data/run/<角色>.pid
    _run_dir="$DATA_DIR/run"
    mkdir -p "$_run_dir" 2>/dev/null

    # 从 PID 文件计数：文件存在 且 PID 存活 → 1，否则 0（并清理陈旧文件）
    _ag_one() {   # $1=角色名
        _f="$_run_dir/$1.pid"
        [ -r "$_f" ] || { echo 0; return; }
        _pid=$(/system/bin/toybox cat "$_f" 2>/dev/null | /system/bin/toybox tr -d ' \r\n')
        case "$_pid" in
            ''|*[!0-9]*) rm -f "$_f" 2>/dev/null; echo 0; return ;;
        esac
        if [ -d "/proc/$_pid" ]; then
            # 僵尸不算
            case "$(/system/bin/toybox cat "/proc/$_pid/stat" 2>/dev/null)" in
                *") Z "*) rm -f "$_f" 2>/dev/null; echo 0; return ;;
            esac
            echo 1
        else
            rm -f "$_f" 2>/dev/null
            echo 0
        fi
    }

    _st_shadow=$(_ag_one ag_shadow_lifecycle)
    _st_guard=$(_ag_one ag_guard_inside)
    _st_house=$(_ag_one ag_housekeeping_loop)
    _st_green=$(_ag_one ag_mem_check_loop)
    _st_prop=$(_ag_one ag_prop_daemon)
    _st_mon=$(_ag_one ag_monitor_loop)
    _st_warm=$(_ag_one ag_cache_warm)

    # 主服务：读 service.pid
    _st_svc=0
    _svcf="$DATA_DIR/service.pid"
    if [ -r "$_svcf" ]; then
        _svcpid=$(/system/bin/toybox cat "$_svcf" 2>/dev/null | /system/bin/toybox tr -d ' \r\n')
        case "$_svcpid" in
            ''|*[!0-9]*) : ;;
            *)
                if [ -d "/proc/$_svcpid" ]; then
                    case "$(/system/bin/toybox cat "/proc/$_svcpid/stat" 2>/dev/null)" in
                        *") Z "*) : ;;
                        *) _st_svc=1 ;;
                    esac
                fi
                ;;
        esac
    fi

    printf 'service=%s\n'  "$_st_svc"
    printf 'shadow=%s\n'   "$_st_shadow"
    printf 'guard=%s\n'    "$_st_guard"
    printf 'house=%s\n'    "$_st_house"
    printf 'green=%s\n'    "$_st_green"
    printf 'prop=%s\n'     "$_st_prop"
    printf 'monitor=%s\n'  "$_st_mon"
    printf 'warm=%s\n'     "$_st_warm"
    printf 'other=0\n'
}
