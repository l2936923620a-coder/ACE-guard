#!/system/bin/sh
# ============================================================
#  ACE Guard 开机入口
#
#  【卸载拦截 —— 必须在最前面】
#  KernelSU 点击「卸载」只创建 remove 标记，不会执行 uninstall.sh。
#  本模块在 post-fs-data 阶段主动检测该标记，
#  先跑完整清理，再让 KSU 在后续阶段删除模块目录。
#
#  正常启动流程：
#    1. 卸载拦截（remove 标记存在 → 清理后退出）
#    2. 授权闸门 + module.prop 刷新
#    3. 真机指纹快照（必须在指纹注入之前）
#    4. 未授权 → 退出；已授权 → 指纹注入 + 残留清理
# ============================================================

# ---------- 卸载拦截（务必第一个执行）----------
_AG_SELF=$(/system/bin/toybox readlink -f "$0")
_AG_MODDIR=$(/system/bin/toybox dirname "$_AG_SELF")

if [ -f "$_AG_MODDIR/remove" ]; then
    echo "[ace_guard] 检测到卸载标记，开始清理残留..." >&2
    if [ -x "$_AG_MODDIR/uninstall.sh" ]; then
        /system/bin/sh "$_AG_MODDIR/uninstall.sh" >/dev/null 2>&1
        echo "[ace_guard] 清理完成，等待 KSU 删除模块目录" >&2
    fi
    exit 0
fi

MODDIR="$_AG_MODDIR"
. "$MODDIR/script/common.sh"
. "$MODDIR/script/clean.sh"

ag_load_conf

# ---------- 授权子系统 ----------
. "$MODDIR/script/auth.sh"

# 1) 真机指纹快照：首次安装建立，之后不再覆盖。
#    此处系统属性还是真机值（post-fs-data 阶段尚未注入），是最佳采集时机。
ag_auth_snapshot_init

# 2) 授权校验 + 刷新 KSU 卡片文案
ag_auth_validate_silent
ag_auth_update_prop 2>/dev/null

# 3) 卡片文案守护（独立进程，setsid 脱离父进程组）。
#    放在未授权分支之前，保证无论授权与否都会持续同步 KSU 卡片。
/system/bin/sh "$MODDIR/bin/ag_prop_daemon.sh" start >/dev/null 2>&1

# 3.5) 远程版本闸门：有新版本则冻结（终止全部进程 + 还原挂载）
. "$MODDIR/script/notice.sh"

# 启动时先按当前本地版本复核一次，清掉可能残留的过期标记
_sig_now=$(ag_notice_local_sig)
_sig_old=$(cat "$AG_NOTICE_DIR/.local_sig" 2>/dev/null)
if [ "$_sig_now" != "$_sig_old" ] && ag_notice_state_load 2>/dev/null; then
    ag_notice_evaluate >/dev/null 2>&1
fi

# 拉起远程版本监控（冻结时必须存活，否则无法自动解冻）
ag_start_notice_monitor() {
    [ -n "${NOTICE_URL:-}" ] || return 0
    _script="
        MODDIR='$MODDIR'
        export MODDIR
        . '$MODDIR/script/common.sh' 2>/dev/null
        . '$MODDIR/script/notice.sh'
        ag_load_conf
        ag_notice_daemon
    "
    if command -v setsid >/dev/null 2>&1; then
        setsid /system/bin/sh -c "$_script" </dev/null >>"$LOG_DIR/service.log" 2>&1 &
    else
        nohup /system/bin/sh -c "$_script" </dev/null >>"$LOG_DIR/service.log" 2>&1 &
    fi
}
ag_start_notice_monitor

if ag_notice_need_update; then
    ag_log WARN "检测到新版本 $AG_N_REMOTE_VER（$AG_N_REMOTE_VC > 本地 $(ag_notice_local_vc)），执行冻结"
    ag_freeze_all "postfs_gate" 2>/dev/null
    ag_auth_update_prop 2>/dev/null
    ag_start_notice_monitor
    exit 0
fi

if [ "$AG_AUTH_OK" != "1" ]; then
    ag_log WARN "未授权：跳过指纹注入与清理（设备码 $(ag_auth_device_id) / $AG_AUTH_REASON）"
    exit 0
fi

ag_log INFO "授权通过：$(ag_auth_plan_text)"

until [ "$(/system/bin/getprop sys.boot_completed 2>/dev/null)" = "1" ]; do
    /system/bin/sleep 2
done
/system/bin/sleep 15

# 3) 指纹
if [ "$ENABLE_IDENTITY" = "1" ]; then
    if [ "$ROTATE_ON_BOOT" = "1" ]; then
        ag_log INFO "开机轮换指纹"
        ag_identity_generate
    else
        ag_identity_ensure
    fi
    ag_identity_apply
fi

# 4) 清理上次运行残留
[ "$ENABLE_EXIT_CLEAN" = "1" ] && {
    ag_clean_game_private
    ag_clean_system
}

# 5) 云端上报（AUTH_URL 为空时内部直接返回，不发请求）
ag_auth_upload_cloud "boot"

# 6) 注入完成后再次同步卡片，防止 3/4 步耗时导致状态滞后
ag_auth_update_prop 2>/dev/null

ag_log INFO "post-fs-data 完成 SERIAL=$AG_SERIAL"
