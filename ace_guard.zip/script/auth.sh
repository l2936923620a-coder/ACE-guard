#!/system/bin/sh
# ============================================================
#  ACE Guard 授权子系统  v1.5.0
#
#  设计要点：
#    1. 设备码由「三种真机指纹」派生，与原厂/当前伪装值都不同，
#       换机必然失效，无法跨设备复制授权。
#    2. 首次安装时抓取真机指纹快照并备份，作为溯源基准。
#    3. 授权码 = 设备码 + 有效期 + 签名，纯离线可核验。
#    4. 云端上报位置已预留（见 ag_auth_upload_cloud）。
# ============================================================

AG_AUTH_DIR="/data/adb/ace_guard/auth"
AG_AUTH_FILE="$AG_AUTH_DIR/license"
AG_AUTH_STAMP="$AG_AUTH_DIR/.tstamp"
AG_AUTH_LASTOK="$AG_AUTH_DIR/.lastok"
AG_AUTH_LOG="$AG_AUTH_DIR/auth.log"
AG_SNAPSHOT="$AG_AUTH_DIR/original_identity"     # 真机指纹快照
AG_SNAPSHOT_BAK="$AG_AUTH_DIR/.original_identity.bak"

AG_AUTH_OK=0
AG_AUTH_DEVICE=""
AG_AUTH_CODE=""
AG_AUTH_ISSUED=0
AG_AUTH_EXPIRE=0
AG_AUTH_REASON="未初始化"
AG_AUTH_CODE_ERR="UNKNOWN"

mkdir -p "$AG_AUTH_DIR" 2>/dev/null
chmod 700 "$AG_AUTH_DIR" 2>/dev/null

# ---------- MODDIR 兜底 ----------
# auth.sh 可能被单独 source（不经 common.sh），此时 MODDIR 为空，
# 会导致 ag_auth_update_prop 静默失败、module.prop 永不刷新。
if [ -z "${MODDIR:-}" ]; then
    MODDIR="/data/adb/modules/ace_guard"
fi

# ============================================================
#  基础工具
# ============================================================

ag_auth_secret() {
    printf '%s' "a3f9c2e1" "7b4d8056" "1e9f4a7c" "d2b63085" "4c8ea19f"
}

# sha256 结果缓存（进程内，按输入缓存最近 32 条）
AG_SHA_CACHE=""
AG_SHA_KEYS=""

ag_sha256() {
    # 命中缓存直接返回（避免重复 fork sha256sum，单次约 19ms）
    case "$AG_SHA_KEYS" in
        *"|$1|"*)
            printf '%s' "$AG_SHA_CACHE" | /system/bin/toybox grep "^$1 " 2>/dev/null | head -n1 | cut -d' ' -f2-
            return 0 ;;
    esac
    _r=$(_ag_sha256_raw "$1")
    [ -n "$_r" ] || return 1
    AG_SHA_CACHE="$AG_SHA_CACHE
$1 $_r"
    AG_SHA_KEYS="$AG_SHA_KEYS|$1|"
    # 控制缓存规模
    if [ $(printf '%s' "$AG_SHA_KEYS" | /system/bin/toybox tr -cd '|' | wc -c) -gt 64 ]; then
        AG_SHA_CACHE=""; AG_SHA_KEYS=""
    fi
    printf '%s' "$_r"
}

_ag_sha256_raw() {
    for p in /system/bin/sha256sum /system/bin/toybox /system/bin/busybox; do
        case "$p" in
            */sha256sum) [ -x "$p" ] && { printf '%s' "$1" | "$p" | cut -c1-64; return 0; } ;;
            */toybox)    [ -x "$p" ] && { printf '%s' "$1" | "$p" sha256sum 2>/dev/null | cut -c1-64; return 0; } ;;
            */busybox)   [ -x "$p" ] && { printf '%s' "$1" | "$p" sha256sum 2>/dev/null | cut -c1-64; return 0; } ;;
        esac
    done
    return 1
}

# 签名：sha256(secret|msg|secret) —— 不依赖 openssl/hmac
# 与 tools/ag_license.py 的 sign() 必须完全一致
ag_hmac_hex() {
    _sec="a3f9c2e17b4d80561e9f4a7cd2b630854c8ea19f"
    ag_sha256 "${_sec}|$1|${_sec}"
}

# ============================================================
#  真机指纹快照（溯源基准）
# ============================================================

# 读取当前系统属性中的真机指纹
# 注意：必须在指纹注入之前调用，否则拿到的是伪装值
ag_auth_read_real_fingerprint() {
    AG_REAL_SERIAL=$(/system/bin/getprop ro.boot.serialno 2>/dev/null)
    [ -z "$AG_REAL_SERIAL" ] && AG_REAL_SERIAL=$(/system/bin/getprop ro.serialno 2>/dev/null)

    AG_REAL_IMEI=$(/system/bin/getprop persist.radio.imei1 2>/dev/null)
    [ -z "$AG_REAL_IMEI" ] && AG_REAL_IMEI=$(/system/bin/getprop persist.radio.imei 2>/dev/null)
    [ -z "$AG_REAL_IMEI" ] && AG_REAL_IMEI=$(/system/bin/getprop ro.ril.oem.imei1 2>/dev/null)

    AG_REAL_CHIPECID=$(/system/bin/getprop ro.boot.chipecid 2>/dev/null)

    AG_REAL_MODEL=$(/system/bin/getprop ro.product.model 2>/dev/null)
    AG_REAL_BRAND=$(/system/bin/getprop ro.product.brand 2>/dev/null)
    AG_REAL_DEVICE=$(/system/bin/getprop ro.product.device 2>/dev/null)
    AG_REAL_FP=$(/system/bin/getprop ro.build.fingerprint 2>/dev/null)

    # 逐属性原值（卸载时精确还原用）
    # v1.9.8 扩全：覆盖所有会被覆盖的身份属性，供授权页展示完整原始值
    AG_REAL_PROPS=""
    for _k in ro.serialno ro.boot.serialno ro.boot.chipecid ro.boot.chipid \
              persist.radio.imei persist.radio.imei1 persist.radio.imei2 persist.radio.imei9 \
              ril.gsm.imei gsm.serial \
              vendor.gsm.serial ro.vendor.gsm.serial \
              ro.vendor.oplus.radio.serialno vendor.oplus.caihong.serialno persist.sys.oplus.serialno \
              ro.ril.oem.imei ro.ril.oem.imei1; do
        _v=$(/system/bin/getprop "$_k" 2>/dev/null)
        [ -n "$_v" ] && AG_REAL_PROPS="$AG_REAL_PROPS
PROP_$(printf '%s' "$_k" | tr '.' '_')=$_v"
    done
    # ADID 原始值也记入快照（归属用户那份）
    _u0=$(_ag_primary_user 2>/dev/null || echo 0)
    _adid0=$(/system/bin/settings --user "$_u0" get secure android_id 2>/dev/null)
    if [ -n "$_adid0" ] && [ "$_adid0" != "null" ]; then
        AG_REAL_PROPS="$AG_REAL_PROPS
PROP_android_id=$_adid0"
    fi
}

# 首次安装时采集并备份真机指纹。已存在则跳过（绝不覆盖）。
# 返回 0=已就绪 1=失败
ag_auth_snapshot_init() {
    if [ -f "$AG_SNAPSHOT" ] && [ -s "$AG_SNAPSHOT" ]; then
        return 0
    fi
    # 从备份恢复（若快照被误删）
    if [ -f "$AG_SNAPSHOT_BAK" ] && [ -s "$AG_SNAPSHOT_BAK" ]; then
        cp -f "$AG_SNAPSHOT_BAK" "$AG_SNAPSHOT" 2>/dev/null
        [ -s "$AG_SNAPSHOT" ] && return 0
    fi

    ag_auth_read_real_fingerprint
    _now=$(/system/bin/date +%s)

    # 真机指纹可能是空（部分设备无 chipecid/imei）
    # 空值用占位符固定，保证设备码稳定
    [ -z "$AG_REAL_SERIAL" ]   && AG_REAL_SERIAL="NOSERIAL"
    [ -z "$AG_REAL_IMEI" ]     && AG_REAL_IMEI="NOIMEI"
    [ -z "$AG_REAL_CHIPECID" ] && AG_REAL_CHIPECID="NOCHIP"

    {
        echo "# ace_guard 真机指纹快照（首次安装时采集，用于授权溯源）"
        echo "REAL_SERIAL=$AG_REAL_SERIAL"
        echo "REAL_IMEI=$AG_REAL_IMEI"
        echo "REAL_CHIPECID=$AG_REAL_CHIPECID"
        echo "REAL_MODEL=$AG_REAL_MODEL"
        echo "REAL_BRAND=$AG_REAL_BRAND"
        echo "REAL_DEVICE=$AG_REAL_DEVICE"
        echo "REAL_FP=$AG_REAL_FP"
        [ -n "$AG_REAL_PROPS" ] && printf '%s\n' "$AG_REAL_PROPS"
        echo "SNAPSHOT_TIME=$_now"
    } > "$AG_SNAPSHOT.tmp" 2>/dev/null || return 1

    chmod 600 "$AG_SNAPSHOT.tmp" 2>/dev/null
    mv -f "$AG_SNAPSHOT.tmp" "$AG_SNAPSHOT" 2>/dev/null || return 1
    cp -f "$AG_SNAPSHOT" "$AG_SNAPSHOT_BAK" 2>/dev/null

    command -v ag_log >/dev/null 2>&1 && \
        ag_log INFO "真机指纹快照已建立 SERIAL=$AG_REAL_SERIAL CHIPECID=$AG_REAL_CHIPECID"
    return 0
}

# 从快照读取真机指纹到 AG_R_* 变量
ag_auth_snapshot_load() {
    AG_R_SERIAL=""; AG_R_IMEI=""; AG_R_CHIPECID=""
    AG_R_MODEL=""; AG_R_BRAND=""; AG_R_DEVICE=""; AG_R_FP=""; AG_R_TIME=0
    [ -f "$AG_SNAPSHOT" ] || return 1
    _k=""; _v=""
    while IFS='=' read -r _k _v; do
        _v=$(printf '%s' "$_v" | tr -d '\r')
        case "$_k" in
            REAL_SERIAL)   AG_R_SERIAL="$_v" ;;
            REAL_IMEI)     AG_R_IMEI="$_v" ;;
            REAL_CHIPECID) AG_R_CHIPECID="$_v" ;;
            REAL_MODEL)    AG_R_MODEL="$_v" ;;
            REAL_BRAND)    AG_R_BRAND="$_v" ;;
            REAL_DEVICE)   AG_R_DEVICE="$_v" ;;
            REAL_FP)       AG_R_FP="$_v" ;;
            SNAPSHOT_TIME) AG_R_TIME="$_v" ;;
        esac
    done < "$AG_SNAPSHOT"
    [ -n "$AG_R_SERIAL" ]
}

# ============================================================
#  设备码（三种真机指纹派生）
# ============================================================

# 设备码 = sha256(SERIAL|IMEI|CHIPECID|acguard-device)[:16]
# 三种指纹全部参与，任一变化设备码即变 → 授权失效
# 设备码缓存
#   注意：函数常被 $( ) 调用，在子 shell 中执行，无法回写父进程变量。
#   所以在 ag_webui.sh / auth.sh 入口处主动预热一次（见 ag_auth_init_cache），
#   之后所有调用直接读 AG_AUTH_DEVID。
AG_AUTH_DEVID="${AG_AUTH_DEVID:-}"

ag_auth_device_id() {
    if [ -n "$AG_AUTH_DEVID" ]; then
        printf '%s' "$AG_AUTH_DEVID"
        return 0
    fi
    _ag_auth_device_id_uncached
}

# 主动预热：在当前进程内算好设备码并存入全局变量
ag_auth_init_cache() {
    [ -n "$AG_AUTH_DEVID" ] && return 0
    AG_AUTH_DEVID=$(_ag_auth_device_id_uncached)
    # 已父进程赋值，同时导出给子 shell
    export AG_AUTH_DEVID
    return 0
}

_ag_auth_device_id_uncached() {
    if ! ag_auth_snapshot_load; then
        # 没有快照时退回属性读取（保证 UI 永远有值可显示）
        ag_auth_read_real_fingerprint
        _s="$AG_REAL_SERIAL"; _i="$AG_REAL_IMEI"; _c="$AG_REAL_CHIPECID"
        [ -z "$_s" ] && _s="NOSERIAL"
        [ -z "$_i" ] && _i="NOIMEI"
        [ -z "$_c" ] && _c="NOCHIP"
        _raw="${_s}|${_i}|${_c}|acguard-device"
    else
        _raw="${AG_R_SERIAL}|${AG_R_IMEI}|${AG_R_CHIPECID}|acguard-device"
    fi
    ag_sha256 "$_raw" | cut -c1-16
}

# 分项指纹短码，便于人工核对是哪一项变了
ag_auth_fp_serial()   { ag_sha256 "$1|acguard-s" | cut -c1-8; }
ag_auth_fp_imei()     { ag_sha256 "$1|acguard-i" | cut -c1-8; }
ag_auth_fp_chipecid() { ag_sha256 "$1|acguard-c" | cut -c1-8; }

# ============================================================
#  授权码
# ============================================================
# 格式: AG-<expire_hex>-<sig16>   expire_hex=0 → 永久
ag_auth_sign() {
    _s=$(ag_hmac_hex "$1|$2|acguard")
    printf '%.16s' "$_s"
}

ag_auth_gen_code() {
    _exp=$(printf '%x' "${2:-0}")
    _sig=$(ag_auth_sign "$1" "$_exp")
    printf 'AG-%s-%s' "$_exp" "$_sig" | tr 'a-f' 'A-F'
}

# 返回 0=有效 1=签名错 2=已过期
ag_auth_verify_code() {
    case "$2" in AG-*-*) ;; *) return 1 ;; esac
    _exp=$(printf '%s' "$2" | sed 's/^AG-//; s/-.*$//' | tr 'A-F' 'a-f')
    _sig=$(printf '%s' "$2" | sed 's/.*-//'         | tr 'A-F' 'a-f')
    [ -n "$_exp" ] && [ -n "$_sig" ] || return 1
    [ "$_sig" = "$(ag_auth_sign "$1" "$_exp")" ] || return 1
    [ "$_exp" = "0" ] && return 0
    _now=$(/system/bin/date +%s)
    [ "$_now" -lt $((0x$_exp)) ] || return 2
    return 0
}

ag_auth_expire_of() {
    _e=$(printf '%s' "$1" | sed 's/^AG-//; s/-.*$//' | tr 'A-F' 'a-f')
    [ "$_e" = "0" ] && { echo 0; return; }
    printf '%d\n' $((0x$_e))
}

# ============================================================
#  授权文件读写
# ============================================================

ag_auth_load() {
    AG_AUTH_OK=0; AG_AUTH_DEVICE=""; AG_AUTH_CODE=""; AG_AUTH_ISSUED=0; AG_AUTH_EXPIRE=0
    AG_AUTH_SIG=""
    [ -f "$AG_AUTH_FILE" ] || { AG_AUTH_REASON="授权文件不存在，本机尚未激活"; AG_AUTH_CODE_ERR="NO_FILE"; return 1; }

    device=""; code=""; issued=""; sig=""
    . "$AG_AUTH_FILE" 2>/dev/null

    AG_AUTH_DEVICE="${device:-}"
    AG_AUTH_CODE="${code:-}"
    AG_AUTH_ISSUED="${issued:-0}"
    AG_AUTH_SIG="${sig:-}"

    if [ -z "$AG_AUTH_DEVICE" ] || [ -z "$AG_AUTH_CODE" ]; then
        AG_AUTH_REASON="授权文件内容损坏（缺少必要字段）"; AG_AUTH_CODE_ERR="CORRUPT"; return 1
    fi

    _chk=$(ag_hmac_hex "${AG_AUTH_DEVICE}|${AG_AUTH_CODE}|${AG_AUTH_ISSUED}|file")
    _chk=$(printf '%.16s' "$_chk")
    if [ -n "$AG_AUTH_SIG" ] && [ "$AG_AUTH_SIG" != "$_chk" ]; then
        AG_AUTH_REASON="授权文件签名不匹配，文件被手工修改过"; AG_AUTH_CODE_ERR="TAMPERED"; return 1
    fi

    AG_AUTH_EXPIRE=$(ag_auth_expire_of "$AG_AUTH_CODE")
    return 0
}

ag_auth_save() {
    _issued=$(/system/bin/date +%s)
    _sig=$(ag_hmac_hex "$1|$2|$_issued|file"); _sig=$(printf '%.16s' "$_sig")
    {
        echo "# ace_guard license"
        echo "device=$1"
        echo "code=$2"
        echo "issued=$_issued"
        echo "sig=$_sig"
    } > "$AG_AUTH_FILE"
    chmod 600 "$AG_AUTH_FILE" 2>/dev/null
    cp -f "$AG_AUTH_FILE" "$AG_AUTH_DIR/.license.bak" 2>/dev/null
}

ag_auth_clear() {
    rm -f "$AG_AUTH_FILE" "$AG_AUTH_STAMP" "$AG_AUTH_LASTOK" 2>/dev/null
    AG_AUTH_OK=0
    AG_AUTH_REASON="授权文件已被清除"
    AG_AUTH_CODE_ERR="NO_FILE"
    # 立即同步 module.prop，避免场景：清授权后卡片仍显示已授权
    ag_auth_update_prop
}

# ============================================================
#  抗时钟回拨
# ============================================================

ag_auth_antiroll() {
    _now=$(/system/bin/date +%s)
    _last=$(cat "$AG_AUTH_STAMP" 2>/dev/null || echo 0)
    if [ "$_last" -gt 0 ] && [ "$_now" -lt $((_last - 21600)) ]; then
        AG_AUTH_REASON="检测到系统时间被回拨，授权暂不可用，请校准系统时间"
        AG_AUTH_CODE_ERR="CLOCK_ROLL"
        return 1
    fi
    if [ -f "$AG_AUTH_STAMP" ]; then
        _mt=$(/system/bin/toybox stat -c %Y "$AG_AUTH_STAMP" 2>/dev/null || echo 0)
        if [ "$_mt" -gt 0 ] && [ "$_now" -lt $((_mt - 21600)) ]; then
            AG_AUTH_REASON="系统时间早于授权记录时间，请校准系统时间"
            AG_AUTH_CODE_ERR="CLOCK_ROLL"
            return 1
        fi
    fi
    [ "$_now" -gt "$_last" ] && echo "$_now" > "$AG_AUTH_STAMP" 2>/dev/null
    return 0
}

# ============================================================
#  主判定
# ============================================================

ag_auth_valid() {
    # 进程内缓存：同一次调用里反复校验无意义
    [ "$AG_AUTH_OK" = "1" ] && return 0
    case "${AG_AUTH_VALID_CACHE:-}" in
        1) return 0 ;;
        0) return 1 ;;
    esac

    # 快照必须先就绪，否则设备码不稳定
    ag_auth_snapshot_init || { AG_AUTH_REASON="真机指纹快照建立失败"; AG_AUTH_CODE_ERR="NO_SNAPSHOT"; return 1; }

    ag_auth_load || return 1
    ag_auth_antiroll || return 1

    ag_auth_init_cache
    _dev="$AG_AUTH_DEVID"
    if [ "$_dev" != "$AG_AUTH_DEVICE" ]; then
        AG_AUTH_REASON="真机指纹已变化，原授权与本设备不匹配"
        AG_AUTH_CODE_ERR="FP_CHANGED"
        return 1
    fi

    ag_auth_verify_code "$AG_AUTH_DEVICE" "$AG_AUTH_CODE"
    case $? in
        0) ;;
        2) AG_AUTH_REASON="授权已到期"; AG_AUTH_CODE_ERR="EXPIRED"; return 1 ;;
        *) AG_AUTH_REASON="授权码签名无效，与本设备不匹配"; AG_AUTH_CODE_ERR="CODE_BAD"; return 1 ;;
    esac

    AG_AUTH_OK=1
    AG_AUTH_REASON="已授权"
    AG_AUTH_CODE_ERR="OK"
    echo "$(ag_auth_device_id)|$(/system/bin/date +%s)" > "$AG_AUTH_LASTOK" 2>/dev/null
    return 0
}

ag_auth_validate_silent() {
    # 已有结论则直接复用，不重新计算
    [ "$AG_AUTH_OK" = "1" ] && return 0
    case "${AG_AUTH_VALID_CACHE:-}" in
        1) AG_AUTH_OK=1; return 0 ;;
        0) return 1 ;;
    esac
    AG_AUTH_OK=0
    ag_auth_valid >/dev/null 2>&1
    if [ "$AG_AUTH_OK" = "1" ]; then
        AG_AUTH_VALID_CACHE=1
    else
        AG_AUTH_VALID_CACHE=0
    fi
    return $([ "$AG_AUTH_OK" = "1" ] && echo 0 || echo 1)
}

# ============================================================
#  守卫
# ============================================================

ag_auth_guard() {
    if ag_auth_valid; then
        return 0
    fi
    _who=${1:-${0##*/}}
    _msg="未授权拦截 [$AG_AUTH_REASON] 调用者=$_who 设备码=$(ag_auth_device_id)"
    echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') $_msg" >> "$AG_AUTH_LOG" 2>/dev/null
    command -v ag_log >/dev/null 2>&1 && ag_log WARN "$_msg"
    # 被拒绝时也刷新一次卡片，确保 KSU 里文案与真实状态一致
    ag_auth_update_prop
    return 1
}

# ============================================================
#  激活
# ============================================================

ag_auth_activate() {
    _code=$(printf '%s' "$1" | tr -d ' \t\r\n' | tr 'a-f' 'A-F')
    [ -n "$_code" ] || { AG_AUTH_REASON="请输入授权码"; AG_AUTH_CODE_ERR="EMPTY_INPUT"; return 1; }

    ag_auth_snapshot_init || { AG_AUTH_REASON="真机指纹快照建立失败"; AG_AUTH_CODE_ERR="NO_SNAPSHOT"; return 1; }
    _dev=$(ag_auth_device_id)

    ag_auth_verify_code "$_dev" "$_code"
    case $? in
        0) ;;
        2) AG_AUTH_REASON="授权码有效但已过期"; AG_AUTH_CODE_ERR="EXPIRED"; return 2 ;;
        *) AG_AUTH_REASON="授权码与本机设备码不匹配（该码不属于本机）"; AG_AUTH_CODE_ERR="CODE_BAD"; return 1 ;;
    esac

    ag_auth_save "$_dev" "$_code"
    AG_AUTH_OK=0
    ag_auth_validate_silent
    ag_auth_update_prop
    ag_auth_upload_cloud "activate"
    command -v ag_log >/dev/null 2>&1 && \
        ag_log INFO "授权激活成功 device=$_dev expire=$(ag_auth_expire_of "$_code")"
    return 0
}

# ============================================================
#  状态输出
# ============================================================

# 到期时间直接展示（不做天数递减）
# ------------------------------------------------------------
# 旧实现按 (expire-now)/86400 递减，必须跨过「授权时刻」才掉 1 天，
# 用户在白天观察会觉得「过了一整天还是 29 天」。
# 现在直接展示授权到期日期，文字固定、不会跳变，也省掉整段进位计算。
ag_auth_expire_date() {
    [ "$AG_AUTH_EXPIRE" = "0" ] && { echo "永久"; return; }
    /system/bin/date -d "@$AG_AUTH_EXPIRE" '+%Y-%m-%d %H:%M' 2>/dev/null \
        || /system/bin/date -r "$AG_AUTH_EXPIRE" '+%Y-%m-%d %H:%M' 2>/dev/null \
        || echo "未知"
}

# 兼容旧调用点：原「剩余 N 天」现在返回到期日期
ag_auth_days_left() {
    ag_auth_expire_date
}

ag_auth_left_text() {
    ag_auth_expire_date
}

ag_auth_plan_text() {
    if [ "$AG_AUTH_OK" = "1" ]; then
        if [ "$AG_AUTH_EXPIRE" = "0" ]; then
            echo "已授权 · 永久"
        else
            echo "已授权 · 到期 $(ag_auth_expire_date)"
        fi
    else
        echo "未授权"
    fi
}

# ============================================================
#  module.prop 动态改写
# ============================================================
#  必须能在任何时机调用（授权变化、被拒绝、开机、过期），
#  否则 KSU 卡片会与真实授权状态脱节。
ag_auth_update_prop() {
    prop="$MODDIR/module.prop"
    orig="$MODDIR/.module.prop.orig"

    [ -f "$prop" ] || return 1

    # 原始副本：首次建立；若现有 prop 已含标记而 orig 缺失，从 prop 反推
    if [ ! -f "$orig" ] || [ ! -s "$orig" ]; then
        if /system/bin/grep -q '【\|⚠️' "$prop" 2>/dev/null; then
            sed 's/【[^】]*】//g; s/⚠️[^｜]*｜//g' "$prop" > "$orig.tmp" 2>/dev/null && \
                mv -f "$orig.tmp" "$orig" 2>/dev/null
        else
            cp -f "$prop" "$orig" 2>/dev/null
        fi
    fi
    [ -f "$orig" ] && [ -s "$orig" ] || return 1

    # 取原始 description（剥掉所有旧标记）
    _base=$(/system/bin/sed -n 's/^description=//p' "$orig" 2>/dev/null | head -n1)
    [ -n "$_base" ] || _base=$(/system/bin/sed -n 's/^description=//p' "$prop" 2>/dev/null | head -n1)
    _base=$(printf '%s' "$_base" | sed 's/【[^】]*】//g; s/⚠️[^｜]*｜//g')
    # 去掉历史补丁残留的重复前缀（含「有新版本 xx·功能已暂时冻结｜」整段）
    _base=$(printf '%s' "$_base" | sed 's/^description=//; s/^⚠️ 有新版本[^｜]*｜//g; s/^打开 WebUI[^｜]*｜//g; s/^请前往 Git 仓库[^｜]*｜//g; s/^当前 [^｜]*｜//g')

    if ag_auth_valid; then
        # 已授权：完整功能介绍
        # 但若远程有新版本，优先显示更新提示并冻结
        if command -v ag_notice_need_update >/dev/null 2>&1 && ag_notice_need_update 2>/dev/null; then
            _rv=$(ag_notice_json_get "$AG_NOTICE_JSON" version str 2>/dev/null)
            _rc_=$(ag_notice_json_get "$AG_NOTICE_JSON" versionCode num 2>/dev/null)
            _lc_=$(ag_notice_local_vc 2>/dev/null)
            [ -n "$_rv" ] || _rv="新版本"
            _new="description=⚠️ 有新版本 ${_rv}·功能已暂时冻结｜打开 WebUI 更新公告下载，或在 KSU 执行操作(Action)一键更新｜当前 ${_rc_:-?} (本地 ${_lc_:-?})｜${_base}"
        else
            _new="description=【$(ag_auth_plan_text)】${_base}"
        fi
    else
        # 未授权：简短文案，不含任何功能描述
        _new="description=⚠️ 未授权·功能已冻结｜联系 ${AUTH_CONTACT:-QQ 3658039852} 或 ${AUTH_TG:-@xiaochunan67}｜设备码 $(ag_auth_device_id)｜无畏契约防观察期全量整合模块。"
    fi

    # 内容没变就不写
    _curdesc=$(/system/bin/sed -n 's/^description=//p' "$prop" 2>/dev/null | head -n1)
    [ "$_curdesc" = "${_new#description=}" ] && return 0

    /system/bin/sed "s|^description=.*|${_new}|" "$orig" > "$prop.tmp" 2>/dev/null || return 1
    # 上面 sed 会把 orig 的 description 行替换掉，但 orig 里的 description 是旧的
    # 直接用 printf 重建更可靠
    # 非 description 字段一律以「当前 module.prop」为准
    # 否则改过 version/versionCode 后会被 orig 的旧值覆盖回去，
    # 导致版本判定永远读到旧版本 → 永远不解冻
    _other=$(/system/bin/grep -v '^description=' "$prop" 2>/dev/null)
    [ -n "$_other" ] || _other=$(/system/bin/grep -v '^description=' "$orig" 2>/dev/null)
    {
        printf '%s\n' "$_other"
        printf '%s\n' "$_new"
    } > "$prop.tmp" 2>/dev/null || return 1
    mv -f "$prop.tmp" "$prop" 2>/dev/null && chmod 644 "$prop" 2>/dev/null
    # 同步导出设备码到 sdcard
    ag_auth_export_device 2>/dev/null
    return 0
}

# ============================================================
#  设备码导出（供签发 APP 读取，APP 无 root）
# ============================================================
ag_auth_export_device() {
    _out="/sdcard/ace_guard_device.txt"
    _tmp="/sdcard/.ace_dev.tmp"
    {
        echo "dev=$(ag_auth_device_id)"
        echo "plan=$([ "$AG_AUTH_OK" = "1" ] && ag_auth_plan_text || echo "未授权")"
        echo "ts=$(/system/bin/date +%s)"
    } > "$_tmp" 2>/dev/null && mv -f "$_tmp" "$_out" 2>/dev/null
    chmod 644 "$_out" 2>/dev/null
    return 0
}

# ============================================================
#  云端上报（预留位置）
# ============================================================
#
#  ⚠️⚠️  云端上报入口在这里  ⚠️⚠️
#
#  你目前没有服务器，此函数只在配置 AUTH_URL 非空时才会真正发请求。
#  上传内容：设备码、三种真机指纹、IP、型号、品牌、时间、授权状态。
#
#  要接入自己的服务器时，只需：
#    1. 把 config/guard.conf 里的 AUTH_URL 填成你的地址，如
#       AUTH_URL="https://your.domain/api/ace/register"
#    2. 服务端接收 POST，JSON body 见下面 _payload 变量
#    3. 返回 {"ok":true} 即可（返回值当前不影响本地授权判定）
#
#  调试：
#    sh bin/ag_webui.sh auth.upload        # 手动触发一次上报
#    sh bin/ag_webui.sh auth.uploadlog     # 查看上报历史
#
ag_auth_upload_cloud() {
    _event=${1:-periodic}

    # ---- 服务器地址（从 conf 读，空则跳过）----
    [ -n "${AUTH_URL:-}" ] || return 0

    ag_auth_snapshot_load 2>/dev/null
    _dev=$(ag_auth_device_id)
    _now=$(/system/bin/date +%s)
    _ip=$(ag_auth_local_ip)

    # ---- 上报内容（服务端按这个 schema 解析）----
    _payload="{\"event\":\"${_event}\",\"device\":\"${_dev}\",\"serial\":\"${AG_R_SERIAL}\",\"imei\":\"${AG_R_IMEI}\",\"chipecid\":\"${AG_R_CHIPECID}\",\"model\":\"${AG_R_MODEL}\",\"brand\":\"${AG_R_BRAND}\",\"build\":\"${AG_R_DEVICE}\",\"ip\":\"${_ip}\",\"ts\":${_now},\"licensed\":$([ "${AG_AUTH_OK:-0}" = "1" ] && echo true || echo false),\"code\":\"${AG_AUTH_CODE:-}\",\"ver\":\"$(sed -n 's/^version=//p' "$MODDIR/module.prop" 2>/dev/null | head -n1)\"}"

    # 记录到本地，成功与否都留痕，方便排查
    echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') [$ _event=$_event ] $_payload" >> "$AG_AUTH_DIR/upload.log" 2>/dev/null

    # ---- 实际发送 ----
    #  Android 的 toybox 不带 wget，优先用系统自带的 curl。
    #  后台执行，网络异常不影响主流程。
    (
        _resp="$AG_AUTH_DIR/.upload.resp"
        _rc=127
        if [ -x /system/bin/curl ]; then
            _code=$(/system/bin/curl -sS -m 15 -X POST \
                -H "Content-Type: application/json" \
                --data-binary "$_payload" \
                -o "$_resp" -w '%{http_code}' \
                "$AUTH_URL" 2>"$_resp.err")
            _rc=$?
        elif command -v wget >/dev/null 2>&1; then
            wget -q -O "$_resp" \
                --header "Content-Type: application/json" \
                --post-data "$_payload" \
                "$AUTH_URL" 2>"$_resp.err"
            _rc=$?
            _code="?"
        fi

        _body=$(head -c 300 "$_resp" 2>/dev/null)
        _err=$(head -c 200 "$_resp.err" 2>/dev/null)
        echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') event=$_event rc=$_rc http=${_code:-none} resp=${_body}${_err:+ err=$_err}" \
            >> "$AG_AUTH_DIR/upload.log" 2>/dev/null
        rm -f "$_resp.err" 2>/dev/null
    ) &
    return 0
}

# 本机局域网 IP（公网 IP 由服务端从请求头取，客户端拿不到自己的出口 IP）
ag_auth_local_ip() {
    for i in wlan0 eth0 rmnet_data0; do
        _ip=$(/system/bin/ip -4 addr show "$i" 2>/dev/null \
              | /system/bin/grep -o 'inet [0-9.]*' | head -n1 | cut -d' ' -f2)
        [ -n "$_ip" ] && { printf '%s' "$_ip"; return 0; }
    done
    printf 'unknown'
}

# ============================================================
#  启动/刷新
# ============================================================

# 开机调用：建快照 → 校验 → 刷新卡片 → 上报
ag_auth_boot() {
    ag_auth_snapshot_init

    ag_auth_validate_silent
    ag_auth_update_prop

    if [ "$AG_AUTH_OK" = "1" ]; then
        command -v ag_log >/dev/null 2>&1 && \
            ag_log INFO "授权校验通过：$(ag_auth_plan_text)"
        ag_auth_upload_cloud "boot"
    else
        command -v ag_log >/dev/null 2>&1 && \
            ag_log WARN "授权校验失败：$AG_AUTH_REASON（设备码 $(ag_auth_device_id)）"
    fi
}

# 供外部（定时任务/UI）调用的强制刷新
ag_auth_refresh_prop() {
    ag_auth_validate_silent
    ag_auth_update_prop
}

# ============================================================
#  卡片文案守护
# ============================================================
#  实验发现：授权在运行中被删除/过期后，KSU 卡片文案不会自动变，
#  因为 module.prop 只在开机时写一次。这个循环默认每 60 秒核对一次
#  真实授权状态与当前卡片文案，不一致就重写。
#  只在 service.sh 里跑，不随每次 UI 调用启动。
ag_auth_prop_keeper() {
    _interval=${AUTH_PROP_REFRESH:-60}
    while true; do
        /system/bin/sleep "$_interval"
        # 强制重新判定，不复用可能已过期的 AG_AUTH_OK
        AG_AUTH_OK=0
        ag_auth_valid >/dev/null 2>&1
        ag_auth_update_prop 2>/dev/null
    done
}

# ============================================================
#  未授权提示文本
# ============================================================

ag_auth_deny_text() {
    ag_auth_validate_silent
    echo ""
    echo "════════════════════════════════════════"
    echo "  ⚠️  此设备未授权，功能已全部冻结"
    echo "════════════════════════════════════════"
    echo "  设备码: $(ag_auth_device_id)"
    echo "  原因:   $AG_AUTH_REASON"
    echo ""
    echo "  联系 ${AUTH_CONTACT:-QQ 3658039852}"
    echo "  或   ${AUTH_TG:-@xiaochunan67}"
    echo "  发送上方设备码获取授权"
    echo ""
    echo "  拿到授权码后在 WebUI 或执行："
    echo "    sh /data/adb/modules/ace_guard/bin/ag_webui.sh auth.activate '<授权码>'"
    echo "════════════════════════════════════════"
}
