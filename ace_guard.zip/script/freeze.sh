# ============================================================
#  ACE Guard 冻结执行器  v1.0.0
#
#  职责：需要更新/未授权时，把模块自己拉起的全部进程终止干净，
#        并还原已做的挂载与属性注入，避免「冻结了但后台还在跑」。
#
#  只终止本模块自己的进程（命令行含 $MODDIR），不碰任何其他应用。
# ============================================================

# 冻结执行器依赖的目录（notice.sh 未加载时兜底）
AG_NOTICE_DIR="${AG_NOTICE_DIR:-/data/adb/ace_guard/notice}"
AG_NOTICE_LOG="${AG_NOTICE_LOG:-$AG_NOTICE_DIR/notice.log}"
AG_AUTH_DIR="${AG_AUTH_DIR:-/data/adb/ace_guard/auth}"
MODDIR="${MODDIR:-/data/adb/modules/ace_guard}"
# ag_log 内部会做数值比较，未初始化会报 bad number
LOG_LEVEL="${LOG_LEVEL:-1}"
mkdir -p "$AG_NOTICE_DIR" 2>/dev/null

AG_FREEZE_MARK="$AG_NOTICE_DIR/.frozen"

# 列出本模块所有进程 PID（排除自己）
ag_freeze_pids() {
    _self=$$
    # 冻结时绝不能杀掉「版本监控」自己，否则永远无法检测到版本追平。
    # notice.pid 记录监控主 PID；同时把它整条祖先链都排除，
    # 因为 ag_freeze_all 就是从监控进程内部调起的。
    _mon_pid=$(cat "$MODDIR/data/run/notice.pid" 2>/dev/null)
    _anc=" $$ "
    _cur=$$
    _i=0
    while [ "$_i" -lt 12 ]; do
        _i=$(( _i + 1 ))
        _pp=$(/system/bin/toybox ps -A -o PID,PPID 2>/dev/null \
              | /system/bin/awk -v p="$_cur" '$1==p{print $2; exit}')
        case "$_pp" in ''|*[!0-9]*|0) break ;; esac
        _anc="$_anc$_pp "
        _cur="$_pp"
    done
    [ -n "$_mon_pid" ] && _anc="$_anc$_mon_pid "

    /system/bin/toybox ps -A -o PID,ARGS 2>/dev/null \
        | /system/bin/grep -F "$MODDIR" \
        | /system/bin/grep -vF "grep" \
        | /system/bin/grep -vF "ag_freeze" \
        | while IFS= read -r _l; do
              # toybox ps 的列格式不固定，直接取行首第一个数字字段
              _p=$(printf '%s' "$_l" | /system/bin/toybox tr -s ' ' | /system/bin/sed 's/^ *//' | /system/bin/toybox cut -d' ' -f1)
              case "$_p" in ''|*[!0-9]*) continue ;; esac
              case "$_anc" in *" $_p "*) continue ;; esac
              printf '%s\n' "$_p"
          done | /system/bin/toybox sort -u
}

# 终止全部模块进程（两轮，确保子进程也被带走）
ag_freeze_kill_all() {
    _round=0
    while [ "$_round" -lt 2 ]; do
        _round=$(( _round + 1 ))
        _any=0
        for _p in $(ag_freeze_pids); do
            _any=1
            # 先温和终止，再强杀
            /system/bin/toybox kill -TERM "$_p" 2>/dev/null
        done
        [ "$_any" = "0" ] && break
        /system/bin/sleep 1
        for _p in $(ag_freeze_pids); do
            /system/bin/toybox kill -9 "$_p" 2>/dev/null
        done
        /system/bin/sleep 1
    done
    return 0
}

# 还原遮蔽挂载（若已挂载）
ag_freeze_restore_mounts() {
    command -v ag_shadow_stop >/dev/null 2>&1 && ag_shadow_stop >/dev/null 2>&1
    command -v ag_shadow_restore >/dev/null 2>&1 && ag_shadow_restore >/dev/null 2>&1
    if command -v ag_sweep_dead_mounts >/dev/null 2>&1; then
        ag_sweep_dead_mounts >/dev/null 2>&1
    fi
    return 0
}

# 清理 run 目录里的 pid 文件
# 注意：不能删整个 data/run，版本监控还要靠其中的 notice.pid 排除自身
ag_freeze_clear_pids() {
    _run="$MODDIR/data/run"
    if [ -d "$_run" ]; then
        for _f in "$_run"/*.pid; do
            [ -f "$_f" ] || continue
            case "$_f" in
                */notice.pid) continue ;;   # 保留监控自身
            esac
            rm -f "$_f" 2>/dev/null
        done
    fi
    rm -f "$MODDIR/data/service.pid" 2>/dev/null
    rm -f "$AG_AUTH_DIR/.prop_daemon.pid" 2>/dev/null
    rm -rf "$MODDIR/data/.service.lock" 2>/dev/null
    return 0
}

# 主入口：$1=原因（用于标记与日志）
ag_freeze_all() {
    _why="${1:-update}"

    # 标记：防止主流程被任何方式再次拉起
    mkdir -p "$AG_NOTICE_DIR" 2>/dev/null
    {
        echo "REASON=$_why"
        echo "TIME=$(/system/bin/date +%s)"
        echo "MODDIR=$MODDIR"
    } > "$AG_FREEZE_MARK" 2>/dev/null
    chmod 644 "$AG_FREEZE_MARK" 2>/dev/null

    # 先还原挂载（依赖仍在运行的进程，必须在杀之前做）
    ag_freeze_restore_mounts

    # 终止全部进程
    ag_freeze_kill_all

    # 清 pid 文件
    ag_freeze_clear_pids

    command -v ag_log >/dev/null 2>&1 && \
        ag_log WARN "冻结完成：已终止全部模块进程（原因=$_why）"
    # LOG_LEVEL 未初始化时 ag_log 内部比较会报 bad number，直接写文件更稳
    echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') freeze reason=$_why all_procs_killed" \
        >> "$AG_NOTICE_LOG" 2>/dev/null
    return 0
}

# 是否处于冻结状态（供主流程闸门判断，不联网）
ag_is_frozen() {
    [ -f "$AG_FREEZE_MARK" ] && return 0
    return 1
}

# 解除冻结（版本追平后调用）
ag_unfreeze_all() {
    rm -f "$AG_FREEZE_MARK" 2>/dev/null
    command -v ag_log >/dev/null 2>&1 && ag_log INFO "已解除冻结"
    return 0
}
