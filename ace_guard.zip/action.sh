#!/system/bin/sh
# ============================================================
#  ACE Guard 控制台
#   带参数：sh action.sh status
#   无参数：进入交互菜单（供 MT / KSU 点击运行）
# ============================================================
MODDIR=$(/system/bin/toybox dirname "$(/system/bin/toybox readlink -f "$0")")
# action.sh 自己控制闸门，source 阶段跳过各脚本入口自检
_AG_AUTH_GUARDED=1
. "$MODDIR/script/common.sh"
. "$MODDIR/script/state.sh"
. "$MODDIR/script/hide.sh"
. "$MODDIR/script/clean.sh"
. "$MODDIR/script/shadow.sh"
. "$MODDIR/script/stealth.sh"
. "$MODDIR/script/network.sh"
. "$MODDIR/script/monitor.sh"
. "$MODDIR/script/selfcheck.sh"
. "$MODDIR/script/identity.sh"
. "$MODDIR/script/auth.sh"
. "$MODDIR/script/notice.sh"

ag_load_conf

R='\033[0;31m'; G='\033[0;32m'; Y='\033[1;33m'
B='\033[0;34m'; C='\033[0;36m'; N='\033[0m'

# KSU Action 的界面不解析 ANSI 转义，会显示成 [0;32m 这类乱码。
# 检测到没有交互终端时，全部颜色置空，输出纯文本。
if ! [ -t 1 ] 2>/dev/null; then
    R=''; G=''; Y=''; B=''; C=''; N=''
fi

hr() { echo -e "${B}────────────────────────────────────${N}"; }

# ---------- 动作实现 ----------
do_status() {
    hr; echo -e "${C}  ACE Guard 状态${N}"; hr
    if ag_auth_valid; then
        echo -e "  授权:     ${G}$(ag_auth_plan_text)${N}"
    else
        echo -e "  授权:     ${R}未授权 ($AG_AUTH_REASON)${N}"
        echo -e "  设备码:   ${Y}$(ag_auth_device_id)${N}"
    fi
    if ag_identity_load; then
        echo "  SERIAL:   $AG_SERIAL"
        echo "  IMEI:     $AG_IMEI"
        echo "  CHIPECID: $AG_CHIPECID"
        if [ "$ENABLE_ADID" = "1" ]; then
            local _a
            _a=$(ag_adid_get 0 2>/dev/null)
            echo "  ADID:     ${_a:-（未设置）}"
            bad=$(ag_identity_selftest 2>/dev/null)
        fi
        cur=$(/system/bin/getprop ro.serialno 2>/dev/null)
        [ "$cur" = "$AG_SERIAL" ] && echo -e "  应用:     ${G}已生效${N}" \
                                  || echo -e "  应用:     ${R}不一致($cur)${N}"
    else
        echo -e "  指纹:     ${Y}未初始化${N}"
    fi
    echo
    echo "  隐藏注入: 已移除(不做 /proc/modules 伪装)"
    g=$(ag_find_game_pid 2>/dev/null)
    [ -n "$g" ] && echo -e "  游戏:     ${G}运行中 PID $g${N}" || echo "  游戏:     未运行"
    m=$(/system/bin/toybox mount 2>/dev/null | /system/bin/grep -c "com.tencent.tmgp.codev")
    echo "  遮蔽挂载: $m 条"
    i=$(/system/bin/toybox ps -A 2>/dev/null | /system/bin/grep -c "shadow_cb.sh")
    echo "  监听进程: $i 个"
    bad=$(ag_check_props)
    [ -z "$bad" ] && echo -e "  属性:     ${G}正常${N}" || echo -e "  属性:     ${R}$bad${N}"
    hr
}

do_scan() {
    hr; echo -e "${C}  环境自检${N}"; hr
    echo "  [指纹]"
    echo "    SERIAL:   $(/system/bin/getprop ro.serialno 2>/dev/null)"
    echo "    boot.ser: $(/system/bin/getprop ro.boot.serialno 2>/dev/null)"
    echo "    chipecid: $(/system/bin/getprop ro.boot.chipecid 2>/dev/null)"
    a=$(/system/bin/getprop ro.serialno); b=$(/system/bin/getprop ro.boot.serialno)
    [ "$a" = "$b" ] && echo "    一致性:   ✓" || echo -e "    一致性:   ${R}✗${N}"
    echo
    echo "  [路径]"
    for p in /system/bin/su /system/xbin/su /sbin/su; do
        [ -e "$p" ] && echo -e "    ${R}★ $p 存在${N}" || echo "    ✓ $p 不存在"
    done
    su 10351 -c "/system/bin/toybox ls /data/adb" >/dev/null 2>&1 \
        && echo -e "    ${R}★ /data/adb 可访问${N}" || echo "    ✓ /data/adb 拒绝"
    echo
    echo "  [属性]"
    bad=$(ag_check_props)
    [ -z "$bad" ] && echo "    ✓ 全部正常" || echo -e "    ${R}★ 异常:$bad${N}"
    hr
}

do_rotate() {
    ag_auth_guard rotate || return 1
    local ts
    ts=$(/system/bin/date '+%Y-%m-%d %H:%M:%S')

    echo -e "${C}======== 指纹 + ADID 轮换 + 自检 ========${N}"
    echo -e "${Y}[$ts] 由 KSU Action 手动触发${N}"
    echo ""

    ag_log INFO "########## 手动轮换开始（Action）##########"

    # --- 1. 记录换之前的旧身份 ---
    local old_serial="" old_imei="" old_chipecid=""
    if ag_identity_load 2>/dev/null; then
        old_serial="$AG_SERIAL"
        old_imei="$AG_IMEI"
        old_chipecid="$AG_CHIPECID"
        ag_log INFO "旧身份: SERIAL=$old_serial IMEI=$old_imei CHIPECID=$old_chipecid"
    else
        ag_log INFO "旧身份: 无（首次生成）"
    fi

    # --- 2. 生成新身份（属性指纹 + ADID 同一次轮换）---
    echo -e "${Y}[1/3] 轮换设备身份（SERIAL / IMEI / CHIPECID / ADID）...${N}"
    local old_adid
    old_adid=$(ag_identity_get_kv ADID 2>/dev/null)
    if ! ag_identity_rotate_all; then
        echo -e "${R}  生成失败${N}"
        ag_log ERROR "轮换失败：生成新身份出错"
        return 1
    fi
    echo "  SERIAL   : ${old_serial:-（无）}  ->  $AG_SERIAL"
    echo "  IMEI     : ${old_imei:-（无）}  ->  $AG_IMEI"
    echo "  CHIPECID : ${old_chipecid:-（无）}  ->  $AG_CHIPECID"
    if [ "$ENABLE_ADID" = "1" ]; then
        echo "  ADID     : ${old_adid:-（无）}  ->  ${AG_ADID:-（未生效）}"
    else
        echo "  ADID     : 已关闭（ENABLE_ADID=0）"
    fi
    ag_log INFO "新身份: SERIAL=$AG_SERIAL IMEI=$AG_IMEI CHIPECID=$AG_CHIPECID ADID=$AG_ADID"
    echo ""

    # --- 3. 写入属性 + 各用户 ADID 实况（逐属性日志在 ag_identity_apply 内部）---
    echo -e "${Y}[2/3] 写入属性与 Android ID...${N}"
    ag_identity_apply
    if [ "$ENABLE_ADID" = "1" ]; then
        local u c
        for u in $(ag_list_users); do
            ag_user_active "$u" 2>/dev/null || continue
            c=$(ag_adid_get "$u")
            echo "  user$u ADID = ${c:-（未设置）}"
        done
    fi
    echo ""

    # --- 4. 自检 ---
    echo -e "${Y}[3/3] 执行自检...${N}"
    ag_selfcheck_boot 2>&1 | /system/bin/sed 's/^/  /'
    echo ""

    ag_log INFO "########## 手动轮换结束 ##########"

    echo -e "${G}完成${N}"
    echo -e "${Y}日志位置: $LOG_FILE${N}"
    echo ""
    echo -e "${C}--- 当前属性实际值 ---${N}"
    local k
    for k in ro.serialno ro.boot.serialno ro.boot.chipecid; do
        echo "  $k = $(/system/bin/getprop "$k" 2>/dev/null)"
    done
    for k in $IMEI_PROPS; do
        [ -n "$k" ] || continue
        echo "  $k = $(/system/bin/getprop "$k" 2>/dev/null)"
    done
    if [ "$ENABLE_ADID" = "1" ]; then
        local _u _c
        for _u in $(ag_list_users); do
            ag_user_active "$_u" 2>/dev/null || continue
            _c=$(ag_adid_get "$_u")
            echo "  android_id[user$_u] = ${_c:-（未设置）}"
        done
    fi
}

do_clean() {
    ag_auth_guard clean || return 1
    echo "执行完整清理..."
    ag_full_clean
    echo -e "${G}完成${N}"
}

do_watch() {
    i=$(/system/bin/toybox ps -A 2>/dev/null | /system/bin/grep -c "shadow_cb.sh")
    echo "监听进程: $i 个"
    echo "已遮蔽目录:"
    /system/bin/toybox cat "$AG_SHADOW_DIRS" 2>/dev/null | /system/bin/sed 's/^/  /'
    echo "遮蔽根: $(/system/bin/toybox cat "$AG_SHADOW_STATE" 2>/dev/null)"
}

do_start() {
    ag_auth_guard start || return 1
    /system/bin/pkill -f "$MODDIR/service.sh" 2>/dev/null
    /system/bin/nohup /system/bin/sh "$MODDIR/service.sh" \
        >> "$LOG_DIR/service.log" 2>&1 &
    sleep 1
    echo -e "${G}服务已启动${N}"
    /system/bin/toybox ps -A -o PID,ARGS 2>/dev/null | /system/bin/grep "service.sh" \
        | /system/bin/grep -v grep | /system/bin/sed 's/^/  /'
}

do_stop() {
    ag_auth_guard stop || return 1
    /system/bin/pkill -f "$MODDIR/service.sh" 2>/dev/null
    ag_shadow_watch_stop
    ag_shadow_restore
    echo -e "${G}服务已停止，遮蔽已还原${N}"
}

# ---------- Action 一键更新 ----------
# 流程：检查远程版本 → 需要更新则下载 → 校验 → 解压 → 重启生效
# 直装在 /data/adb/modules/ace_guard（KSU 模块目录）
# ---------- 下载链接预检 ----------
# 返回码：
#   0  链接有效、服务器可达
#  10  链接格式不合法（不是 http/https）
#  11  网络不通（DNS 失败 / 连接失败 / TLS 拦截）
#  12  服务器返回 404/403（文件不存在或无权限）
#  13  服务器无响应（超时）
ag_update_probe() {
    _u="$1"
    case "$_u" in
        http://*|https://*) ;;
        *) return 10 ;;
    esac

    # 没有 curl 就跳过预检，交给下载阶段判断
    [ -x /system/bin/curl ] || return 0

    # 注意：不能用 $(...|tail) 捕获，管道会污染退出码。
    # 先把 http_code 写文件，退出码单独保留。
    _pf="/data/adb/ace_guard/notice/.probe"
    rm -f "$_pf" "$_pf.rc" 2>/dev/null

    /system/bin/curl -sS -I -L -m 20 -o /dev/null \
        -w '%{http_code}' "$_u" > "$_pf" 2>"$_pf.err"
    _rc=$?
    echo "$_rc" > "$_pf.rc"

    _code=$(cat "$_pf" 2>/dev/null | /system/bin/toybox tr -dc '0-9')
    _err=$(cat "$_pf.err" 2>/dev/null | head -n1)
    rm -f "$_pf" "$_pf.err" 2>/dev/null

    # 记录可读原因，供上层展示
    AG_PROBE_REASON=""

    if [ "$_rc" != "0" ]; then
        case "$_rc" in
            6)  AG_PROBE_REASON="DNS 解析失败：域名无法解析" ; return 11 ;;
            7)  AG_PROBE_REASON="连接失败：服务器不可达或网络不通" ; return 11 ;;
            28) AG_PROBE_REASON="请求超时：服务器 20 秒无响应" ; return 13 ;;
            35) AG_PROBE_REASON="TLS 握手失败：连接被拦截" ; return 11 ;;
            22) AG_PROBE_REASON="服务器返回错误状态" ; return 12 ;;
            *)  AG_PROBE_REASON="请求失败（curl 代码 $_rc）${_err:+：$_err}" ; return 13 ;;
        esac
    fi

    case "$_code" in
        2*)              AG_PROBE_REASON="链接有效" ; return 0 ;;
        404|410)         AG_PROBE_REASON="安装包不存在（HTTP 404）" ; return 12 ;;
        401|403)         AG_PROBE_REASON="无权限访问（HTTP $_code）" ; return 12 ;;
        5*)              AG_PROBE_REASON="服务器错误（HTTP $_code）" ; return 13 ;;
        ''|000)          AG_PROBE_REASON="服务器无响应" ; return 13 ;;
        *)               AG_PROBE_REASON="异常状态码（HTTP $_code）" ; return 12 ;;
    esac
}

do_update() {
    hr; echo -e "${C}  ACE Guard 在线更新${N}"; hr

    if [ -z "${NOTICE_URL:-}" ]; then
        echo -e "  ${R}未配置 NOTICE_URL，无法在线更新${N}"
        echo "  请在 config/guard.conf 填写远程版本清单地址"
        hr; return 1
    fi

    echo "  正在检查远程版本..."
    ag_notice_fetch force >/dev/null 2>&1

    _local=$(ag_notice_local_vc)
    _rvc=$(ag_notice_json_get "$AG_NOTICE_JSON" versionCode num 2>/dev/null)
    _rver=$(ag_notice_json_get "$AG_NOTICE_JSON" version str 2>/dev/null)
    _durl=$(ag_notice_json_get "$AG_NOTICE_JSON" url str 2>/dev/null)
    case "$_local" in ''|*[!0-9]*) _local=0 ;; esac
    case "$_rvc" in ''|*[!0-9]*) _rvc=0 ;; esac

    if [ "$_rvc" -le "$_local" ] || [ "$_rvc" = "0" ]; then
        echo -e "  ${G}已是最新版本${N}（本地 v${_local}）"
        hr; return 0
    fi

    _lver=$(/system/bin/sed -n "s/^version=//p" "$MODDIR/module.prop" 2>/dev/null | head -n1)
    echo "  本地版本: ${_lver:-v$_local} (versionCode=${_local})"
    echo "  远程版本: ${_rver:-v${_rvc}}"
    _log=$(ag_notice_json_get "$AG_NOTICE_JSON" changelog str 2>/dev/null)
    if [ -n "$_log" ]; then
        echo "  更新内容:"
        printf '%s\n' "$_log" | while IFS= read -r _line; do
            [ -n "$_line" ] && echo "    $_line"
        done
    fi
    hr

    if [ -z "$_durl" ]; then
        echo -e "  ${R}版本清单未提供下载地址(url 为空)${N}"
        echo "  请到 WebUI 公告页或联系作者获取安装包"
        hr; return 1
    fi

    # ---- 下载 ----
    _zip="$AG_NOTICE_DIR/update.zip"
    _zip_tmp="$AG_NOTICE_DIR/.update.part"
    rm -f "$_zip" "$_zip_tmp" 2>/dev/null

    # ---- 下载前预检：先确认 URL 有效、服务器可达、确实是安装包 ----
    echo "  正在检查下载链接..."
    # 直接调用，用 $? 取返回码（不能用 $() 捕获，那样会丢掉退出码）
    AG_PROBE_REASON=""
    ag_update_probe "$_durl"
    _chk_rc=$?
    case "$_chk_rc" in
        0)  echo "  链接有效（${AG_PROBE_REASON}），开始下载" ;;
        10) echo -e "  ${R}下载失败${N}：下载链接格式无效"
            echo "  原因：version.json 里的 url 不是 http/https 地址"
            hr; return 1 ;;
        11) echo -e "  ${R}下载失败${N}：网络不通"
            echo "  原因：${AG_PROBE_REASON}"
            echo "  请检查手机能否正常上网（WiFi / 移动数据）"
            hr; return 1 ;;
        12) echo -e "  ${R}下载失败${N}：安装包不存在"
            echo "  原因：${AG_PROBE_REASON}"
            echo "  请检查 version.json 里的 url 是否指向真实存在的文件"
            hr; return 1 ;;
        13) echo -e "  ${R}下载失败${N}：服务器无响应"
            echo "  原因：${AG_PROBE_REASON}"
            hr; return 1 ;;
        *)  echo -e "  ${R}下载失败${N}：链接检查未通过"
            echo "  原因：${AG_PROBE_REASON:-未知}"
            hr; return 1 ;;
    esac

    # ---- 真实下载：只有确实拿到字节才显示进度 ----
    echo "  正在下载安装包..."
    _dl_ok=1
    _try=0
    _dl_err=""
    for _src in "$_durl" "https://ghfast.top/${_durl}" "https://gh-proxy.com/${_durl}"; do
        [ -n "$_src" ] || continue
        _try=$(( _try + 1 ))
        rm -f "$_zip_tmp" 2>/dev/null
        if [ -x /system/bin/curl ]; then
            # --progress-bar 只在真正传输数据时才出现
            _dl_err=$(/system/bin/curl -L -f -m 300 --progress-bar \
                        -o "$_zip_tmp" "$_src" 2>&1 >/dev/null)
            _rc=$?
            _sz=$(/system/bin/toybox stat -c %s "$_zip_tmp" 2>/dev/null || echo 0)
            if [ "$_rc" = "0" ] && [ "$_sz" -gt 1024 ]; then
                _dl_ok=0
                break
            fi
        fi
        [ "$_try" -lt 3 ] && echo "  下载中断，切换备用源重试（${_try}/3）..."
    done

    if [ "$_dl_ok" != "0" ]; then
        _sz=$(/system/bin/toybox stat -c %s "$_zip_tmp" 2>/dev/null || echo 0)
        rm -f "$_zip_tmp" 2>/dev/null
        echo -e "  ${R}下载失败${N}"
        # 依据 curl 的退出码判定真实原因
        case "${_rc:-0}" in
            6)  echo "  原因：DNS 解析失败，域名无法解析（检查网络或 DNS）" ;;
            7)  echo "  原因：连接服务器失败（网络不通，或该地址被墙/被封）" ;;
            22) echo "  原因：服务器返回错误状态（404 安装包不存在 / 403 无权限）" ;;
            28) echo "  原因：下载超时（网络太慢或服务器无响应）" ;;
            35) echo "  原因：TLS 握手失败（网络被中间人拦截）" ;;
            *)  echo "  原因：下载中断（已尝试 3 个源，实际收到 ${_sz} 字节）"
                [ -n "$_dl_err" ] && echo "  详情：$(printf '%s' "$_dl_err" | tail -n1)" ;;
        esac
        hr; return 1
    fi
    mv -f "$_zip_tmp" "$_zip" 2>/dev/null
    echo "  下载完成，正在校验安装包..."
    # ---- 校验是否为合法 zip ----
    if ! /data/adb/ksu/bin/busybox unzip -t "$_zip" >/dev/null 2>&1; then
        echo -e "  ${R}文件校验失败${N}：下载包不是有效 zip，已删除"
        rm -f "$_zip" 2>/dev/null
        hr; return 1
    fi

    # ---- 交给 KernelSU 安装（标准安装流程，自动处理挂载/权限/重启提示）----
    _ksud="/data/adb/ksu/bin/ksud"
    if [ ! -x "$_ksud" ]; then
        echo -e "  ${R}未找到 ksud${N}，无法调用系统安装器"
        rm -f "$_zip" 2>/dev/null
        hr; return 1
    fi

    echo "  正在安装（KernelSU 安装器）..."
    hr
    "$_ksud" module install "$_zip" 2>&1
    _inst_rc=$?
    hr

    if [ "$_inst_rc" != "0" ]; then
        echo -e "  ${R}安装失败${N}（ksud 返回 $_inst_rc）"
        echo "  安装包已保留：$_zip"
        hr; return 1
    fi

    # ---- 清理冻结标记，让新版本正常启动 ----
    rm -f "$AG_FREEZE_FLAG" "$AG_FREEZE_MARK" 2>/dev/null

    # ---- 重置 .module.prop.orig 到新版本，避免卡片刷新时回退版本号 ----
    if [ -f "$MODDIR/module.prop" ]; then
        _nbase=$(/system/bin/grep -v '^description=' "$MODDIR/module.prop" 2>/dev/null)
        _ndesc=$(/system/bin/sed -n 's/^description=//p' "$MODDIR/module.prop" 2>/dev/null | head -n1)
        _ndesc=$(printf '%s' "$_ndesc" | sed 's/^【[^】]*】//; s/^⚠️ //')
        if [ -n "$_nbase" ]; then
            {
                printf '%s\n' "$_nbase"
                printf 'description=%s\n' "$_ndesc"
            } > "$MODDIR/.module.prop.orig" 2>/dev/null
            chmod 644 "$MODDIR/.module.prop.orig" 2>/dev/null
        fi
    fi

    # ---- 刷新卡片并重新拉起监控 ----
    . "$MODDIR/script/notice.sh" 2>/dev/null
    ag_notice_evaluate >/dev/null 2>&1
    /system/bin/sh "$MODDIR/bin/ag_prop_daemon.sh" start >/dev/null 2>&1

    rm -f "$_zip" 2>/dev/null

    hr
    _newver=$(/system/bin/sed -n 's/^version=//p' "$MODDIR/module.prop" 2>/dev/null | head -n1)
    echo -e "  ${G}安装完成${N}: ${_lver:-v$_local} → ${_newver:-新版本}"
    echo -e "  ${Y}请重启设备完成更新${N}"
    hr
    return 0
}

# ---------- 带参数执行 ----------
run_cmd() {
    case "$1" in
        status)   do_status ;;
        scan)     do_scan ;;
        start)    do_start ;;
        stop)     do_stop ;;
        reload)   ag_load_conf; echo -e "${G}配置已重载${N}" ;;
        update)   do_update ;;
        rotate)   do_rotate ;;
        clean)    do_clean ;;
        watch)    do_watch ;;
        selfcheck|sc) ag_selfcheck_boot ;;
        log)      /system/bin/toybox tail -n "${2:-30}" "$LOG_FILE" 2>/dev/null || echo "无日志" ;;
        clearlog) : > "$LOG_FILE"; echo "已清空" ;;
        *)        return 1 ;;
    esac
    return 0
}

# ---------- 交互菜单 ----------
menu() {
    if ! ag_auth_valid; then
        ag_auth_deny_text
        return 1
    fi
    while true; do
        clear 2>/dev/null
        hr
        echo -e "${C}        ACE Guard${N}"
        hr
        echo -e "  ${G}1${N}) 查看状态"
        echo -e "  ${G}2${N}) 环境自检"
        echo -e "  ${G}3${N}) 轮换指纹"
        echo -e "  ${G}4${N}) 立即清理"
        echo -e "  ${G}5${N}) 查看遮蔽"
        echo -e "  ${G}6${N}) 启动服务"
        echo -e "  ${G}7${N}) 停止服务"
        echo -e "  ${G}8${N}) 重载配置"
        echo -e "  ${G}9${N}) 查看日志"
        echo -e "  ${G}0${N}) 退出"
        hr
        printf "请选择: "
        read -r choice
        echo
        case "$choice" in
            1) do_status ;;
            2) do_scan ;;
            3) do_rotate ;;
            4) do_clean ;;
            5) do_watch ;;
            6) do_start ;;
            7) do_stop ;;
            8) ag_load_conf; echo -e "${G}配置已重载${N}" ;;
            9) /system/bin/toybox tail -n 30 "$LOG_FILE" 2>/dev/null || echo "无日志" ;;
            0|q|Q) echo "退出"; break ;;
            *) echo -e "${R}无效选择${N}" ;;
        esac
        echo
        printf "按回车继续..."
        read -r _
    done
}

# ---------- 入口 ----------
if [ -n "$1" ]; then
    run_cmd "$@" || {
        hr; echo -e "${Y}未知命令: $1${N}"; hr
        echo "可用: status scan start stop reload update rotate clean watch selfcheck log clearlog"
        hr
    }
else
    # 无参数：
    #   - 有交互终端 -> 进菜单
    #   - 无终端（KSU Action 按钮的场景）-> 直接执行轮换
    #     KSU 的 Action 只是把 stdout 抓走显示，没有 stdin，无法交互。
    if [ -t 0 ] 2>/dev/null; then
        menu
    else
        # 优先判断是否有新版本：有则直接一键更新（更新不受授权闸门限制）
        # 这样卡片提示「执行操作(Action)一键更新」时，点按钮就能直接完成
        if ag_notice_need_update 2>/dev/null; then
            ag_log INFO "Action 按钮触发：检测到新版本，进入一键更新"
            do_update
            exit $?
        fi

        # 记录一次触发来源，便于日志追溯
        if ! ag_auth_valid; then
            ag_log WARN "Action 按钮触发但未授权，已拒绝执行"
            ag_auth_deny_text
            exit 0
        fi
        ag_log INFO "Action 按钮触发（无交互终端，自动执行轮换）"
        do_rotate
        echo ""
        echo "────────────────────────────────"
        echo "KSU Action 已完成：指纹 + ADID 轮换 + 自检"
        echo "可用参数（需在终端中执行）:"
        echo "  sh action.sh status / scan / update / rotate / clean / selfcheck"
        echo "────────────────────────────────"
    fi
fi
