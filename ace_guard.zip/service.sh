#!/system/bin/sh
# ============================================================
#  ACE Guard 常驻服务
#   未授权：立即退出，不启动任何守护线程、不挂载任何目录
#   已在运行：去重后由本实例接管，最终恰好一份（v1.9.4）
# ============================================================
MODDIR=$(/system/bin/toybox dirname "$(/system/bin/toybox readlink -f "$0")")
. "$MODDIR/script/common.sh"
# service.sh 自己控制闸门，source 阶段跳过各脚本入口自检
_AG_AUTH_GUARDED=1
. "$MODDIR/script/state.sh"
. "$MODDIR/script/hide.sh"
. "$MODDIR/script/clean.sh"
. "$MODDIR/script/shadow.sh"
. "$MODDIR/script/stealth.sh"
. "$MODDIR/script/network.sh"
. "$MODDIR/script/monitor.sh"
. "$MODDIR/script/selfcheck.sh"
. "$MODDIR/script/identity.sh"

ag_load_conf

# ============================================================
#  重复实例去重（v1.9.4）
#
#  原则：把「重复」收敛成「唯一实例」，而不是放弃启动。
#  扫描所有 service.sh 主进程 → 杀掉非自己的 → 本实例接管继续启动。
#  无论从 KSU / 手动 / WebUI 哪进，跑完总是恰好一份在运行。
#
#  自我识别用 $$（shell 主 PID，生命周期内稳定）。
#  注意：绝不能用 readlink /proc/self —— 它在 $() 命令替换里会 fork
#        子进程，读到的是子进程 PID，每次都变，会误判自己。
# ============================================================
AG_LOCK_DIR="$MODDIR/data"
AG_PIDFILE="$AG_LOCK_DIR/service.pid"
AG_RUNLOCK="$AG_LOCK_DIR/.service.lock"

# 判断某 PID 是否存活（非僵尸）
ag_pid_alive() {
    case "$1" in ''|*[!0-9]*) return 1 ;; esac
    [ -d "/proc/$1" ] || return 1
    case "$(/system/bin/toybox cat "/proc/$1/stat" 2>/dev/null)" in
        *") Z "*) return 1 ;;
    esac
    return 0
}

# 列出所有 service.sh 主进程 PID（不含自己）
ag_svc_find_other() {
    _self="$$"
    /system/bin/toybox ps -A -o PID,ARGS 2>/dev/null \
        | /system/bin/grep -F "ace_guard/service.sh" \
        | /system/bin/grep -vF "sh -c" \
        | while IFS= read -r _l; do
              _p=$(printf '%s' "$_l" | /system/bin/toybox tr -s ' ' | /system/bin/toybox cut -d' ' -f2)
              case "$_p" in ''|*[!0-9]*) continue ;; esac
              [ "$_p" = "$_self" ] && continue
              printf '%s\n' "$_p"
          done | /system/bin/toybox sort -u
}

# 杀掉某进程的全部子进程（守护子进程）
ag_svc_kill_children() {
    _pp="$1"
    case "$_pp" in ''|*[!0-9]*) return 0 ;; esac
    /system/bin/toybox ps -A -o PID,PPID 2>/dev/null \
        | while IFS= read -r _l; do
              _c=$(printf '%s' "$_l" | /system/bin/toybox tr -s ' ' | /system/bin/toybox cut -d' ' -f2)
              _par=$(printf '%s' "$_l" | /system/bin/toybox tr -s ' ' | /system/bin/toybox cut -d' ' -f3)
              case "$_c" in ''|*[!0-9]*) continue ;; esac
              [ "$_par" = "$_pp" ] && /system/bin/toybox kill -9 "$_c" 2>/dev/null
          done
}

ag_svc_singleton() {
    mkdir -p "$AG_LOCK_DIR" 2>/dev/null
    _me="$$"

    _svc_log() { ag_log WARN "$1"; }

    # ---- 清扫所有旧实例（两轮，确保杀干净）----
    _killed=""
    _round=0
    while [ "$_round" -lt 2 ]; do
        _round=$((_round + 1))
        for _p in $(ag_svc_find_other); do
            ag_pid_alive "$_p" || continue
            ag_svc_kill_children "$_p"
            /system/bin/toybox kill -9 "$_p" 2>/dev/null
            _killed="$_killed $_p"
        done
        /system/bin/sleep 1
    done

    _killed=$(printf '%s' "$_killed" | /system/bin/toybox tr ' ' '\n' | /system/bin/toybox sort -u | /system/bin/toybox tr '\n' ' ')
    _killed=$(printf '%s' "$_killed" | /system/bin/toybox sed 's/^ *//;s/ *$//')
    if [ -n "$_killed" ]; then
        _svc_log "已去重旧实例: $_killed （本实例 $_me 接管运行）"
    fi

    # ---- 接管锁 ----
    rm -rf "$AG_RUNLOCK" 2>/dev/null
    mkdir -p "$AG_RUNLOCK" 2>/dev/null
    printf '%s\n' "$_me" > "$AG_RUNLOCK/pid" 2>/dev/null
    printf '%s\n' "$_me" > "$AG_PIDFILE" 2>/dev/null
    chmod 600 "$AG_PIDFILE" 2>/dev/null

    trap 'rm -rf "$AG_RUNLOCK" 2>/dev/null; rm -f "$AG_PIDFILE" 2>/dev/null' EXIT INT TERM
    return 0
}

# 去重并接管
ag_svc_singleton


# ---------- 后台子系统启动器 ----------
# KSU 执行完 service.sh 会清理其进程组，直接 ( cmd ) & 会被一起杀掉。
# 用 setsid 创建新会话，彻底脱离父进程组；同时重定向所有 fd。
ag_spawn() {
    _fn="$1"
    AG_SPAWN_PARENT="$$"
    export AG_SPAWN_PARENT
    # 角色标记（供子进程内部使用）
    AG_ROLE="$_fn"
    export AG_ROLE
    # 子进程启动后立即把自己的 PID 写入 data/run/<角色>.pid
    # 统计时直接读文件判活，不必遍历 /proc（v2.0.0）
    _run_dir="$DATA_DIR/run"
    mkdir -p "$_run_dir" 2>/dev/null
    _script="
        mkdir -p '$_run_dir' 2>/dev/null
        echo \$\$ > '$_run_dir/$_fn.pid' 2>/dev/null
        . '$MODDIR/script/common.sh'
        . '$MODDIR/script/state.sh'
        . '$MODDIR/script/hide.sh'
        . '$MODDIR/script/clean.sh'
        . '$MODDIR/script/shadow.sh'
        . '$MODDIR/script/stealth.sh'
        . '$MODDIR/script/network.sh'
        . '$MODDIR/script/monitor.sh'
        . '$MODDIR/script/selfcheck.sh'
        . '$MODDIR/script/identity.sh'
        ag_load_conf
        $_fn
    "
    if command -v setsid >/dev/null 2>&1; then
        AG_ROLE="$_fn" setsid /system/bin/sh -c "$_script" </dev/null >>"$LOG_DIR/service.log" 2>&1 &
    else
        AG_ROLE="$_fn" nohup /system/bin/sh -c "$_script" </dev/null >>"$LOG_DIR/service.log" 2>&1 &
    fi
    unset AG_ROLE
}

# ---------- 授权闸门 ----------
. "$MODDIR/script/auth.sh"
. "$MODDIR/script/notice.sh"
ag_auth_snapshot_init
ag_auth_validate_silent
ag_auth_update_prop 2>/dev/null

# ---------- 远程版本监控（必须在闸门之前拉起）----------
# 冻结时业务进程全被杀，只有这条外部循环能发现「本地版本已追平」并自动解冻。
# 启动时先按当前本地版本复核一次，清掉可能残留的过期标记。
ag_start_notice_monitor() {
    [ -n "${NOTICE_URL:-}" ] || return 0
    _md="$MODDIR"
    _script="
        MODDIR='$_md'
        export MODDIR
        . '$_md/script/common.sh' 2>/dev/null
        . '$_md/script/notice.sh'
        ag_load_conf
        ag_notice_daemon
    "
    if command -v setsid >/dev/null 2>&1; then
        setsid /system/bin/sh -c "$_script" </dev/null >>"$LOG_DIR/service.log" 2>&1 &
    else
        nohup /system/bin/sh -c "$_script" </dev/null >>"$LOG_DIR/service.log" 2>&1 &
    fi
}

# 启动即复核一次本地版本（手动改 prop 后重启服务也能立刻解冻）
_sig_now=$(ag_notice_local_sig)
_sig_old=$(cat "$AG_NOTICE_DIR/.local_sig" 2>/dev/null)
if [ "$_sig_now" != "$_sig_old" ] && ag_notice_state_load 2>/dev/null; then
    ag_notice_evaluate >/dev/null 2>&1
fi

ag_start_notice_monitor
/system/bin/sh "$MODDIR/bin/ag_prop_daemon.sh" start >/dev/null 2>&1

# ---------- 远程版本闸门 ----------
# 有新版本时：终止全部模块进程 + 还原挂载，只留卡片提示与监控进程
if ag_notice_need_update; then
    ag_log WARN "检测到新版本 $AG_N_REMOTE_VER（远程 $AG_N_REMOTE_VC > 本地 $(ag_notice_local_vc)），执行冻结"
    ag_freeze_all "service_gate" 2>/dev/null
    ag_auth_update_prop 2>/dev/null
    # 冻结会连带杀掉监控进程，这里重新拉起，否则永远无法自动解冻
    ag_start_notice_monitor
    /system/bin/sh "$MODDIR/bin/ag_prop_daemon.sh" start >/dev/null 2>&1
    exit 0
fi

/system/bin/sh "$MODDIR/bin/ag_prop_daemon.sh" start >/dev/null 2>&1

if [ "$AG_AUTH_OK" != "1" ]; then
    ag_log WARN "未授权：service.sh 拒绝启动（设备码 $(ag_auth_device_id) / $AG_AUTH_REASON）"
    exit 0
fi

until [ "$(/system/bin/getprop sys.boot_completed 2>/dev/null)" = "1" ]; do
    /system/bin/sleep 2
done
/system/bin/sleep 25

# 0. 授权复查
if ! ag_auth_valid; then
    ag_log WARN "服务启动时授权复查失败：$AG_AUTH_REASON"
    ag_auth_update_prop 2>/dev/null
    exit 0
fi

# 1. 设备身份（SERIAL/IMEI/CHIPECID/ADID 一体）
ag_identity_load >/dev/null 2>&1
ag_identity_ensure
ag_identity_apply_all keep

# 2. 空源目录
ag_hide_empty

# 3. 目录遮蔽
if [ "$ENABLE_SHADOW" = "1" ]; then
    ag_spawn 'ag_shadow_lifecycle'
fi

# 4. 配置伪装
if [ "$ENABLE_GREEN_LOCK" = "1" ]; then
    ag_gen_green
    ag_spawn 'ag_mem_check_loop'
fi

# 5. 清理悬空挂载
ag_sweep_dead_mounts

# 6. 网络层
ag_ipt_cycle_cleanup
if [ "$ENABLE_NET_BLOCK" = "1" ]; then
    ag_ipt_init
    ag_ipt_refresh
fi

# 7. 守护
if [ "$ENABLE_GUARD" = "1" ]; then
    ag_spawn 'ag_guard_inside'
fi

# 8. 后台维护
ag_spawn 'ag_housekeeping_loop'
setsid /system/bin/sh "$MODDIR/bin/ag_cache_warm.sh" </dev/null >/dev/null 2>&1 &

# 8.5 远程版本监控已在闸门之前拉起（见 ag_start_notice_monitor），此处不再重复
ag_log INFO "远程版本检查：$([ -n "${NOTICE_URL:-}" ] && echo "$NOTICE_URL 间隔 ${NOTICE_INTERVAL}s" || echo 未启用)"

# 9. 开机自检
if [ "$ENABLE_SELFCHECK_BOOT" = "1" ]; then
    ( sleep 12; ag_selfcheck_boot ) &
fi

# 10. 监控主循环
if [ "$ENABLE_MONITOR" = "1" ]; then
    ag_monitor_loop
else
    ag_log INFO "监控已关闭"
    while true; do
        /system/bin/sleep 120
    done
fi
