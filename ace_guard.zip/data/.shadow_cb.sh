#!/system/bin/sh
# $1=event $2=dir $3=name
[ -n "$3" ] && [ "$3" != "." ] || exit 0
case "$1" in
    n*|c*)
        MODDIR=$(/system/bin/toybox dirname "$(dirname "$0")")
        . "$MODDIR/script/common.sh"
        . "$MODDIR/script/clean.sh"
        . "$MODDIR/script/shadow.sh"
        ag_load_conf
        base=$(ag_game_dirs | /system/bin/head -1)
        [ -n "$base" ] || exit 0
        t="$2/$3"
        [ -d "$t" ] || exit 0
        # 只在风险目录名单内才遮蔽
        name="$3"
        for d in $RISK_DIRS $CACHE_RISK_SUB; do
            [ "$d" = "$name" ] || continue
            ag_shadow_one "$t" && ag_log INFO "动态遮蔽 $t"
            break
        done
        ;;
esac
exit 0
