#!/system/bin/sh

# >>> AG-AUTH-GUARD >>>
# 授权闸门（性能优化版）
#   1) 同进程内复用：_AG_AUTH_GUARDED=1 直接跳过
#   2) 跨进程复用：60 秒内通过的标记文件，避免每次 source 都跑 sha256
#   3) 缓存失效才真正校验
if [ "${_AG_AUTH_GUARDED:-0}" != "1" ]; then
    _ag_gcache="/data/adb/ace_guard/auth/.guardok"
    _ag_gok=0
    if [ -f "$_ag_gcache" ]; then
        _ag_gt=$(cat "$_ag_gcache" 2>/dev/null)
        _ag_now=$(/system/bin/date +%s)
        # 60 秒内的标记视为有效
        case "$_ag_gt" in
            ''|*[!0-9]*) : ;;
            *) [ $(( _ag_now - _ag_gt )) -lt 60 ] && _ag_gok=1 ;;
        esac
    fi
    if [ "$_ag_gok" != "1" ]; then
        if [ -f "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh" ]; then
            . "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh"
            if ! ag_auth_guard "${0##*/}" 2>/dev/null; then
                echo "此设备未授权，功能已冻结" >&2
                exit 1
            fi
            /system/bin/date +%s > "$_ag_gcache" 2>/dev/null
        fi
    fi
fi
_AG_AUTH_GUARDED=1
# <<< AG-AUTH-GUARD <<<

# ============================================================
#  ACE Guard 配置伪装
#  严格移植 上号.sh: gen_green_data / lock_green / mem_integrity_check
#  不自行发明机制：上锁方式、检测方式、重建条件均与参考脚本一致
# ============================================================

# ---------- 定位游戏数据目录（自带，不依赖 monitor.sh）----------
ag_stealth_base() {
    local d best="" bestn=-1 n
    for d in $(ag_game_data_dirs); do
        [ -d "$d" ] || continue
        n=$(/system/bin/toybox ls -A "$d/files" 2>/dev/null | /system/bin/toybox wc -l)
        [ -z "$n" ] && n=0
        if [ "$n" -gt "$bestn" ]; then
            bestn=$n
            best="$d"
        fi
    done
    [ -n "$best" ] && echo "$best"
}

# ---------- 生成"正常用户"配置 ----------
# 移植 上号.sh gen_green_data，字段与取值完全一致
ag_gen_green() {
    local base prefs xml
    base=$(ag_stealth_base) || return 1
    [ -n "$base" ] || return 1
    prefs="$base/shared_prefs"
    xml="$prefs/ace_config.xml"
    /system/bin/mkdir -p "$prefs" 2>/dev/null

    local NOW DEV_SCORE LOGIN_DAYS DAILY_MATCH LAST_CHECK
    NOW=$(/system/bin/date +%s)
    DEV_SCORE=$((RANDOM % 7 + 90))
    LOGIN_DAYS=$((RANDOM % 60 + 40))
    DAILY_MATCH=$((RANDOM % 7 + 2))
    LAST_CHECK=$((NOW - RANDOM % 28800))

    cat > "$xml" <<EOF
<?xml version="1.0" encoding="utf-8"?>
<map>
<boolean name="observe_enable" value="false"/>
<boolean name="behavior_track" value="false"/>
<boolean name="behavior7_enable" value="false"/>
<boolean name="weekly_stat" value="false"/>
<boolean name="longterm_observe" value="false"/>
<boolean name="seven_day_eval" value="false"/>
<boolean name="touch_sample_enable" value="false"/>
<int name="risk_score" value="0"/>
<int name="risk_level" value="0"/>
<int name="device_health" value="$DEV_SCORE"/>
<int name="login_days" value="$LOGIN_DAYS"/>
<int name="daily_match" value="$DAILY_MATCH"/>
<long name="last_security_check" value="$LAST_CHECK"/>
<string name="behavior_tag">normal_green_user</string>
<string name="long_risk_tag">none</string>
<string name="abnormal_record">empty</string>
<string name="cheat_flag">false</string>
<int name="macro_count" value="0"/>
<int name="fast_click_count" value="0"/>
<int name="abnormal_move" value="0"/>
<int name="auto_click" value="0"/>
<int name="speed_move" value="0"/>
<boolean name="geo_risk_check" value="false"/>
<boolean name="login_limit_popup" value="false"/>
<int name="login_risk_timer" value="0"/>
</map>
EOF
    # 归属改回游戏 UID，否则游戏读不到
    local uid
    uid=$(/system/bin/stat -c %u "$base" 2>/dev/null)
    [ -n "$uid" ] && /system/bin/chown "$uid:$uid" "$xml" 2>/dev/null
    ag_log INFO "ace_config.xml 已生成"
    return 0
}

# ---------- 锁定配置 ----------
# chmod 444 + 自 bind（root field 与挂载点相同，不泄露模块路径）
# 幂等：重复调用只保留一条 bind，绝不叠加
#   v2.4.1：旧实现写死 umount 三次，叠加超过 3 条时摘不干净，
#           残留累积后自检一直报「无游戏却存在残留 bind」。
ag_lock_green() {
    local base xml cnt i
    base=$(ag_stealth_base) || return 1
    [ -n "$base" ] || return 1
    xml="$base/shared_prefs/ace_config.xml"
    [ -f "$xml" ] || return 1

    /system/bin/chmod 444 "$xml" 2>/dev/null

    # 先摘到归零，再重新挂一条，保证任何时刻最多一条
    # bind 挂在 init 命名空间上，本进程 umount 摘不掉，必须 nsenter
    i=0
    while [ "$i" -lt 8 ]; do
        cnt=$(/system/bin/nsenter --target 1 --mount -- \
              /system/bin/toybox mount 2>/dev/null | /system/bin/grep -c " on $xml ")
        case "$cnt" in ''|*[!0-9]*) cnt=0 ;; esac
        [ "$cnt" -eq 0 ] && break
        /system/bin/nsenter --target 1 --mount -- \
            /system/bin/toybox umount -l "$xml" 2>/dev/null
        /system/bin/toybox umount -l "$xml" 2>/dev/null
        i=$((i + 1))
    done
    /system/bin/toybox mount --bind "$xml" "$xml" 2>/dev/null
    /system/bin/toybox mount -o remount,ro,bind "$xml" "$xml" 2>/dev/null
    return 0
}

# 解除配置锁定
#   v2.4.1 修复：不再依赖 ag_stealth_base 能不能找到数据目录。
#   旧实现在「游戏目录一时找不到」时直接 return 1，bind 就留在那儿没人收，
#   自检报「无游戏却存在残留 bind」。现改为按所有已知游戏目录兜底清理，
#   并且把重复叠加的条目全部摘干净（一场一轮 umount 只摘一条）。
ag_unlock_green() {
    local base xml cnt i cleaned=0
    # 收集全部候选路径：优先 ag_stealth_base，再补 ag_game_data_dirs
    local _bases=""
    base=$(ag_stealth_base 2>/dev/null)
    [ -n "$base" ] && _bases="$base"
    for base in $(ag_game_data_dirs 2>/dev/null); do
        case "|$_bases|" in
            *"|$base|"*) continue ;;
        esac
        _bases="$_bases $base"
    done
    # 最后补一遍通配路径，覆盖实测中 /data/user/10 不存在、
    # 真实目录只在 /data_mirror/data_ce 下的情况
    for base in /data_mirror/data_ce/null/*/"$PKG" \
                /data/user/*/"$PKG" \
                /data/data/"$PKG"; do
        [ -d "$base" ] || continue
        case "|$_bases|" in
            *"|$base|"*) continue ;;
        esac
        _bases="$_bases $base"
    done

    for base in $_bases; do
        xml="$base/shared_prefs/ace_config.xml"
        [ -f "$xml" ] || continue
        # 关键：bind 是挂在 init 命名空间上的，本进程 umount 摘不掉，
        # 必须 nsenter 进 pid 1 的 mount 命名空间才生效。
        # 这两个路径在 /data_mirror 与 /data/user 下其实是同一份文件，
        # 一次 umount 会让两个视图一起消失，所以两边都试。
        i=0
        while [ "$i" -lt 8 ]; do
            cnt=$(/system/bin/nsenter --target 1 --mount -- \
                  /system/bin/toybox mount 2>/dev/null | /system/bin/grep -c " on $xml ")
            case "$cnt" in ''|*[!0-9]*) cnt=0 ;; esac
            [ "$cnt" -eq 0 ] && break
            /system/bin/nsenter --target 1 --mount -- \
                /system/bin/toybox umount -l "$xml" 2>/dev/null
            # 本进程命名空间里若也有一份，顺手摘掉
            /system/bin/toybox umount -l "$xml" 2>/dev/null
            i=$((i + 1))
            cleaned=$((cleaned + 1))
        done
        # 权限也一起放回可读写，否则下次生成会被 444 挡住
        [ "$(stat -c %a "$xml" 2>/dev/null)" != "644" ] && \
            /system/bin/chmod 644 "$xml" 2>/dev/null
    done
    [ "$cleaned" -gt 0 ] && ag_log INFO "配置伪装：已解除 $cleaned 条残留挂载"
    return 0
}

# ---------- 完整性校验 ----------
# 移植 上号.sh mem_integrity_check：文件存在但 mount 里查不到 → 重生成+上锁
ag_mem_check_loop() {
    [ "${ENABLE_GREEN_LOCK:-1}" = "1" ] || return 0
    ag_log INFO "配置完整性校验启动（仅游戏运行时校验）"

    local base xml _busy=0
    while true; do
        ag_orphan_check
        if ! ag_game_running >/dev/null 2>&1; then
            # 无游戏：上一轮若校验过，收尾卸掉自 bind，之后纯等待
            if [ "$_busy" = "1" ]; then
                base=$(ag_stealth_base)
                if [ -n "$base" ]; then
                    xml="$base/shared_prefs/ace_config.xml"
                    /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $xml " && \
                        /system/bin/toybox umount -l "$xml" 2>/dev/null
                fi
                _busy=0
                ag_log INFO "配置校验：游戏已退出，停止校验"
            fi
            /system/bin/sleep "${GREEN_CHECK_INTERVAL:-12}"
            continue
        fi
        _busy=1

        base=$(ag_stealth_base)
        if [ -n "$base" ]; then
            xml="$base/shared_prefs/ace_config.xml"
            if [ -f "$xml" ]; then
                if ! /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $xml "; then
                    ag_gen_green
                    ag_lock_green
                    ag_log WARN "检测配置被篡改，重新还原上锁"
                fi
            fi
        fi
        /system/bin/sleep "${GREEN_CHECK_INTERVAL:-12}"
    done
}
