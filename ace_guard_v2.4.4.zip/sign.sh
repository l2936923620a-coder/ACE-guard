#!/system/bin/sh
# ============================================================
#  ACE Guard 更新清单签名工具
#
#  用法：
#    sh sign.sh <版本号> <版本码> <最低版本> <停止版本> <下载地址> [更新内容]
#
#  示例：
#    sh sign.sh v2.3.0 230 201 200 \
#      "https://raw.githubusercontent.com/l2936923620a-coder/ACE-guard/main/ace_guard_v2.3.0.zip" \
#      "1. 修复问题"
#
#  说明：
#    签名由模块内置的核心程序计算，密钥不暴露在脚本中。
# ============================================================

SELF_DIR=$(/system/bin/toybox dirname "$(/system/bin/toybox readlink -f "$0")")
AG_CORE="$SELF_DIR/lib/agcore"

if [ $# -lt 5 ]; then
    cat <<'USAGE'
用法: sh sign.sh <版本号> <版本码> <最低版本> <停止版本> <下载地址> [更新内容]

参数说明:
  版本号    显示用，如 v2.3.0
  版本码    整数，必须递增，如 230
  最低版本  低于此值提示升级，一般填 201
  停止版本  低于此值强制停止，一般填 200
  下载地址  必须是 raw.githubusercontent.com 直链（blob 是网页，不能用）
  更新内容  可选，多行用 \n 分隔

注意：任何字段变化都必须重新签名
USAGE
    exit 1
fi

VER="$1"; VC="$2"; MIN="$3"; KILL="$4"; URL="$5"; LOG="${6:-}"

if [ ! -x "$AG_CORE" ]; then
    echo "错误：找不到核心程序 $AG_CORE" >&2
    exit 1
fi

MSG="${VER}|${VC}|${MIN}|${KILL}|${URL}"
SIG=$("$AG_CORE" sign "$MSG" 2>/dev/null | head -n1)

if [ -z "$SIG" ]; then
    echo "签名计算失败" >&2
    exit 1
fi

cat <<EOF
{
  "version": "${VER}",
  "versionCode": ${VC},
  "minAllowed": ${MIN},
  "killBelow": ${KILL},
  "url": "${URL}",
  "changelog": "${LOG}",
  "sig": "${SIG}"
}
EOF
