#!/system/bin/sh
# ACE Guard 隐藏运行环境
#
# 作用：把守护进程的入口脚本放到 tmpfs 隐藏目录，使进程命令行里
#       不出现模块路径与功能标识，降低被 /proc 探针发现的概率。
# 清理：/dev 是 tmpfs，重启自动消失；卸载模块时由 uninstall.sh 删除。

AG_RUN_HIDE="/dev/.agr"

# 建立隐藏目录并生成各守护进程的入口
ag_hide_prepare() {
    mkdir -p "$AG_RUN_HIDE" 2>/dev/null || return 1
    chmod 700 "$AG_RUN_HIDE" 2>/dev/null
    rm -f "$AG_RUN_HIDE"/* 2>/dev/null

    _md="${MODDIR:-/data/adb/modules/ace_guard}"

    # 版本监控
    _gen "$AG_RUN_HIDE/nrun.sh" "$_md" "notice.sh" "ag_role=notice_monitor; ag_notice_daemon"
    # 卡片守护
    _gen "$AG_RUN_HIDE/prun.sh" "$_md" ""          "ag_role=prop_daemon; exec /system/bin/sh \"\$MODDIR/bin/ag_prop_daemon.sh\" __loop"
    # 遮蔽生命周期
    _gen "$AG_RUN_HIDE/srun.sh" "$_md" "shadow.sh" "ag_role=shadow_lifecycle; ag_shadow_lifecycle"
    # 配置完整性
    _gen "$AG_RUN_HIDE/mrun.sh" "$_md" "stealth.sh" "ag_role=mem_check_loop; ag_mem_check_loop"
    # 清理循环
    _gen "$AG_RUN_HIDE/hrun.sh" "$_md" "clean.sh"  "ag_role=housekeeping_loop; ag_housekeeping_loop"
    # 反制守护
    _gen "$AG_RUN_HIDE/grun.sh" "$_md" "stealth.sh" "ag_role=guard_inside; ag_guard_inside"

    return 0
}

# 生成单个入口脚本
# $1=输出路径  $2=模块目录  $3=额外加载的脚本(可空)  $4=启动代码
_gen() {
    {
        echo '#!/system/bin/sh'
        echo "MODDIR='$2'"
        echo 'export MODDIR'
        echo '. "$MODDIR/script/common.sh" 2>/dev/null'
        echo '. "$MODDIR/script/config.sh" 2>/dev/null'
        if [ -n "$3" ]; then
            echo ". \"\$MODDIR/script/$3\" 2>/dev/null"
        fi
        echo 'ag_load_conf >/dev/null 2>&1'
        echo "$4"
    } > "$1" 2>/dev/null
    chmod 700 "$1" 2>/dev/null
}

# 清理隐藏目录（卸载/关闭时调用）
ag_hide_cleanup() {
    rm -rf "$AG_RUN_HIDE" 2>/dev/null
    return 0
}
