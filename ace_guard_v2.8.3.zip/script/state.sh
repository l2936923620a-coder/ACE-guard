#!/system/bin/sh
# ============================================================
#  ACE Guard 游戏状态中心 (v2.7.0 多游戏版)
#
#  全模块唯一的游戏进程检测点。
#  所有循环不再各自调 ag_find_game_pid，统一读这里的缓存。
#
#  v2.7.0 变更：
#    检测从「单包名 $PKG」改为「四款游戏全部包名」，
#    任意一款在运行都算游戏运行，功能照常触发。
#    同时记录当前是哪个包名在跑，界面右上角据此显示图标。
#
#  检测手段：/system/bin/pidof -s
#    内核级查找，实测 21~30ms（1000+ 进程时）
#
#  缓存有效期：AG_STATE_TTL 秒（默认等于 LIFECYCLE_INTERVAL）
#    生命周期循环是唯一刷新者，其余循环只读
# ============================================================

AG_STATE_PID=""        # 缓存的游戏 PID（空=未运行）
AG_STATE_PKG=""        # 缓存中命中的包名
AG_STATE_TS=0          # 上次刷新时间戳（秒）
AG_STATE_TTL=5         # 缓存有效期

# ---------- 原始检测（不做缓存）----------
#  v2.7.0：遍历四款游戏的全部包名，命中即返回 "包名 PID"
ag_probe_game_pid() {
    for _gp in $(ag_game_all_pkgs); do
        _gpid=$(/system/bin/pidof -s "$_gp" 2>/dev/null)
        if [ -n "$_gpid" ]; then
            printf '%s %s' "$_gp" "$_gpid"
            return 0
        fi
    done
    return 1
}

# ---------- 刷新缓存（仅生命周期循环调用）----------
ag_state_refresh() {
    _hit=$(ag_probe_game_pid 2>/dev/null)
    AG_STATE_TS=$(/system/bin/date +%s 2>/dev/null)
    [ -z "$AG_STATE_TS" ] && AG_STATE_TS=0
    if [ -n "$_hit" ]; then
        AG_STATE_PKG="${_hit%% *}"
        AG_STATE_PID="${_hit##* }"
    else
        AG_STATE_PKG=""
        AG_STATE_PID=""
    fi
}

# ---------- 读缓存（其余循环调用，过期不主动刷新）----------
# 返回 0=游戏运行中(输出PID)  1=未运行
ag_game_running() {
    if [ -n "$AG_STATE_TS" ] && [ "$AG_STATE_TS" != "0" ]; then
        local now age
        now=$(/system/bin/date +%s 2>/dev/null)
        [ -n "$now" ] || now=0
        age=$((now - AG_STATE_TS))
        if [ "$age" -gt "$((AG_STATE_TTL * 3))" ]; then
            ag_state_refresh
        fi
    else
        ag_state_refresh
    fi

    [ -n "$AG_STATE_PID" ] || return 1
    [ -d "/proc/$AG_STATE_PID" ] || return 1
    echo "$AG_STATE_PID"
    return 0
}

# ---------- 兼容旧接口 ----------
ag_find_game_pid() {
    ag_game_running
}

# ---------- 当前命中的包名 ----------
#  给界面显示用：返回正在跑的那款游戏的包名
ag_game_running_pkg() {
    ag_game_running >/dev/null 2>&1 || return 1
    printf '%s' "$AG_STATE_PKG"
}

# ---------- 四款游戏运行状态一览 ----------
#  输出每行：序号|包名|PID(空=未运行)，界面据此点亮图标
ag_game_status_lines() {
    _ifs="$IFS"
    IFS='
'
    for _line in $AG_GAME_DEFS; do
        IFS="$_ifs"
        case "$_line" in ''|'#'*) continue ;; esac
        _no="${_line%%|*}"
        _rest="${_line#*|}"
        _nm="${_rest%%|*}"
        _pkgs="${_line#*|*|}"
        _run=""
        _rpid=""
        for _p in $_pkgs; do
            _gpid=$(/system/bin/pidof -s "$_p" 2>/dev/null)
            if [ -n "$_gpid" ]; then
                _run="$_p"
                _rpid="$_gpid"
                break
            fi
        done
        printf '%s|%s|%s|%s\n' "$_no" "$_nm" "$_run" "$_rpid"
    done
    IFS="$_ifs"
}
