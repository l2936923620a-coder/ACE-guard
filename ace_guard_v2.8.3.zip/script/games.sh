# ============================================================
#  ACE Guard 多游戏支持（四款）
#
#  背景：
#    原先全模块只认一个包名 $PKG，换成别的游戏就不触发。
#    这里引入 AG_GAME_PKGS，四款游戏分别列出全部包名变体，
#    核心检测统一走多包名匹配，任意一款在运行都算「游戏运行」。
#
#  四款游戏与包名对应：
#    1 和平精英 / 无畏契约(国服)  com.tencent.tmgp.codev
#                                 com.tencent.tmgp.pubgmhd
#    2 三角洲行动                 com.tencent.tmgp.dfm
#                                 com.delta.dfm
#                                 com.proxima.dfm
#    3 使命召唤手游               com.tencent.tmgp.cod
#                                 com.activision.callofduty.shooter
#    4 王者荣耀                   com.tencent.tmgp.sgame
#                                 com.tencent.tmgp.sgamece
# ============================================================

# 每行：游戏序号|显示名|包名（空格分隔）
AG_GAME_DEFS="
1|和平精英|com.tencent.tmgp.pubgmhd
2|三角洲行动|com.tencent.tmgp.dfm com.delta.dfm com.proxima.dfm
3|无畏契约|com.tencent.tmgp.codev
4|王者荣耀|com.tencent.tmgp.sgame com.tencent.tmgp.sgamece
5|使命召唤手游|com.tencent.tmgp.cod com.activision.callofduty.shooter
"

# 展开成全部包名的扁平列表
ag_game_all_pkgs() {
    _all=""
    _ifs="$IFS"
    IFS='
'
    for _line in $AG_GAME_DEFS; do
        IFS="$_ifs"
        case "$_line" in ''|'#'*) continue ;; esac
        _pkgs=$(ag_gd_field "$_line" 3)
        _all="$_all $_pkgs"
    done
    IFS="$_ifs"
    printf '%s' "$_all"
}

# 找正在运行的游戏：输出 "包名 PID"，未运行输出空
#   逐个包名走 pidof，命中即返回，四款游戏一视同仁
ag_game_probe_any() {
    for _p in $(ag_game_all_pkgs); do
        _gpid=$(/system/bin/pidof -s "$_p" 2>/dev/null)
        if [ -n "$_gpid" ]; then
            printf '%s %s' "$_p" "$_gpid"
            return 0
        fi
    done
    return 1
}

# 列出当前正在运行的游戏（可能多个）
#   输出形如：com.tencent.tmgp.sgame:12345 com.tencent.tmgp.pubgmhd:6789
ag_game_running_list() {
    _out=""
    for _p in $(ag_game_all_pkgs); do
        _gpid=$(/system/bin/pidof "$_p" 2>/dev/null)
        [ -n "$_gpid" ] || continue
        for _one in $_gpid; do
            _out="$_out $_p:$_one"
        done
    done
    printf '%s' "${_out# }"
}

# 给某个包名找它属于第几款游戏（1-4），找不到输出 0
ag_game_index_of() {
    _want="$1"
    _idx=0
    _ifs="$IFS"
    IFS='
'
    for _line in $AG_GAME_DEFS; do
        IFS="$_ifs"
        case "$_line" in ''|'#'*) continue ;; esac
        _no=$(ag_gd_field "$_line" 1)
        _pkgs=$(ag_gd_field "$_line" 3)
        for _p in $_pkgs; do
            [ "$_p" = "$_want" ] && { IFS="$_ifs"; printf '%s' "$_no"; return 0; }
        done
    done
    IFS="$_ifs"
    printf '0'
}

# 给某个包名找它的显示名
ag_game_name_of() {
    _want="$1"
    _ifs="$IFS"
    IFS='
'
    for _line in $AG_GAME_DEFS; do
        IFS="$_ifs"
        case "$_line" in ''|'#'*) continue ;; esac
        _rest=$(ag_gd_field "$_line" 2)
        _nm=$(ag_gd_field "$_line" 2)
        _pkgs=$(ag_gd_field "$_line" 3)
        for _p in $_pkgs; do
            [ "$_p" = "$_want" ] && { IFS="$_ifs"; printf '%s' "$_nm"; return 0; }
        done
    done
    IFS="$_ifs"
    printf '%s' "$_want"
}

# 列举四款游戏在各用户下的数据目录（只输出真实存在的）
#   供 monitor.sh / stealth.sh 等需要「游戏数据根」的地方复用
ag_game_data_dirs() {
    local gp d
    for gp in $(ag_game_all_pkgs); do
        for d in /data_mirror/data_ce/null/*/"$gp" \
                 /data/user/*/"$gp" \
                 /data/data/"$gp"; do
            [ -d "$d" ] && echo "$d"
        done
    done
}

# 取「当前要用于展示/诊断的包名」
#   有游戏在跑 → 返回正在跑的那个包名
#   没游戏在跑 → 返回四款的包名列表（用于诊断时全量检查）
ag_game_active_pkg() {
    _ap=$(ag_game_running_pkg 2>/dev/null)
    [ -n "$_ap" ] && { printf '%s' "$_ap"; return 0; }
    printf '%s' "$PKG"
}

# 生成用于 grep 的包名模式（四款游戏全覆盖）
#   输出形如：com.tencent.tmgp.codev|com.tencent.tmgp.pubgmhd|...
ag_game_grep_pattern() {
    _pat=""
    for _p in $(ag_game_all_pkgs); do
        [ -n "$_pat" ] && _pat="$_pat|"
        _pat="$_pat$_p"
    done
    printf '%s' "$_pat"
}
# 从配置行里取字段
#   每行格式：序号|显示名|包名列表（空格分隔）
#   注意：不用 ${line#*|*} 这种写法，当前 ash 对含 | 的模式剥离不可靠，
#   统一改用 cut 取字段。
ag_gd_field() {
    # $1=配置行 $2=字段号（1/2/3）
    printf '%s' "$1" | /system/bin/cut -d'|' -f"$2" 2>/dev/null
}
