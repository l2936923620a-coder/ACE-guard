#!/system/bin/sh

# 独立运行时自动载入所需依赖
if ! command -v ag_hmac_hex >/dev/null 2>&1; then
    [ -f "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh" ] && \
        . "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh" 2>/dev/null
fi
# ============================================================
#  ACE Guard 文件完整性检查
#
#  作用：
#    确认模块的核心文件是否完整、是否被意外改动。
#    如果文件在传输或安装过程中损坏，模块能及时发现，
#    避免带着异常的模块继续运行。
#
#  对用户的影响：
#    · 正常安装、正常升级都不会触发提示
#    · 只有文件内容异常时才会记录，不影响你正常使用
#    · 升级完成后会自动更新校验基准，无需你手动处理
# ============================================================

# 参与指纹的核心文件（不含 module.prop，避免把自己算进去）
# 参与指纹的核心文件：覆盖全部可执行脚本与界面资源
# 动态枚举，避免新增脚本时漏掉
ag_integrity_list_files() {
    _md="${MODDIR:-/data/adb/modules/ace_guard}"
    {
        # 全部脚本
        ls "$_md"/script/*.sh 2>/dev/null   | /system/bin/sed "s|^$_md/||"
        ls "$_md"/bin/*.sh 2>/dev/null      | /system/bin/sed "s|^$_md/||"
        ls "$_md"/*.sh 2>/dev/null          | /system/bin/sed "s|^$_md/||"
        # 界面
        [ -f "$_md/webroot/index.html" ] && echo "webroot/index.html"
        # 界面图标（四款游戏，真实图标）
        for _ic in "$_md"/webroot/gameicon/*.png; do
            [ -f "$_ic" ] && echo "webroot/gameicon/${_ic##*/}"
        done
        # 本地程序
        [ -x "$_md/lib/agcore" ] && echo "lib/agcore"
        [ -x "$_md/lib/agcfg" ]  && echo "lib/agcfg"
    } | /system/bin/grep -vE "^build_zip\.sh$" | /system/bin/toybox sort -u
}

# 兼容旧引用：保留变量形式，内容为动态枚举结果
AG_INTEGRITY_FILES=""
ag_integrity_refresh_list() {
    AG_INTEGRITY_FILES=$(ag_integrity_list_files)
}

# 计算单个文件的规范化哈希（16 位）
ag_integrity_file_hash() {
    _f="$1"
    [ -f "$_f" ] || { printf 'MISSING'; return 1; }
    _h=$(/system/bin/toybox sha256sum "$_f" 2>/dev/null | /system/bin/toybox cut -c1-32)
    [ -n "$_h" ] || { printf 'ERR'; return 1; }
    # 再用密钥包一层，避免直接暴露明文哈希
    ag_hmac_hex "$_h" 2>/dev/null | /system/bin/toybox cut -c1-16
}

# 计算模块整体指纹
#   返回形如 "a1b2c3d4e5f60718" 的 16 位串
ag_integrity_fingerprint() {
    _md="${MODDIR:-/data/adb/modules/ace_guard}"
    _acc=""
    ag_integrity_refresh_list
    for _rel in $AG_INTEGRITY_FILES; do
        _h=$(ag_integrity_file_hash "$_md/$_rel")
        _acc="${_acc}${_rel}:${_h};"
    done
    # 最终再做一次带密钥汇总
    ag_hmac_hex "$_acc" 2>/dev/null | /system/bin/toybox cut -c1-16
}

# 校验指纹是否与已登记的一致
#   返回 0=一致  1=不一致（被改过）  2=没有基线
ag_integrity_verify() {
    _base=$(ag_cfg_get "installed.fingerprint" 2>/dev/null)
    [ -n "$_base" ] || return 2
    _now=$(ag_integrity_fingerprint)
    [ "$_base" = "$_now" ] && return 0
    AG_INTEGRITY_EXPECT="$_base"
    AG_INTEGRITY_ACTUAL="$_now"
    return 1
}

# 登记当前指纹（首次运行或正常升级后调用）
# 逐文件哈希快照路径
AG_INTEGRITY_SNAP="/data/adb/ace_guard/notice/.integrity_base"

# 写入当前逐文件哈希快照
ag_integrity_snapshot_save() {
    _md="${MODDIR:-/data/adb/modules/ace_guard}"
    ag_integrity_refresh_list
    {
        for _rf in $AG_INTEGRITY_FILES; do
            printf '%s  %s\n' "$(ag_integrity_file_hash "$_md/$_rf")" "$_rf"
        done
    } > "$AG_INTEGRITY_SNAP" 2>/dev/null
    chmod 600 "$AG_INTEGRITY_SNAP" 2>/dev/null
    return 0
}

# 对比快照，输出发生变化的文件列表
ag_integrity_diff_files() {
    _md="${MODDIR:-/data/adb/modules/ace_guard}"
    [ -f "$AG_INTEGRITY_SNAP" ] || return 0
    ag_integrity_refresh_list
    for _rf in $AG_INTEGRITY_FILES; do
        _old=$(/system/bin/grep -F " $_rf" "$AG_INTEGRITY_SNAP" 2>/dev/null | head -n1 | /system/bin/toybox cut -d' ' -f1)
        _new=$(ag_integrity_file_hash "$_md/$_rf")
        if [ -z "$_old" ]; then
            echo "新增 $_rf"
        elif [ "$_old" != "$_new" ]; then
            echo "变更 $_rf"
        fi
    done
    # 已删除的文件
    while IFS= read -r _line; do
        case "$_line" in ''|\#*) continue ;; esac
        _p=$(printf '%s' "$_line" | /system/bin/toybox cut -d' ' -f3-)
        [ -n "$_p" ] && [ ! -f "$_md/$_p" ] && echo "缺失 $_p"
    done < "$AG_INTEGRITY_SNAP"
    return 0
}

ag_integrity_register() {
    _fp=$(ag_integrity_fingerprint)
    [ -n "$_fp" ] || return 1
    ag_cfg_set "installed.fingerprint" "$_fp"
    ag_integrity_snapshot_save
    printf '%s' "$_fp"
}

# 指纹被判定不一致时的处理：记录告警，不阻断（避免误伤正常升级）
ag_integrity_report() {
    _log="${AG_NOTICE_DIR:-/data/adb/ace_guard/notice}/integrity.log"
    mkdir -p /data/adb/ace_guard/notice 2>/dev/null
    echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') MISMATCH expect=${AG_INTEGRITY_EXPECT:-?} actual=${AG_INTEGRITY_ACTUAL:-?}" \
        >> "$_log" 2>/dev/null
    command -v ag_log >/dev/null 2>&1 && \
        ag_log WARN "模块文件完整性校验失败：核心文件被修改"
}
# ============================================================
#  指纹自动重登记（识别正常升级）
#
#  问题：模块升级后所有核心文件都变了，指纹必然失配，
#        如果不重登记，会一直报 MISMATCH，日志被刷满。
#
#  但也不能「失配就自动重登记」，否则篡改核心文件后
#  守护自己就把篡改洗白了。
#
#  所以复用 ag_cfg_is_real_upgrade 的判据：
#    核心文件与 module.prop 的 mtime 相近（安装时一起写入）→ 正常升级
#    只有个别文件被单独改动 → 篡改
# ============================================================

AG_INTEGRITY_LOG="${AG_NOTICE_DIR:-/data/adb/ace_guard/notice}/integrity.log"

# 统一入口：校验指纹并按情况处理
#   返回 0=一致或已重登记   1=发现篡改   2=首次登记
ag_integrity_check_and_heal() {
    _fp_now=$(ag_integrity_fingerprint)
    _fp_base=$(ag_cfg_get "installed.fingerprint" 2>/dev/null)

    # 1) 没有基线：首次运行，直接登记
    if [ -z "$_fp_base" ]; then
        ag_cfg_set "installed.fingerprint" "$_fp_now"
        ag_cfg_set "installed.fingerprint_mtime" "$(ag_integrity_newest_mtime)"
        ag_integrity_snapshot_save 2>/dev/null
        _log_int "INIT fingerprint=$_fp_now"
        return 2
    fi

    # 2) 一致：正常
    [ "$_fp_base" = "$_fp_now" ] && return 0

    # 3) 不一致：判断是升级还是篡改
    if ag_integrity_is_upgrade; then
        ag_cfg_set "installed.fingerprint" "$_fp_now"
        ag_cfg_set "installed.fingerprint_mtime" "$(ag_integrity_newest_mtime)"
        ag_integrity_snapshot_save 2>/dev/null
        _log_int "UPGRADE re-registered ${_fp_base} -> ${_fp_now}"
        command -v ag_log >/dev/null 2>&1 && ag_log INFO "检测到模块升级，完整性指纹已更新"
        return 0
    fi

    # 4) 篡改
    AG_INTEGRITY_EXPECT="$_fp_base"
    AG_INTEGRITY_ACTUAL="$_fp_now"

    # 去重：同一组结果短时间内只记录一次，避免日志被刷满
    _stamp="$AG_INTEGRITY_EXPECT:$_fp_now"
    _lastfile="/data/adb/ace_guard/notice/.last_mismatch"
    _now=$(/system/bin/date +%s)
    _skip=0
    if [ -f "$_lastfile" ]; then
        _prev=$(/system/bin/toybox cat "$_lastfile" 2>/dev/null)
        _prev_stamp="${_prev%|*}"
        _prev_time="${_prev##*|}"
        case "$_prev_time" in ''|*[!0-9]*) _prev_time=0 ;; esac
        if [ "$_prev_stamp" = "$_stamp" ] && [ $(( _now - _prev_time )) -lt 3600 ]; then
            _skip=1
        fi
    fi

    if [ "$_skip" = "0" ]; then
        echo "${_stamp}|${_now}" > "$_lastfile" 2>/dev/null
        chmod 600 "$_lastfile" 2>/dev/null
        _log_int "MISMATCH expect=${_fp_base} actual=${_fp_now}"
        # 定位具体变化的文件
        _changed=$(ag_integrity_diff_files 2>/dev/null)
        if [ -n "$_changed" ]; then
            _log_int "CHANGED: $(printf '%s' "$_changed" | /system/bin/toybox tr '\n' ' ')"
        fi
        command -v ag_log >/dev/null 2>&1 && \
            ag_log WARN "模块核心文件被修改：$(printf '%s' "$_changed" | /system/bin/toybox tr '\n' ' ')"
    fi
    return 1
}

# 核心文件里最新的 mtime（安装时会被统一写入）
ag_integrity_newest_mtime() {
    _md="${MODDIR:-/data/adb/modules/ace_guard}"
    ag_integrity_refresh_list
    _max=0
    for _rel in $AG_INTEGRITY_FILES; do
        _m=$(/system/bin/toybox stat -c %Y "$_md/$_rel" 2>/dev/null || echo 0)
        case "$_m" in ''|*[!0-9]*) continue ;; esac
        [ "$_m" -gt "$_max" ] && _max=$_m
    done
    printf '%s' "$_max"
}

# 判断这次指纹变化是不是「正常升级」
#   判据：核心文件的最新 mtime 与 module.prop 的 mtime 相差很小
#         （KSU 安装 zip 时这些文件是一起写入的）
#   并且：距离上次登记时的 mtime 有明显变化（排除了「只是重启」的情况）
# 判断这次指纹变化是不是「正常安装/升级」
#   判据：模块目录整体被替换过（KSU 安装会重建整个模块目录）
#   单纯编辑某个文件不会改变目录本身的 mtime 排序关系
# 判断这次变化是不是「正常安装/升级」
#   核心判据：安装会替换全部文件，篡改只动其中个别文件
#   所以必须「所有文件的 mtime 都明显晚于上次记录」才算升级
ag_integrity_is_upgrade() {
    _md="${MODDIR:-/data/adb/modules/ace_guard}"
    _last=$(ag_cfg_get "installed.fingerprint_mtime" 2>/dev/null)
    case "$_last" in ''|*[!0-9]*) _last=0 ;; esac
    [ "$_last" -gt 0 ] || return 1

    ag_integrity_refresh_list
    _total=0
    _newer=0
    for _rel in $AG_INTEGRITY_FILES; do
        _total=$(( _total + 1 ))
        _m=$(/system/bin/toybox stat -c %Y "$_md/$_rel" 2>/dev/null || echo 0)
        case "$_m" in ''|*[!0-9]*) continue ;; esac
        # 该文件比上次记录时间更新（至少 2 秒，避开同秒误差）
        [ $(( _m - _last )) -ge 2 ] && _newer=$(( _newer + 1 ))
    done

    [ "$_total" -gt 0 ] || return 1
    # 只有「全部文件」都被更新时，才认定是安装
    [ "$_newer" -eq "$_total" ] || return 1
    return 0
}

# 内部日志
_log_int() {
    mkdir -p /data/adb/ace_guard/notice 2>/dev/null
    echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') $1" >> "$AG_INTEGRITY_LOG" 2>/dev/null
    _sz=$(/system/bin/toybox stat -c %s "$AG_INTEGRITY_LOG" 2>/dev/null || echo 0)
    [ "$_sz" -gt 32768 ] && /system/bin/toybox tail -n 200 "$AG_INTEGRITY_LOG" > "$AG_INTEGRITY_LOG.t" 2>/dev/null && \
        mv -f "$AG_INTEGRITY_LOG.t" "$AG_INTEGRITY_LOG" 2>/dev/null
    return 0
}
