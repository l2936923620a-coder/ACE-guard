#!/system/bin/sh
# ============================================================
#  ACE Guard 常驻服务
#   未授权：立即退出，不启动任何守护线程、不挂载任何目录
#   已在运行：去重后由本实例接管，最终恰好一份（v1.9.4）
# ============================================================
MODDIR=$(/system/bin/toybox dirname "$(/system/bin/toybox readlink -f "$0")")

# 版本更新后自动补全执行权限与运行目录
if [ -d "$MODDIR/lib" ]; then
    [ -x "$MODDIR/lib/agcore" ] || chmod 755 "$MODDIR/lib/agcore" 2>/dev/null
    [ -x "$MODDIR/lib/agcfg" ] || chmod 755 "$MODDIR/lib/agcfg" 2>/dev/null
fi
mkdir -p "$MODDIR/log" "$MODDIR/data" "$MODDIR/data/run" 2>/dev/null

. "$MODDIR/script/common.sh"
# service.sh 自己控制闸门，source 阶段跳过各脚本入口自检
_AG_AUTH_GUARDED=1
. "$MODDIR/script/state.sh"
. "$MODDIR/script/hide.sh"
. "$MODDIR/script/clean.sh"
. "$MODDIR/script/shadow.sh"
. "$MODDIR/script/stealth.sh"
. "$MODDIR/script/ext.sh"
. "$MODDIR/script/network.sh"
. "$MODDIR/script/monitor.sh"
. "$MODDIR/script/selfcheck.sh"
. "$MODDIR/script/identity.sh"
. "$MODDIR/script/hide_run.sh" 2>/dev/null

ag_load_conf

# ============================================================
#  重复实例去重（v1.9.4）
#
#  原则：把「重复」收敛成「唯一实例」，而不是放弃启动。
#  扫描所有 service.sh 主进程 → 杀掉非自己的 → 本实例接管继续启动。
#  无论从 KSU / 手动 / WebUI 哪进，跑完总是恰好一份在运行。
#
#  自我识别用 $$（shell 主 PID，生命周期内稳定）。
#  注意：绝不能用 readlink /proc/self —— 它在 $() 命令替换里会 fork
#        子进程，读到的是子进程 PID，每次都变，会误判自己。
# ============================================================
AG_LOCK_DIR="$MODDIR/data"
AG_PIDFILE="$AG_LOCK_DIR/service.pid"
AG_RUNLOCK="$AG_LOCK_DIR/.service.lock"

# 判断某 PID 是否存活（非僵尸）
ag_pid_alive() {
    case "$1" in ''|*[!0-9]*) return 1 ;; esac
    [ -d "/proc/$1" ] || return 1
    case "$(/system/bin/toybox cat "/proc/$1/stat" 2>/dev/null)" in
        *") Z "*) return 1 ;;
    esac
    return 0
}

# 列出所有 service.sh 主进程 PID（不含自己）
ag_svc_find_other() {
    _self="$$"
    /system/bin/toybox ps -A -o PID,ARGS 2>/dev/null \
        | /system/bin/grep -F "ace_guard/service.sh" \
        | /system/bin/grep -vF "sh -c" \
        | while IFS= read -r _l; do
              _p=$(printf '%s' "$_l" | /system/bin/toybox tr -s ' ' | /system/bin/toybox cut -d' ' -f2)
              case "$_p" in ''|*[!0-9]*) continue ;; esac
              [ "$_p" = "$_self" ] && continue
              printf '%s\n' "$_p"
          done | /system/bin/toybox sort -u
}

# 杀掉某进程的全部子进程（守护子进程）
ag_svc_kill_children() {
    _pp="$1"
    case "$_pp" in ''|*[!0-9]*) return 0 ;; esac
    # 直接杀子进程（setsid 脱管的另由角色清理兜底）
    /system/bin/toybox ps -A -o PID,PPID 2>/dev/null \
        | /system/bin/grep -F " $_pp" \
        | while IFS= read -r _l; do
              _c=$(printf '%s' "$_l" | /system/bin/toybox tr -s ' ' | /system/bin/sed 's/^ *//' | /system/bin/toybox cut -d' ' -f1)
              case "$_c" in ''|*[!0-9]*) continue ;; esac
              _par=$(printf '%s' "$_l" | /system/bin/toybox tr -s ' ' | /system/bin/sed 's/^ *//' | /system/bin/toybox cut -d' ' -f2)
              [ "$_par" = "$_pp" ] && /system/bin/toybox kill -9 "$_c" 2>/dev/null
          done
}

ag_svc_singleton() {
    mkdir -p "$AG_LOCK_DIR" 2>/dev/null
    _me="$$"

    # ---- 原子锁：mkdir 成功者为唯一实例 ----
    # 并发启动时，只有第一个 mkdir 能成功，其余退出
    _lockdir="$AG_LOCK_DIR/.svc_lock"
    _lock_try=0
    while [ "$_lock_try" -lt 5 ]; do
        _lock_try=$(( _lock_try + 1 ))
        if mkdir "$_lockdir" 2>/dev/null; then
            # 拿到锁：写入自己的 PID
            echo "$_me" > "$_lockdir/pid" 2>/dev/null
            break
        fi
        # 锁已存在：检查持有者是否还活着
        _holder=$(/system/bin/toybox cat "$_lockdir/pid" 2>/dev/null | /system/bin/toybox tr -dc '0-9')
        if [ -n "$_holder" ] && [ -d "/proc/$_holder" ]; then
            # 持有者存活：本实例退出，避免叠加
            if [ "$_holder" != "$_me" ]; then
                echo "[$(/system/bin/date '+%H:%M:%S')] 已有实例 $_holder 运行，本实例退出" >>"$LOG_DIR/service.log"
                exit 0
            fi
        else
            # 持有者已死：清理僵尸锁后重试
            rm -rf "$_lockdir" 2>/dev/null
            /system/bin/sleep 1
        fi
    done

    # ---- 清扫所有旧实例（两轮，确保杀干净）----
    _killed=""
    _round=0
    while [ "$_round" -lt 2 ]; do
        _round=$(( _round + 1 ))
        for _p in $(ag_svc_find_other); do
            ag_pid_alive "$_p" || continue
            ag_svc_kill_children "$_p"
            /system/bin/toybox kill -9 "$_p" 2>/dev/null
            _killed="$_killed $_p"
        done
        /system/bin/sleep 1
    done

    _killed=$(printf '%s' "$_killed" | /system/bin/toybox tr ' ' '\n' | /system/bin/toybox sort -u | /system/bin/toybox tr '\n' ' ')
    _killed=$(printf '%s' "$_killed" | /system/bin/toybox sed 's/^ *//;s/ *$//')
    if [ -n "$_killed" ]; then
        ag_log WARN "已去重旧实例: $_killed （本实例 $_me 接管运行）"
    fi

    # 清理遗留角色进程（含 setsid 脱管的）
    if command -v ag_spawn_kill_all_roles >/dev/null 2>&1; then
        _zk=$(ag_spawn_kill_all_roles 2>/dev/null)
        [ "${_zk:-0}" -gt 0 ] 2>/dev/null && ag_log WARN "清理遗留守护进程 ${_zk} 个"
    fi

    # ---- 接管锁 ----
    rm -rf "$AG_RUNLOCK" 2>/dev/null
    mkdir -p "$AG_RUNLOCK" 2>/dev/null
    printf '%s\n' "$_me" > "$AG_RUNLOCK/pid" 2>/dev/null
    printf '%s\n' "$_me" > "$AG_PIDFILE" 2>/dev/null
    chmod 600 "$AG_PIDFILE" 2>/dev/null

    trap 'rm -rf "$AG_RUNLOCK" 2>/dev/null; rm -f "$AG_PIDFILE" 2>/dev/null; rm -rf "$_lockdir" 2>/dev/null' EXIT INT TERM
    return 0
}

# 去重并接管

ag_svc_singleton


# 运行环境自检（仅记录，不阻断）
if command -v ag_env_check >/dev/null 2>&1; then
    if ! ag_env_check; then
        ag_log WARN "运行环境自检未通过，已记录"
    fi
fi
# ---------- 后台子系统启动器 ----------
# 按角色标识彻底清理同名守护进程（不依赖父子关系）
ag_spawn_kill_role() {
    _role="$1"
    [ -n "$_role" ] || return 0
    _n=0
    for _p in $(/system/bin/toybox ps -A -o PID,ARGS 2>/dev/null \
                | /system/bin/grep -F "ag_role=$_role" \
                | /system/bin/grep -vF "grep" \
                | /system/bin/sed 's/^ *//' | /system/bin/toybox cut -d' ' -f1); do
        case "$_p" in ''|*[!0-9]*) continue ;; esac
        /system/bin/toybox kill -9 "$_p" 2>/dev/null
        _n=$(( _n + 1 ))
    done
    printf '%s' "$_n"
}

# 清理所有模块角色进程（本体除外）
ag_spawn_kill_all_roles() {
    _total=0
    for _r in ag_shadow_lifecycle ag_guard_inside ag_housekeeping_loop ag_mem_check_loop; do
        _c=$(ag_spawn_kill_role "$_r")
        _total=$(( _total + _c ))
    done
    # 预热脚本不带角色标识，单独按路径清理
    for _p in $(/system/bin/toybox ps -A -o PID,ARGS 2>/dev/null \
                | /system/bin/grep -F "ag_cache_warm.sh" | /system/bin/grep -vF "grep" \
                | /system/bin/sed 's/^ *//' | /system/bin/toybox cut -d' ' -f1); do
        case "$_p" in ''|*[!0-9]*) continue ;; esac
        /system/bin/toybox kill -9 "$_p" 2>/dev/null
        _total=$(( _total + 1 ))
    done
    printf '%s' "$_total"
}

ag_spawn() {
    _fn="$1"
    AG_SPAWN_PARENT="$$"
    export AG_SPAWN_PARENT
    AG_ROLE="$_fn"
    export AG_ROLE
    _run_dir="$DATA_DIR/run"
    mkdir -p "$_run_dir" 2>/dev/null

    # 先清理同名旧进程，避免叠加
    _pre_killed=$(ag_spawn_kill_role "$_fn")
    [ "$_pre_killed" -gt 0 ] 2>/dev/null && \
        echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') spawn: 清理旧 $_fn 进程 ${_pre_killed} 个" >>"$LOG_DIR/service.log"

    _script="mkdir -p '$_run_dir' 2>/dev/null; echo \$\$ > '$_run_dir/$_fn.pid' 2>/dev/null; "
    _script="${_script}. '$MODDIR/script/common.sh'; . '$MODDIR/script/state.sh'; "
    _script="${_script}. '$MODDIR/script/hide.sh'; . '$MODDIR/script/clean.sh'; "
    _script="${_script}. '$MODDIR/script/shadow.sh'; . '$MODDIR/script/stealth.sh'; "
    _script="${_script}. '$MODDIR/script/ext.sh'; "
    _script="${_script}. '$MODDIR/script/network.sh'; . '$MODDIR/script/monitor.sh'; "
    _script="${_script}. '$MODDIR/script/selfcheck.sh'; . '$MODDIR/script/identity.sh'; "
    _script="${_script}ag_load_conf; ag_role=$_fn; $_fn"

    if command -v setsid >/dev/null 2>&1; then
        AG_ROLE="$_fn" setsid /system/bin/sh -c "$_script" </dev/null >>"$LOG_DIR/service.log" 2>&1 &
    else
        AG_ROLE="$_fn" nohup /system/bin/sh -c "$_script" </dev/null >>"$LOG_DIR/service.log" 2>&1 &
    fi
    unset AG_ROLE

    # 启动后校验：确认真实只有一个实例
    /system/bin/sleep 1
    _cnt=$(/system/bin/toybox ps -A -o PID,ARGS 2>/dev/null \
           | /system/bin/grep -F "ag_role=$_fn" | /system/bin/grep -vF "grep" | wc -l)
    case "$_cnt" in ''|*[!0-9]*) _cnt=0 ;; esac
    if [ "$_cnt" -gt 1 ]; then
        # 多实例：保留最早的一个，其余清掉
        _first=1
        for _p in $(/system/bin/toybox ps -A -o PID,ARGS 2>/dev/null \
                    | /system/bin/grep -F "ag_role=$_fn" | /system/bin/grep -vF "grep" \
                    | /system/bin/sed 's/^ *//' | /system/bin/toybox cut -d' ' -f1); do
            if [ "$_first" = "1" ]; then _first=0; continue; fi
            /system/bin/toybox kill -9 "$_p" 2>/dev/null
        done
        echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') spawn: $_fn 出现 $_cnt 个实例，已收敛为 1" >>"$LOG_DIR/service.log"
    fi
}

# ---------- 授权闸门 ----------
. "$MODDIR/script/auth.sh"
. "$MODDIR/script/notice.sh"
ag_auth_snapshot_init
ag_auth_validate_silent

# 启动时检测 module.prop 是否被篡改（发现即回退）
command -v ag_cfg_guard_prop >/dev/null 2>&1 && {
    ag_cfg_guard_prop >/dev/null 2>&1
    [ $? = 1 ] && ag_log WARN "启动检测：module.prop 版本号被篡改，已自动回退"
}
ag_auth_update_prop 2>/dev/null

# ---------- 远程版本监控（必须在闸门之前拉起）----------
# 冻结时业务进程全被杀，只有这条外部循环能发现「本地版本已追平」并自动解冻。
# 启动时先按当前本地版本复核一次，清掉可能残留的过期标记。
ag_start_notice_monitor() {
    [ -n "${NOTICE_URL:-}" ] || return 0
    _md="$MODDIR"
    _lock="$MODDIR/data/.lock_notice"
    _np="$MODDIR/data/run/notice.pid"

    # 原子占位：mkdir 是原子操作，多个启动源同时执行只会有一个成功
    if ! mkdir "$_lock" 2>/dev/null; then
        _holder=$(/system/bin/toybox cat "$_lock/pid" 2>/dev/null | /system/bin/toybox tr -dc '0-9')
        if [ -n "$_holder" ] && [ -d "/proc/$_holder" ]; then
            return 0
        fi
        rm -rf "$_lock" 2>/dev/null
        mkdir "$_lock" 2>/dev/null || return 0
    fi

    mkdir -p "$MODDIR/data/run" "$LOG_DIR" 2>/dev/null
    echo "$$" > "$_lock/pid" 2>/dev/null

    # 从隐藏目录运行：命令行里不出现模块路径
    command -v ag_hide_prepare >/dev/null 2>&1 && ag_hide_prepare >/dev/null 2>&1
    _run="/dev/.agr/nrun.sh"
    if [ -x "$_run" ]; then
        /system/bin/setsid "$_run" </dev/null >>"$LOG_DIR/service.log" 2>&1 &
    else
        _script="MODDIR='$_md'; export MODDIR; . '$_md/script/common.sh' 2>/dev/null; . '$_md/script/notice.sh' 2>/dev/null; ag_load_conf; ag_role=notice_monitor; ag_notice_daemon"
        /system/bin/setsid /system/bin/sh -c "$_script" </dev/null >>"$LOG_DIR/service.log" 2>&1 &
    fi

    _i=0
    while [ "$_i" -lt 10 ]; do
        _i=$(( _i + 1 ))
        /system/bin/sleep 1
        if [ -f "$_np" ]; then
            _newp=$(/system/bin/toybox cat "$_np" 2>/dev/null | /system/bin/toybox tr -dc '0-9')
            if [ -n "$_newp" ] && [ -d "/proc/$_newp" ]; then
                echo "$_newp" > "$_lock/pid" 2>/dev/null
                return 0
            fi
        fi
    done
    rm -rf "$_lock" 2>/dev/null
    echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') notice_monitor 启动失败（超时未见 pid）" >>"$LOG_DIR/service.log" 2>/dev/null
    return 1
}
# 启动即复核一次本地版本（手动改 prop 后重启服务也能立刻解冻）
_sig_now=$(ag_notice_local_sig)
_sig_old=$(cat "$AG_NOTICE_DIR/.local_sig" 2>/dev/null)
if [ "$_sig_now" != "$_sig_old" ] && ag_notice_state_load 2>/dev/null; then
    ag_notice_evaluate >/dev/null 2>&1
fi

ag_start_notice_monitor
/system/bin/sh "$MODDIR/bin/ag_prop_daemon.sh" start >/dev/null 2>&1

# ---------- 远程版本闸门 ----------
# 有新版本时：终止全部模块进程 + 还原挂载，只留卡片提示与监控进程
if ag_notice_need_update; then
    # 已冻结且远程版本未变则不重复杀进程，避免「刚拉起就被杀」的死循环
    _need_freeze=1
    if [ -f "$AG_FREEZE_MARK" ]; then
        _prevvc=$(/system/bin/sed -n 's/^REMOTE_VC=//p' "$AG_FREEZE_FLAG" 2>/dev/null | head -n1)
        case "$_prevvc" in ''|*[!0-9]*) _prevvc=0 ;; esac
        _curvc=$(ag_notice_json_get "$AG_NOTICE_JSON" versionCode num 2>/dev/null)
        case "$_curvc" in ''|*[!0-9]*) _curvc=0 ;; esac
        [ -n "$_prevvc" ] && [ "$_prevvc" = "$_curvc" ] && _need_freeze=0
    fi
    if [ "$_need_freeze" = "1" ]; then
        ag_log WARN "检测到新版本 $AG_N_REMOTE_VER（远程 $AG_N_REMOTE_VC > 本地 $(ag_notice_local_vc)），执行冻结"
        ag_freeze_all "service_gate" 2>/dev/null
    fi
    ag_auth_update_prop 2>/dev/null
    # 冻结会连带杀掉监控进程，这里重新拉起，否则永远无法自动解冻
    ag_start_notice_monitor
    /system/bin/sh "$MODDIR/bin/ag_prop_daemon.sh" start >/dev/null 2>&1
    exit 0
fi

/system/bin/sh "$MODDIR/bin/ag_prop_daemon.sh" start >/dev/null 2>&1

if [ "$AG_AUTH_OK" != "1" ]; then
    ag_log WARN "未授权：service.sh 拒绝启动（设备码 $(ag_auth_device_id) / $AG_AUTH_REASON）"
    exit 0
fi

until [ "$(/system/bin/getprop sys.boot_completed 2>/dev/null)" = "1" ]; do
    /system/bin/sleep 2
done
/system/bin/sleep 25

# 0. 授权复查
if ! ag_auth_valid; then
    ag_log WARN "服务启动时授权复查失败：$AG_AUTH_REASON"
    ag_auth_update_prop 2>/dev/null
    exit 0
fi

# 1. 设备身份（SERIAL/IMEI/CHIPECID/ADID 一体）
ag_identity_load >/dev/null 2>&1
ag_identity_ensure
ag_identity_apply_all keep

# 2. 空源目录
ag_hide_empty

# 3. 目录遮蔽 / 配置伪装 / 守护反制 / 扩展隐藏 / 后台维护
#    全部合并到同一个调度器进程，游戏运行时才执行，不再一个功能一个进程。
ag_gen_green 2>/dev/null
ag_ext_load_state

# 先杀掉可能残留的旧角色进程，避免叠加
for _old in ag_shadow_lifecycle ag_mem_check_loop ag_guard_inside ag_ext_lifecycle ag_housekeeping_loop; do
    for _op in $(/system/bin/toybox ps -A -o PID,ARGS 2>/dev/null \
                 | /system/bin/grep -F "ag_role=$_old" | /system/bin/grep -vF grep \
                 | /system/bin/sed 's/^ *//' | /system/bin/toybox cut -d' ' -f1); do
        case "$_op" in ''|*[!0-9]*) continue ;; esac
        /system/bin/toybox kill -9 "$_op" 2>/dev/null
    done
done

if command -v setsid >/dev/null 2>&1; then
    setsid /system/bin/sh "$MODDIR/bin/ag_unified.sh" </dev/null >>"$LOG_DIR/service.log" 2>&1 &
else
    nohup /system/bin/sh "$MODDIR/bin/ag_unified.sh" </dev/null >>"$LOG_DIR/service.log" 2>&1 &
fi
ag_log INFO "统一调度器已启动（单进程模式）：shadow=$ENABLE_SHADOW green=$ENABLE_GREEN_LOCK guard=$ENABLE_GUARD ext=$ENABLE_EXT_BINDMOUNT/$ENABLE_EXT_OVERLAY/$ENABLE_EXT_SECCOMP/$ENABLE_EXT_PROCFAKE"
# 先清理残留的预热进程，避免重复
for _cp in $(/system/bin/toybox ps -A -o PID,ARGS 2>/dev/null | /system/bin/grep -F "ag_cache_warm.sh" | /system/bin/grep -vF "grep" | /system/bin/sed 's/^ *//' | /system/bin/toybox cut -d' ' -f1); do
    case "$_cp" in ''|*[!0-9]*) continue ;; esac
    /system/bin/toybox kill -9 "$_cp" 2>/dev/null
done
setsid /system/bin/sh "$MODDIR/bin/ag_cache_warm.sh" </dev/null >/dev/null 2>&1 &

# 8.5 远程版本监控已在闸门之前拉起（见 ag_start_notice_monitor），此处不再重复
ag_log INFO "远程版本检查：$([ -n "${NOTICE_URL:-}" ] && echo "已启用，间隔 ${NOTICE_INTERVAL}s" || echo 未启用)"

# 9. 开机自检
if [ "$ENABLE_SELFCHECK_BOOT" = "1" ]; then
    ( sleep 12; ag_selfcheck_boot ) &
fi

# 10. 监控主循环
if [ "$ENABLE_MONITOR" = "1" ]; then
    ag_monitor_loop
else
    ag_log INFO "监控已关闭"
    while true; do
        /system/bin/sleep 120
    done
fi
