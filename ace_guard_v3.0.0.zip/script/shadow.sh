#!/system/bin/sh

# >>> AG-AUTH-GUARD >>>
# 授权闸门（性能优化版）
#   1) 同进程内复用：_AG_AUTH_GUARDED=1 直接跳过
#   2) 跨进程复用：60 秒内通过的标记文件，避免每次 source 都跑 sha256
#   3) 缓存失效才真正校验
if [ "${_AG_AUTH_GUARDED:-0}" != "1" ]; then
    _ag_gcache="/data/adb/ace_guard/auth/.guardok"
    _ag_gok=0
    if [ -f "$_ag_gcache" ]; then
        _ag_gt=$(cat "$_ag_gcache" 2>/dev/null)
        _ag_now=$(/system/bin/date +%s)
        # 60 秒内的标记视为有效
        case "$_ag_gt" in
            ''|*[!0-9]*) : ;;
            *) [ $(( _ag_now - _ag_gt )) -lt 60 ] && _ag_gok=1 ;;
        esac
    fi
    if [ "$_ag_gok" != "1" ]; then
        if [ -f "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh" ]; then
            . "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh"
            if ! ag_auth_guard "${0##*/}" 2>/dev/null; then
                echo "此设备未授权，功能已冻结" >&2
                exit 1
            fi
            /system/bin/date +%s > "$_ag_gcache" 2>/dev/null
        fi
    fi
fi
_AG_AUTH_GUARDED=1
# <<< AG-AUTH-GUARD <<<

# ============================================================
#  ACE Guard 目录遮蔽层 — 事件驱动版
#
#  藏匿设计：
#    1. inotifyd 监听父目录，子目录一出现立即遮蔽（零轮询）
#    2. 监听游戏进程生命周期，退出即全量还原
#    3. 源目录随机命名，不放在模块目录下
#    4. 只 bind 已存在目录，绝不创建
#    5. 游戏未运行时不保留任何挂载
# ============================================================

AG_SHADOW_ROOT=""
AG_SHADOW_STATE="$DATA_DIR/.shadow_root"
AG_SHADOW_DIRS="$DATA_DIR/.shadow_dirs"
AG_SHADOW_WD="$DATA_DIR/.shadow_wd"
AG_SHADOW_GAME="$DATA_DIR/.shadow_game"


# ---------- 随机 token ----------
ag_rand_token() {
    local n="${1:-8}" v
    v=$(/system/bin/toybox od -An -N$((n / 2)) -tx1 /dev/urandom 2>/dev/null \
        | /system/bin/toybox tr -d ' \r\n')
    printf '%s' "$v"
}

# ---------- 遮蔽根 ----------
ag_shadow_init() {
    [ -n "$AG_SHADOW_ROOT" ] && [ -d "$AG_SHADOW_ROOT" ] && return 0
    if [ -r "$AG_SHADOW_STATE" ]; then
        AG_SHADOW_ROOT=$(/system/bin/toybox cat "$AG_SHADOW_STATE" 2>/dev/null | /system/bin/toybox tr -d '\r\n')
    fi
    if [ -z "$AG_SHADOW_ROOT" ] || [ ! -d "$AG_SHADOW_ROOT" ]; then
        AG_SHADOW_ROOT="/data/local/tmp/.$(ag_rand_token 10)"
        /system/bin/mkdir -p "$AG_SHADOW_ROOT" 2>/dev/null
        /system/bin/chmod 700 "$AG_SHADOW_ROOT" 2>/dev/null
        ( umask 077; printf '%s' "$AG_SHADOW_ROOT" > "$AG_SHADOW_STATE" ) 2>/dev/null
    fi
    [ -d "$AG_SHADOW_ROOT" ]
}

# ---------- 源目录（随机名）----------
ag_shadow_src_for() {
    local target="$1" hash src
    ag_shadow_init || return 1
    hash=$(printf '%s' "$target" | /system/bin/toybox cksum 2>/dev/null | /system/bin/awk '{print $1}')
    [ -z "$hash" ] && hash=$(ag_rand_token 8)
    src="$AG_SHADOW_ROOT/$hash"
    [ -d "$src" ] || /system/bin/mkdir -p "$src" 2>/dev/null
    [ -d "$src" ] || return 1
    printf '%s' "$src"
}


# 解挂一个路径
#   先普通卸载，失败再用惰性卸载。
#   实测部分内核上 -l 对本场景无效，普通 umount 反而一次成功。
ag_shadow_umount() {
    [ -n "$1" ] || return 1
    /system/bin/toybox umount "$1" 2>/dev/null && return 0
    /system/bin/toybox umount -l "$1" 2>/dev/null && return 0
    return 1
}
ag_shadow_bound() {
    /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $1 "
}

# ---------- 单目录遮蔽 ----------
ag_shadow_one() {
    local target="$1" uid src
    [ -d "$target" ] || return 1
    ag_shadow_bound "$target" && return 0
    src=$(ag_shadow_src_for "$target") || return 1
    [ -d "$src" ] || return 1
    uid=$(/system/bin/stat -c %u "$target" 2>/dev/null)
    [ -n "$uid" ] && /system/bin/chown "$uid:$uid" "$src" 2>/dev/null
    /system/bin/toybox mount --bind "$src" "$target" 2>/dev/null
    ag_shadow_bound "$target" || return 1
    # 记录已遮蔽目录
    echo "$target" >> "$AG_SHADOW_DIRS" 2>/dev/null
    return 0
}

# ---------- 全量扫描（仅在游戏启动时执行一次）----------
ag_shadow_sweep() {
    local base d sub n=0
    for base in $(ag_game_dirs); do
        [ -d "$base" ] || continue
        for d in $RISK_DIRS; do
            [ -z "$d" ] && continue
            [ -d "$base/files/$d" ] || continue
            ag_shadow_one "$base/files/$d" && n=$((n+1))
        done
        for sub in $CACHE_RISK_SUB; do
            [ -d "$base/cache/$sub" ] || continue
            ag_shadow_one "$base/cache/$sub" && n=$((n+1))
        done
    done
    [ "$n" -gt 0 ] && ag_log INFO "初始遮蔽 $n 个目录"
}

# ---------- 全量还原 ----------
ag_shadow_restore() {
    local t n=0
    if [ -r "$AG_SHADOW_DIRS" ]; then
        while read -r t; do
            [ -n "$t" ] || continue
            ag_shadow_bound "$t" && ag_shadow_umount "$t" && n=$((n+1))
        done < "$AG_SHADOW_DIRS"
    fi
    # 兜底一：按配置清单逐个解挂，覆盖所有游戏与所有用户目录
    local base d sub gp t
    for gp in $(ag_game_all_pkgs); do
        for base in /data_mirror/data_ce/null/*/"$gp" /data/user/*/"$gp" /data/data/"$gp"; do
            [ -d "$base" ] || continue
            for d in $RISK_DIRS; do
                [ -z "$d" ] && continue
                t="$base/files/$d"
                ag_shadow_bound "$t" && ag_shadow_umount "$t"
            done
            for sub in $CACHE_RISK_SUB; do
                [ -z "$sub" ] && continue
                t="$base/cache/$sub"
                ag_shadow_bound "$t" && ag_shadow_umount "$t"
            done
        done
    done

    # 兜底二：扫一遍挂载表，凡是挂在游戏数据目录下的 bind 全部解掉。
    #        配置改过之后旧挂载点会没人认领，这一步负责收尾。
    for t in $(/system/bin/toybox mount 2>/dev/null | /system/bin/sed 's/^.* on //;s/ type .*//' | /system/bin/grep -E '^/data[_a-z]*/.*/(com\.|me\.)'); do
        case "$t" in
            *"/shared_prefs/ace_config.xml") continue ;;
        esac
        ag_shadow_umount "$t"
    done

    # 从状态文件读遮蔽根（变量可能在其他子 shell 中丢失）
    local root="$AG_SHADOW_ROOT"
    if [ -z "$root" ] && [ -r "$AG_SHADOW_STATE" ]; then
        root=$(/system/bin/toybox cat "$AG_SHADOW_STATE" 2>/dev/null | /system/bin/toybox tr -d '\r\n')
    fi
    if [ -n "$root" ] && [ -d "$root" ]; then
        /system/bin/toybox rm -rf "$root" 2>/dev/null
    fi
    AG_SHADOW_ROOT=""
    /system/bin/toybox rm -f "$AG_SHADOW_STATE" 2>/dev/null
    /system/bin/toybox rm -f "$DATA_DIR/.shadow_ino.log" 2>/dev/null
    [ "$n" -gt 0 ] && ag_log INFO "还原 $n 个遮蔽目录"
    return 0
}

# ---------- inotifyd 回调：子目录出现即遮蔽 ----------
ag_shadow_callback() {
    local cb="$DATA_DIR/.shadow_cb.sh"
    cat > "$cb" <<'EOS'
#!/system/bin/sh
# $1=event $2=dir $3=name
[ -n "$3" ] && [ "$3" != "." ] || exit 0
case "$1" in
    n*|c*)
        MODDIR=$(/system/bin/toybox dirname "$(dirname "$0")")
        . "$MODDIR/script/common.sh"
        . "$MODDIR/script/clean.sh"
        . "$MODDIR/script/shadow.sh"
        ag_load_conf
        base=$(ag_game_dirs | /system/bin/head -1)
        [ -n "$base" ] || exit 0
        t="$2/$3"
        [ -d "$t" ] || exit 0
        # 只在风险目录名单内才遮蔽
        name="$3"
        for d in $RISK_DIRS $CACHE_RISK_SUB; do
            [ "$d" = "$name" ] || continue
            ag_shadow_one "$t" && ag_log INFO "动态遮蔽 $t"
            break
        done
        ;;
esac
exit 0
EOS
    /system/bin/chmod 755 "$cb"
    printf '%s' "$cb"
}

# ---------- 启动监听 ----------
ag_shadow_watch_start() {
    [ "$ENABLE_SHADOW" = "1" ] || return 0
    ag_shadow_init || { ag_log ERROR "遮蔽根初始化失败"; return 1; }

    ag_shadow_watch_stop
    : > "$AG_SHADOW_DIRS" 2>/dev/null

    local cb base
    cb=$(ag_shadow_callback)

    # 对每个游戏的 files/ 和 cache/ 父目录挂 inotifyd
    for base in $(ag_game_dirs); do
        [ -d "$base/files" ] && {
            /system/bin/toybox inotifyd "$cb" "$base/files" >> "$DATA_DIR/.shadow_ino.log" 2>&1 &
        }
        [ -d "$base/cache" ] && {
            /system/bin/toybox inotifyd "$cb" "$base/cache" >> "$DATA_DIR/.shadow_ino.log" 2>&1 &
        }
    done

    ag_shadow_sweep
    ag_log INFO "遮蔽监听启动"
}

ag_shadow_watch_stop() {
    local p
    for p in $(/system/bin/toybox ps -A -o PID,ARGS 2>/dev/null \
               | /system/bin/grep "shadow_cb.sh" | /system/bin/grep -v grep \
               | /system/bin/awk '{print $1}'); do
        /system/bin/kill -9 "$p" 2>/dev/null
    done
    return 0
}

# ---------- 游戏进程生命周期守护 ----------
# 只做低频检查（不是文件轮询）
# 游戏启动 → 建立全部挂载；游戏退出 → 全部解除
# 闲时（无游戏进程）不保留任何游戏相关挂载
ag_shadow_lifecycle() {
    [ "$ENABLE_SHADOW" = "1" ] || [ "$ENABLE_GUARD" = "1" ] || [ "$ENABLE_GREEN_LOCK" = "1" ] || return 0
    ag_log INFO "游戏生命周期守护启动（闲时不挂载，统一状态源）"

    local running=0 gpid interval="${LIFECYCLE_INTERVAL:-5}"

    # 启动自愈：
    #   上一次运行若异常退出，可能留下遮蔽挂载却没人清理；
    #   也可能反过来——状态文件还在，但挂载已经没了。
    #   这里两种情况都处理：有残留就还原，游戏在跑但没遮蔽就补建。
    if [ -f "$AG_SHADOW_GAME" ] || [ -s "$AG_SHADOW_DIRS" ]; then
        ag_state_refresh
        if [ -z "$AG_STATE_PID" ]; then
            ag_log WARN "发现上次遗留的遮蔽，先还原"
            [ "$ENABLE_SHADOW" = "1" ] && {
                ag_shadow_watch_stop
                ag_shadow_restore
            }
            [ "$ENABLE_GUARD" = "1" ] && ag_unlock_dirs
            [ "$ENABLE_GUARD" = "1" ] && ag_unlock_perms
            /system/bin/toybox rm -f "$AG_SHADOW_GAME" 2>/dev/null
        else
            # 游戏还在跑：看遮蔽是否真的在
            _have=0
            for _b in $(ag_game_dirs); do
                [ -d "$_b" ] || continue
                for _d in $RISK_DIRS; do
                    [ -n "$_d" ] || continue
                    ag_shadow_bound "$_b/files/$_d" && { _have=1; break 2; }
                done
                for _d in $CACHE_RISK_SUB; do
                    [ -n "$_d" ] || continue
                    ag_shadow_bound "$_b/cache/$_d" && { _have=1; break 2; }
                done
            done
            if [ "$_have" = "1" ]; then
                running=1
            else
                # 游戏在跑但遮蔽丢了，补建一次
                ag_log WARN "游戏运行中但遮蔽缺失，重新建立"
                [ "$ENABLE_SHADOW" = "1" ] && ag_shadow_watch_start
                [ "$ENABLE_GUARD" = "1" ] && ag_lock_dirs
                [ "$ENABLE_GREEN_LOCK" = "1" ] && ag_lock_green
                running=1
            fi
        fi
    fi

    while true; do
        ag_orphan_check
        # 唯一刷新点：更新状态中心缓存，供 monitor/guard/housekeeping/stealth 复用
        ag_state_refresh
        gpid="$AG_STATE_PID"

        if [ -n "$gpid" ] && [ "$running" = "0" ]; then
            # 游戏启动
            running=1
            echo "$gpid" > "$AG_SHADOW_GAME" 2>/dev/null
            ag_log INFO "游戏启动 PID=$gpid，建立遮蔽"
            # 1. 风险目录遮蔽
            [ "$ENABLE_SHADOW" = "1" ] && ag_shadow_watch_start
            # 2. 守护层 LOCK_DIRS 锁定
            [ "$ENABLE_GUARD" = "1" ] && ag_lock_dirs
            [ "$ENABLE_GREEN_LOCK" = "1" ] && ag_lock_green
        elif [ -z "$gpid" ] && [ "$running" = "1" ]; then
            # 游戏退出
            running=0
            ag_log INFO "游戏退出，还原遮蔽"
            [ "$ENABLE_SHADOW" = "1" ] && {
                ag_shadow_watch_stop
                ag_shadow_restore
            }
            [ "$ENABLE_GUARD" = "1" ] && ag_unlock_dirs
            [ "$ENABLE_GUARD" = "1" ] && ag_unlock_perms
            [ "$ENABLE_GREEN_LOCK" = "1" ] && {
                local bx
                bx=$(ag_stealth_base 2>/dev/null)
                [ -n "$bx" ] && /system/bin/toybox umount -l "$bx/shared_prefs/ace_config.xml" 2>/dev/null
            }
            /system/bin/toybox rm -f "$AG_SHADOW_GAME" 2>/dev/null
        fi

        /system/bin/sleep "$interval"
    done
}
