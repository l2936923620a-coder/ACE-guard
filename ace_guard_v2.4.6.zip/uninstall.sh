#!/system/bin/sh

MODDIR=$(/system/bin/toybox dirname "$(/system/bin/toybox readlink -f "$0")")
. "$MODDIR/script/common.sh" 2>/dev/null
ag_load_conf 2>/dev/null

PKG="${PKG:-com.tencent.tmgp.codev}"
AUTHDIR="/data/adb/ace_guard"
LOG="/data/local/tmp/ace_guard_uninstall.log"

: > "$LOG" 2>/dev/null
log() {
    printf '[%s] %s\n' "$(/system/bin/date '+%H:%M:%S')" "$1" | tee -a "$LOG"
}

SELF_PID=$$
SAFE_PIDS=" "
_p=$SELF_PID
while [ "$_p" != "1" ] && [ -n "$_p" ] && [ "$_p" != "0" ]; do
    SAFE_PIDS="${SAFE_PIDS}${_p} "
    _pp=$(awk '{print $4}' "/proc/$_p/stat" 2>/dev/null)
    [ -n "$_pp" ] || break
    _p="$_pp"
done

is_safe() {
    case "$SAFE_PIDS" in *" $1 "*) return 0 ;; esac
    return 1
}

is_module_proc() {
    # $1=pid  判断是否属于本模块的进程（排除自身/终端/eta）
    _c=$(/system/bin/toybox cat "/proc/$1/cmdline" 2>/dev/null | /system/bin/toybox tr '\0' ' ')
    [ -n "$_c" ] || return 1
    case "$_c" in
        *uninstall.sh*|*io.github.mangi.eta*|*eta-terminal*|*eta/daemon*) return 1 ;;
        *"/data/adb/modules/ace_guard/"*|*"/data/adb/ace_guard/"*) return 0 ;;
        *inotifyd*shadow_cb*) return 0 ;;
    esac
    return 1
}

log "===== ACE Guard 卸载清理开始 ====="
log "自身 PID=$SELF_PID  保护链:$SAFE_PIDS"

log "--- 阶段1/11 停止子进程 ---"
_killed=0
for _d in /proc/[0-9]*; do
    _pid="${_d#/proc/}"
    [ -d "$_d" ] || continue
    is_safe "$_pid" && continue
    if is_module_proc "$_pid"; then
        _c=$(/system/bin/toybox cat "$_d/cmdline" 2>/dev/null | /system/bin/toybox tr '\0' ' ')
        kill -9 "$_pid" 2>/dev/null && {
            _killed=$((_killed + 1))
            log "  kill PID $_pid : $(printf '%s' "$_c" | cut -c1-50)"
        }
    fi
done
# 精确匹配兜底（不用 ace_guard 宽泛词）
for pat in "bin/ag_prop_daemon.sh" "bin/ag_cache_warm.sh" \
           "ag_shadow_lifecycle" "ag_guard_inside" \
           "ag_housekeeping_loop" "ag_mem_check_loop"; do
    /system/bin/pkill -9 -f "$pat" 2>/dev/null && _killed=$((_killed + 1))
done
log "  已停止 $_killed 个进程"
/system/bin/sleep 1

log "--- 阶段2/11 解除挂载 ---"
_unm=0

# 2.1 游戏目录挂载
for d in /data_mirror/data_ce/null/*/"$PKG" /data/user/*/"$PKG" /data/data/"$PKG"; do
    [ -d "$d" ] || continue
    for sub in $RISK_DIRS $CACHE_RISK_SUB $LOCK_DIRS $ACCUSE_DIRS; do
        for base in "$d/files" "$d/cache"; do
            t="$base/$sub"
            /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $t " && \
                /system/bin/toybox umount -l "$t" 2>/dev/null && _unm=$((_unm + 1))
        done
    done
    for t in "$d/shared_prefs/ace_config.xml" "$d/logs" "$d/cache/log"; do
        /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $t " && \
            /system/bin/toybox umount -l "$t" 2>/dev/null && _unm=$((_unm + 1))
    done
done

# 2.2 /proc/modules 绑定（所有命名空间）
for p in /proc/[0-9]*; do
    pid="${p#/proc/}"
    is_safe "$pid" && continue
    /system/bin/nsenter --target "$pid" --mount -- /system/bin/sh -c \
        '/system/bin/toybox umount -l /proc/modules 2>/dev/null' 2>/dev/null
done

# 2.3 兜底：所有指向本模块的挂载（绝不碰模块目录本身）
/system/bin/toybox mount 2>/dev/null | awk '{print $3}' > /data/local/tmp/.ag_mnt 2>/dev/null
while IFS= read -r _mp; do
    [ -n "$_mp" ] || continue
    case "$_mp" in
        # 保护位：模块根目录、授权根目录一律跳过
        "$MODDIR"|"$AUTHDIR") continue ;;
        "/data/adb/modules"|"/data/adb") continue ;;
    esac
    case "$_mp" in
        *"/data/adb/modules/ace_guard/"*|*"/data/adb/ace_guard/"*)
            /system/bin/toybox umount -l "$_mp" 2>/dev/null && _unm=$((_unm + 1)) ;;
    esac
done < /data/local/tmp/.ag_mnt
rm -f /data/local/tmp/.ag_mnt 2>/dev/null

log "  已解除 $_unm 条挂载"

log "--- 阶段3/11 清理 iptables ---"
for chain in ACG_CYCLE ACG_FULL ACG_GUARD; do
    /system/bin/iptables -D OUTPUT -j "$chain" 2>/dev/null
    /system/bin/iptables -F "$chain" 2>/dev/null
    /system/bin/iptables -X "$chain" 2>/dev/null
    /system/bin/ip6tables -D OUTPUT -j "$chain" 2>/dev/null
    /system/bin/ip6tables -F "$chain" 2>/dev/null
    /system/bin/ip6tables -X "$chain" 2>/dev/null
done
log "  完成"

log "--- 阶段4/11 恢复属性 ---"
SNAP="$AUTHDIR/auth/original_identity"
RP=""
for r in /data/adb/ksu/bin/resetprop /data/adb/magisk/resetprop; do
    [ -x "$r" ] && { RP="$r"; break; }
done
[ -z "$RP" ] && RP=$(command -v resetprop 2>/dev/null)

if [ -n "$RP" ] && [ -f "$SNAP" ]; then
    _n=0
    # 4.1 逐属性精确还原
    while IFS='=' read -r _k _v; do
        case "$_k" in PROP_*) ;; *) continue ;; esac
        [ -n "$_v" ] || continue
        _prop=$(printf '%s' "${_k#PROP_}" | tr '_' '.')
        # 只还原原本存在的属性，避免创建新属性产生空洞
        [ -n "$(/system/bin/getprop "$_prop" 2>/dev/null)" ] || continue
        "$RP" "$_prop" "$_v" 2>/dev/null && {
            _n=$((_n + 1))
            log "  $_prop = $_v"
        }
    done < "$SNAP"

    # 4.2 兜底：用汇总值
    if [ "$_n" = "0" ]; then
        R_S=$(sed -n 's/^REAL_SERIAL=//p' "$SNAP" 2>/dev/null)
        R_I=$(sed -n 's/^REAL_IMEI=//p' "$SNAP" 2>/dev/null)
        R_C=$(sed -n 's/^REAL_CHIPECID=//p' "$SNAP" 2>/dev/null)
        [ -n "$R_S" ] && [ "$R_S" != "NOSERIAL" ] && {
            "$RP" ro.serialno "$R_S" 2>/dev/null
            "$RP" ro.boot.serialno "$R_S" 2>/dev/null
            _n=$((_n + 2)) ; log "  ro.serialno = $R_S"
        }
        [ -n "$R_C" ] && [ "$R_C" != "NOCHIP" ] && {
            "$RP" ro.boot.chipecid "$R_C" 2>/dev/null
            _n=$((_n + 1)) ; log "  ro.boot.chipecid = $R_C"
        }
        [ -n "$R_I" ] && [ "$R_I" != "NOIMEI" ] && {
            for key in $IMEI_PROPS; do
                [ -n "$(/system/bin/getprop "$key" 2>/dev/null)" ] && \
                    "$RP" "$key" "$R_I" 2>/dev/null
            done
            _n=$((_n + 1)) ; log "  IMEI 组 = $R_I"
        }
    fi
    log "  共还原 $_n 个属性"

    # 4.3 清除属性区空洞
    "$RP" -c -Z ro.serialno 2>/dev/null
    "$RP" -c -Z persist.radio.imei1 2>/dev/null
    "$RP" -c -Z ro.boot.chipecid 2>/dev/null
    log "  属性区已重建"
else
    log "  [警告] 无快照或 resetprop 不可用"
fi

log "--- 阶段5/11 恢复 Android ID ---"
_orig="$MODDIR/data/original_adid"
if [ -r "$_orig" ]; then
    _an=0
    while IFS='=' read -r _u _v; do
        _u=$(printf '%s' "$_u" | tr -d ' \r\n')
        _v=$(printf '%s' "$_v" | tr -d ' \r\n')
        case "$_u" in ''|*[!0-9]*) continue ;; esac
        case "$_v" in ''|*[!0-9a-f]*) continue ;; esac
        [ ${#_v} -eq 16 ] || continue
        /system/bin/settings --user "$_u" put secure android_id "$_v" 2>/dev/null && {
            _an=$((_an + 1))
            log "  user$_u ADID = $_v"
        }
    done < "$_orig"
    [ "$_an" = "0" ] && log "  (无有效记录)"
else
    log "  [提示] 未记录原始 ADID，保留当前值"
fi

log "--- 阶段6/11 清理遮蔽源目录 ---"
_rm=0

# 6.1 .empty_root 指向的目录
if [ -f "$MODDIR/data/.empty_root" ]; then
    _r=$(cat "$MODDIR/data/.empty_root" 2>/dev/null)
    case "$_r" in
        /data/local/tmp/*|/dev/*) [ -d "$_r" ] && rm -rf "$_r" 2>/dev/null && {
            _rm=$((_rm + 1)); log "  删除 $_r" ; } ;;
    esac
fi

# 6.2 .shadow_root 指向的目录
if [ -f "$MODDIR/data/.shadow_root" ]; then
    _r=$(cat "$MODDIR/data/.shadow_root" 2>/dev/null)
    case "$_r" in
        /data/local/tmp/*|/dev/*) [ -d "$_r" ] && rm -rf "$_r" 2>/dev/null && {
            _rm=$((_rm + 1)); log "  删除 $_r" ; } ;;
    esac
fi

# 6.3 兜底：/data/local/tmp 下形如 .8位hex 的目录
for d in /data/local/tmp/.[0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]; do
    [ -d "$d" ] && rm -rf "$d" 2>/dev/null && { _rm=$((_rm + 1)); log "  删除 $d" ; }
done

log "  共删除 $_rm 个目录"

log "--- 阶段7/11 卸载探针 APK ---"
# 先判断包是否真的存在
_pkg_exists=0
/system/bin/pm list packages 2>/dev/null | /system/bin/grep -q "^package:com.aceguard.probe$" && _pkg_exists=1

if [ "$_pkg_exists" = "0" ]; then
    log "  探针未安装，跳过"
else
/system/bin/am force-stop com.aceguard.probe 2>/dev/null
/system/bin/sleep 1
_r=$(/system/bin/pm uninstall com.aceguard.probe 2>&1)
case "$_r" in
    *Success*) log "  探针已卸载" ;;
    *)
        /system/bin/pm clear com.aceguard.probe >/dev/null 2>&1
        /system/bin/sleep 1
        _r2=$(/system/bin/pm uninstall com.aceguard.probe 2>&1)
        case "$_r2" in
            *Success*) log "  探针已卸载（二次）" ;;
            *)
                _apk=$(/system/bin/pm path com.aceguard.probe 2>/dev/null | head -n1 | sed 's/^package://')
                [ -n "$_apk" ] && rm -f "$_apk" 2>/dev/null
                rm -rf /data/data/com.aceguard.probe 2>/dev/null
                log "  [警告] pm 卸载失败，已强制删除文件" ;;
        esac ;;
esac
rm -rf /sdcard/Android/data/com.aceguard.probe 2>/dev/null
rm -rf /data/media/0/Android/data/com.aceguard.probe 2>/dev/null
fi

log "--- 阶段8/11 清理外部残留 ---"
rm -f /data/adb/service.d/ace_guard_selfcheck.sh 2>/dev/null && log "  删除 service.d 自检脚本"
rm -f /data/adb/post-fs-data.d/ace_guard*.sh 2>/dev/null
rm -rf /sdcard/ace_guard_thermal_backup_* 2>/dev/null
rm -rf /data/local/tmp/ace_guard* 2>/dev/null
rm -f  /data/local/tmp/aceguard-probe.apk 2>/dev/null
rm -f  /data/local/tmp/.ag_mnt /data/local/tmp/.ag_mnts /data/local/tmp/.ag_mnts2 2>/dev/null
log "  完成"

log "--- 阶段9/11 清理模块数据 ---"
# 注意：只删数据目录，不删脚本所在目录本身
rm -rf "$MODDIR/data" 2>/dev/null && log "  删除 data/"
rm -rf "$MODDIR/log"  2>/dev/null && log "  删除 log/"
rm -rf "$AUTHDIR"     2>/dev/null && log "  删除 /data/adb/ace_guard（含授权）"

log "--- 阶段10/11 还原 module.prop ---"
if [ -f "$MODDIR/.module.prop.orig" ]; then
    cp -f "$MODDIR/.module.prop.orig" "$MODDIR/module.prop" 2>/dev/null && \
        rm -f "$MODDIR/.module.prop.orig" 2>/dev/null && \
        log "  已还原原始描述"
else
    # 无备份则剥掉所有标记
    sed -i 's/【[^】]*】//g; s/⚠️[^｜]*｜//g' "$MODDIR/module.prop" 2>/dev/null
    log "  已剥离授权标记"
fi

log "--- 阶段11/11 最终核对 ---"

# 剩余挂载
_m=$(/system/bin/toybox mount 2>/dev/null | awk '{print $3}' | grep -c "ace_guard")
log "  剩余模块挂载: $_m"

# 剩余进程
_pn=0
for _d in /proc/[0-9]*; do
    _pid="${_d#/proc/}"
    [ -d "$_d" ] || continue
    is_safe "$_pid" && continue
    is_module_proc "$_pid" && _pn=$((_pn + 1))
done
log "  剩余模块进程: $_pn"

# 属性核对
if [ -n "$RP" ] && [ -f "$SNAP" ] 2>/dev/null; then
    _cur=$(/system/bin/getprop ro.serialno 2>/dev/null)
    _real=$(sed -n 's/^REAL_SERIAL=//p' "$SNAP" 2>/dev/null | head -n1)
    if [ -n "$_real" ] && [ "$_cur" = "$_real" ]; then
        log "  属性核对: ✓ SERIAL 已恢复 ($_cur)"
    else
        log "  属性核对: SERIAL=$_cur"
    fi
fi

# 残留清单
log "  待 KSU 重启后自动删除: $MODDIR"
log ""
log "===== 卸载清理完成 ====="
log "日志: $LOG"
log ""

# 日志已通过 tee 实时输出，无需重复打印
exit 0
