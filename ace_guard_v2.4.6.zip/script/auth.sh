#!/system/bin/sh

# 密钥与签名（由核心程序提供）
AG_CORE="${MODDIR:-/data/adb/modules/ace_guard}/lib/agcore"
[ -f "${MODDIR:-/data/adb/modules/ace_guard}/script/keys.sh" ] && \
    . "${MODDIR:-/data/adb/modules/ace_guard}/script/keys.sh"

AG_AUTH_DIR="/data/adb/ace_guard/auth"
AG_AUTH_FILE="$AG_AUTH_DIR/license"
AG_AUTH_STAMP="$AG_AUTH_DIR/.tstamp"
AG_AUTH_LASTOK="$AG_AUTH_DIR/.lastok"
AG_AUTH_LOG="$AG_AUTH_DIR/auth.log"
AG_SNAPSHOT="$AG_AUTH_DIR/original_identity"     # 真机指纹快照
AG_SNAPSHOT_BAK="$AG_AUTH_DIR/.original_identity.bak"

AG_AUTH_OK=0
AG_AUTH_DEVICE=""
AG_AUTH_CODE=""
AG_AUTH_ISSUED=0
AG_AUTH_EXPIRE=0
AG_AUTH_REASON="未初始化"
AG_AUTH_CODE_ERR="UNKNOWN"

mkdir -p "$AG_AUTH_DIR" 2>/dev/null
chmod 700 "$AG_AUTH_DIR" 2>/dev/null

# ---------- MODDIR 兜底 ----------
# auth.sh 可能被单独 source（不经 common.sh），此时 MODDIR 为空，
# 会导致 ag_auth_update_prop 静默失败、module.prop 永不刷新。
if [ -z "${MODDIR:-}" ]; then
    MODDIR="/data/adb/modules/ace_guard"
fi

# 签名密钥：运行时派生，不在脚本里保存可直接复制的明文
# 材料 = 构建常量 + 设备只读属性，换机或改脚本都拿不到同一个密钥
# 授权密钥：固定值，与设备无关
#   这样你签发的授权码在任何设备上都能验证通过，
#   修改此值会导致所有已签发的授权码失效，请勿随意改动。
# 授权密钥：由核心程序内部持有，脚本不保存
ag_auth_secret() {
    if [ -x "$AG_CORE" ]; then
        "$AG_CORE" key 2>/dev/null
        return 0
    fi
    printf '%s' ""
}

# 兼容密钥：仅用于验证历史授权码，不参与签发
ag_auth_secret_legacy() {
    printf '%s' "$(printf '%s' 'a3f9c2e1')$(printf '%s' '7b4d8056')$(printf '%s' '1e9f4a7c')$(printf '%s' 'd2b63085')$(printf '%s' '4c8ea19f')"
}

# sha256 结果缓存（进程内，按输入缓存最近 32 条）
AG_SHA_CACHE=""
AG_SHA_KEYS=""

ag_sha256() {
    case "$AG_SHA_KEYS" in
        *"|$1|"*)
            printf '%s' "$AG_SHA_CACHE" | /system/bin/toybox grep "^$1 " 2>/dev/null | head -n1 | cut -d' ' -f2-
            return 0 ;;
    esac
    _r=$(_ag_sha256_raw "$1")
    [ -n "$_r" ] || return 1
    AG_SHA_CACHE="$AG_SHA_CACHE
$1 $_r"
    AG_SHA_KEYS="$AG_SHA_KEYS|$1|"
    # 控制缓存规模
    if [ $(printf '%s' "$AG_SHA_KEYS" | /system/bin/toybox tr -cd '|' | wc -c) -gt 64 ]; then
        AG_SHA_CACHE=""; AG_SHA_KEYS=""
    fi
    printf '%s' "$_r"
}

_ag_sha256_raw() {
    for p in /system/bin/sha256sum /system/bin/toybox /system/bin/busybox; do
        case "$p" in
            */sha256sum) [ -x "$p" ] && { printf '%s' "$1" | "$p" | cut -c1-64; return 0; } ;;
            */toybox)    [ -x "$p" ] && { printf '%s' "$1" | "$p" sha256sum 2>/dev/null | cut -c1-64; return 0; } ;;
            */busybox)   [ -x "$p" ] && { printf '%s' "$1" | "$p" sha256sum 2>/dev/null | cut -c1-64; return 0; } ;;
        esac
    done
    return 1
}

# 签名：sha256(secret|msg|secret) —— 不依赖 openssl/hmac
# 与 tools/ag_license.py 的 sign() 必须完全一致
# 用指定密钥算 HMAC
#   $1 = 密钥  $2 = 消息
ag_hmac_with() {
    ag_sha256 "${1}|${2}|${1}"
}

# 签名（用当前密钥）
ag_hmac_hex() {
    _sec=$(ag_auth_secret)
    ag_hmac_with "$_sec" "$1"
}

# 签名（用兼容密钥）
ag_hmac_hex_legacy() {
    _sec=$(ag_auth_secret_legacy)
    ag_hmac_with "$_sec" "$1"
}

# 读取当前系统属性中的真机指纹
# 注意：必须在指纹注入之前调用，否则拿到的是伪装值
ag_auth_read_real_fingerprint() {
    AG_REAL_SERIAL=$(/system/bin/getprop ro.boot.serialno 2>/dev/null)
    [ -z "$AG_REAL_SERIAL" ] && AG_REAL_SERIAL=$(/system/bin/getprop ro.serialno 2>/dev/null)

    AG_REAL_IMEI=$(/system/bin/getprop persist.radio.imei1 2>/dev/null)
    [ -z "$AG_REAL_IMEI" ] && AG_REAL_IMEI=$(/system/bin/getprop persist.radio.imei 2>/dev/null)
    [ -z "$AG_REAL_IMEI" ] && AG_REAL_IMEI=$(/system/bin/getprop ro.ril.oem.imei1 2>/dev/null)

    AG_REAL_CHIPECID=$(/system/bin/getprop ro.boot.chipecid 2>/dev/null)

    AG_REAL_MODEL=$(/system/bin/getprop ro.product.model 2>/dev/null)
    AG_REAL_BRAND=$(/system/bin/getprop ro.product.brand 2>/dev/null)
    AG_REAL_DEVICE=$(/system/bin/getprop ro.product.device 2>/dev/null)
    AG_REAL_FP=$(/system/bin/getprop ro.build.fingerprint 2>/dev/null)

    # 逐属性原值（卸载时精确还原用）
    # v1.9.8 扩全：覆盖所有会被覆盖的身份属性，供授权页展示完整原始值
    AG_REAL_PROPS=""
    for _k in ro.serialno ro.boot.serialno ro.boot.chipecid ro.boot.chipid \
              persist.radio.imei persist.radio.imei1 persist.radio.imei2 persist.radio.imei9 \
              ril.gsm.imei gsm.serial \
              vendor.gsm.serial ro.vendor.gsm.serial \
              ro.vendor.oplus.radio.serialno vendor.oplus.caihong.serialno persist.sys.oplus.serialno \
              ro.ril.oem.imei ro.ril.oem.imei1; do
        _v=$(/system/bin/getprop "$_k" 2>/dev/null)
        [ -n "$_v" ] && AG_REAL_PROPS="$AG_REAL_PROPS
PROP_$(printf '%s' "$_k" | tr '.' '_')=$_v"
    done
    # ADID 原始值也记入快照（归属用户那份）
    _u0=$(_ag_primary_user 2>/dev/null || echo 0)
    _adid0=$(/system/bin/settings --user "$_u0" get secure android_id 2>/dev/null)
    if [ -n "$_adid0" ] && [ "$_adid0" != "null" ]; then
        AG_REAL_PROPS="$AG_REAL_PROPS
PROP_android_id=$_adid0"
    fi
}

# 首次安装时采集并备份真机指纹。已存在则跳过（绝不覆盖）。
# 返回 0=已就绪 1=失败
ag_auth_snapshot_init() {
    if [ -f "$AG_SNAPSHOT" ] && [ -s "$AG_SNAPSHOT" ]; then
        return 0
    fi
    # 从备份恢复（若快照被误删）
    if [ -f "$AG_SNAPSHOT_BAK" ] && [ -s "$AG_SNAPSHOT_BAK" ]; then
        cp -f "$AG_SNAPSHOT_BAK" "$AG_SNAPSHOT" 2>/dev/null
        [ -s "$AG_SNAPSHOT" ] && return 0
    fi

    ag_auth_read_real_fingerprint
    _now=$(/system/bin/date +%s)

    # 真机指纹可能是空（部分设备无 chipecid/imei）
    # 空值用占位符固定，保证设备码稳定
    [ -z "$AG_REAL_SERIAL" ]   && AG_REAL_SERIAL="NOSERIAL"
    [ -z "$AG_REAL_IMEI" ]     && AG_REAL_IMEI="NOIMEI"
    [ -z "$AG_REAL_CHIPECID" ] && AG_REAL_CHIPECID="NOCHIP"

    {
        echo "# ace_guard 真机指纹快照（首次安装时采集，用于授权溯源）"
        echo "REAL_SERIAL=$AG_REAL_SERIAL"
        echo "REAL_IMEI=$AG_REAL_IMEI"
        echo "REAL_CHIPECID=$AG_REAL_CHIPECID"
        echo "REAL_MODEL=$AG_REAL_MODEL"
        echo "REAL_BRAND=$AG_REAL_BRAND"
        echo "REAL_DEVICE=$AG_REAL_DEVICE"
        echo "REAL_FP=$AG_REAL_FP"
        [ -n "$AG_REAL_PROPS" ] && printf '%s\n' "$AG_REAL_PROPS"
        echo "SNAPSHOT_TIME=$_now"
    } > "$AG_SNAPSHOT.tmp" 2>/dev/null || return 1

    chmod 600 "$AG_SNAPSHOT.tmp" 2>/dev/null
    mv -f "$AG_SNAPSHOT.tmp" "$AG_SNAPSHOT" 2>/dev/null || return 1
    cp -f "$AG_SNAPSHOT" "$AG_SNAPSHOT_BAK" 2>/dev/null

    command -v ag_log >/dev/null 2>&1 && \
        ag_log INFO "真机指纹快照已建立 SERIAL=$AG_REAL_SERIAL CHIPECID=$AG_REAL_CHIPECID"
    return 0
}

# 从快照读取真机指纹到 AG_R_* 变量
ag_auth_snapshot_load() {
    AG_R_SERIAL=""; AG_R_IMEI=""; AG_R_CHIPECID=""
    AG_R_MODEL=""; AG_R_BRAND=""; AG_R_DEVICE=""; AG_R_FP=""; AG_R_TIME=0
    [ -f "$AG_SNAPSHOT" ] || return 1
    _k=""; _v=""
    while IFS='=' read -r _k _v; do
        _v=$(printf '%s' "$_v" | tr -d '\r')
        case "$_k" in
            REAL_SERIAL)   AG_R_SERIAL="$_v" ;;
            REAL_IMEI)     AG_R_IMEI="$_v" ;;
            REAL_CHIPECID) AG_R_CHIPECID="$_v" ;;
            REAL_MODEL)    AG_R_MODEL="$_v" ;;
            REAL_BRAND)    AG_R_BRAND="$_v" ;;
            REAL_DEVICE)   AG_R_DEVICE="$_v" ;;
            REAL_FP)       AG_R_FP="$_v" ;;
            SNAPSHOT_TIME) AG_R_TIME="$_v" ;;
        esac
    done < "$AG_SNAPSHOT"
    [ -n "$AG_R_SERIAL" ]
}

# 设备码 = sha256(SERIAL|IMEI|CHIPECID|acguard-device)[:16]
# 三种指纹全部参与，任一变化设备码即变 → 授权失效
# 设备码缓存
#   注意：函数常被 $( ) 调用，在子 shell 中执行，无法回写父进程变量。
#   所以在 ag_webui.sh / auth.sh 入口处主动预热一次（见 ag_auth_init_cache），
#   之后所有调用直接读 AG_AUTH_DEVID。
AG_AUTH_DEVID="${AG_AUTH_DEVID:-}"

ag_auth_device_id() {
    if [ -n "$AG_AUTH_DEVID" ]; then
        printf '%s' "$AG_AUTH_DEVID"
        return 0
    fi
    _ag_auth_device_id_uncached
}

# 主动预热：在当前进程内算好设备码并存入全局变量
ag_auth_init_cache() {
    [ -n "$AG_AUTH_DEVID" ] && return 0
    AG_AUTH_DEVID=$(_ag_auth_device_id_uncached)
    # 已父进程赋值，同时导出给子 shell
    export AG_AUTH_DEVID
    return 0
}

_ag_auth_device_id_uncached() {
    if ! ag_auth_snapshot_load; then
        # 没有快照时退回属性读取（保证 UI 永远有值可显示）
        ag_auth_read_real_fingerprint
        _s="$AG_REAL_SERIAL"; _i="$AG_REAL_IMEI"; _c="$AG_REAL_CHIPECID"
        [ -z "$_s" ] && _s="NOSERIAL"
        [ -z "$_i" ] && _i="NOIMEI"
        [ -z "$_c" ] && _c="NOCHIP"
        _raw="${_s}|${_i}|${_c}|acguard-device"
    else
        _raw="${AG_R_SERIAL}|${AG_R_IMEI}|${AG_R_CHIPECID}|acguard-device"
    fi
    ag_sha256 "$_raw" | cut -c1-16
}

# 分项指纹短码，便于人工核对是哪一项变了
ag_auth_fp_serial()   { ag_sha256 "$1|acguard-s" | cut -c1-8; }
ag_auth_fp_imei()     { ag_sha256 "$1|acguard-i" | cut -c1-8; }
ag_auth_fp_chipecid() { ag_sha256 "$1|acguard-c" | cut -c1-8; }

# 格式: AG-<expire_hex>-<sig16>   expire_hex=0 → 永久
ag_auth_sign() {
    _s=$(ag_hmac_hex "$1|$2|acguard")
    printf '%.16s' "$_s"
}

ag_auth_gen_code() {
    _exp=$(printf '%x' "${2:-0}")
    _sig=$(ag_auth_sign "$1" "$_exp")
    printf 'AG-%s-%s' "$_exp" "$_sig" | tr 'a-f' 'A-F'
}

# 返回 0=有效 1=签名错 2=已过期
ag_auth_verify_code() {
    case "$2" in AG-*-*) ;; *) return 1 ;; esac

    _core="${MODDIR:-/data/adb/modules/ace_guard}/lib/agcore"

    if [ -x "$_core" ]; then
        # 由核心程序完成验签与到期判断
        _legacy=$(ag_auth_secret_legacy 2>/dev/null)
        _res=$(AG_LEGACY_KEY="$_legacy" "$_core" verify "$1" "$2" 2>/dev/null)
        case "$_res" in
            OK*)      ag_auth_note_code "$2" "core"
                      AG_AUTH_EXPIRE_FROM_CORE="${_res#OK }"
                      return 0 ;;
            EXPIRED*) return 2 ;;
            *)        return 1 ;;
        esac
    fi

    # 核心程序不可用时的兜底校验
    _exp=$(printf '%s' "$2" | sed 's/^AG-//; s/-.*$//' | tr 'A-F' 'a-f')
    _sig=$(printf '%s' "$2" | sed 's/.*-//'         | tr 'A-F' 'a-f')
    [ -n "$_exp" ] && [ -n "$_sig" ] || return 1
    if [ "$_sig" = "$(ag_auth_sign "$1" "$_exp")" ]; then
        ag_auth_note_code "$2" "current"
    else
        _leg2=$(ag_hmac_with "$(ag_auth_secret_legacy)" "${1}|${_exp}|acguard" | /system/bin/toybox cut -c1-16)
        [ "$_sig" = "$_leg2" ] || return 1
        ag_auth_note_code "$2" "legacy"
    fi
    [ "$_exp" = "0" ] && return 0
    _now=$(/system/bin/date +%s)
    [ "$_now" -lt $((0x$_exp)) ] || return 2
}

# 记录本机已见过的授权码指纹，用于发现异常批量/模拟特征
ag_auth_note_code() {
    _cdir="${AG_AUTH_DIR:-/data/adb/ace_guard/auth}"
    _cf="$_cdir/.code_seen"
    _fp=$(printf '%s' "$1" | /system/bin/toybox sha256sum 2>/dev/null | /system/bin/toybox cut -c1-16)
    [ -n "$_fp" ] || return 0
    mkdir -p "$_cdir" 2>/dev/null
    # 同一码重复出现只记一次
    if [ -f "$_cf" ] && /system/bin/grep -qF "$_fp" "$_cf" 2>/dev/null; then
        return 0
    fi
    echo "$(/system/bin/date +%s) $_fp $2" >> "$_cf" 2>/dev/null
    chmod 600 "$_cf" 2>/dev/null
    return 0
}

ag_auth_expire_of() {
    _e=$(printf '%s' "$1" | sed 's/^AG-//; s/-.*$//' | tr 'A-F' 'a-f')
    [ "$_e" = "0" ] && { echo 0; return; }
    printf '%d\n' $((0x$_e))
}

ag_auth_load() {
    AG_AUTH_OK=0; AG_AUTH_DEVICE=""; AG_AUTH_CODE=""; AG_AUTH_ISSUED=0; AG_AUTH_EXPIRE=0
    AG_AUTH_SIG=""
    [ -f "$AG_AUTH_FILE" ] || { AG_AUTH_REASON="授权文件不存在，本机尚未激活"; AG_AUTH_CODE_ERR="NO_FILE"; return 1; }

    device=""; code=""; issued=""; sig=""
    . "$AG_AUTH_FILE" 2>/dev/null

    AG_AUTH_DEVICE="${device:-}"
    AG_AUTH_CODE="${code:-}"
    AG_AUTH_ISSUED="${issued:-0}"
    AG_AUTH_SIG="${sig:-}"

    if [ -z "$AG_AUTH_DEVICE" ] || [ -z "$AG_AUTH_CODE" ]; then
        AG_AUTH_REASON="授权文件内容损坏（缺少必要字段）"; AG_AUTH_CODE_ERR="CORRUPT"; return 1
    fi

    # 文件完整性签名：新密钥优先，兼容旧密钥签的历史文件
    _chk=$(printf '%.16s' "$(ag_hmac_hex "${AG_AUTH_DEVICE}|${AG_AUTH_CODE}|${AG_AUTH_ISSUED}|file")")
    if [ -n "$AG_AUTH_SIG" ] && [ "$AG_AUTH_SIG" != "$_chk" ]; then
        _chk_old=$(printf '%.16s' "$(ag_hmac_with "$(ag_auth_secret_legacy)" "${AG_AUTH_DEVICE}|${AG_AUTH_CODE}|${AG_AUTH_ISSUED}|file")")
        if [ "$AG_AUTH_SIG" = "$_chk_old" ]; then
            # 旧格式文件：静默升级为新密钥重签，用户无感
            _sig_new=$(printf '%.16s' "$(ag_hmac_hex "${AG_AUTH_DEVICE}|${AG_AUTH_CODE}|${AG_AUTH_ISSUED}|file")")
            /system/bin/sed -i "s|^sig=.*|sig=${_sig_new}|" "$AG_AUTH_FILE" 2>/dev/null
        else
            AG_AUTH_REASON="授权文件校验未通过，内容可能被改动"
            AG_AUTH_CODE_ERR="TAMPERED"
            return 1
        fi
    fi

    AG_AUTH_EXPIRE=$(ag_auth_expire_of "$AG_AUTH_CODE")
    return 0
}

ag_auth_save() {
    _issued=$(/system/bin/date +%s)
    _sig=$(ag_hmac_hex "$1|$2|$_issued|file"); _sig=$(printf '%.16s' "$_sig")
    {
        echo "# ace_guard license"
        echo "device=$1"
        echo "code=$2"
        echo "issued=$_issued"
        echo "sig=$_sig"
    } > "$AG_AUTH_FILE"
    chmod 600 "$AG_AUTH_FILE" 2>/dev/null
    cp -f "$AG_AUTH_FILE" "$AG_AUTH_DIR/.license.bak" 2>/dev/null
}

ag_auth_clear() {
    rm -f "$AG_AUTH_FILE" "$AG_AUTH_STAMP" "$AG_AUTH_LASTOK" 2>/dev/null
    AG_AUTH_OK=0
    AG_AUTH_REASON="授权文件已被清除"
    AG_AUTH_CODE_ERR="NO_FILE"
    # 立即同步 module.prop，避免场景：清授权后卡片仍显示已授权
    ag_auth_update_prop
}

ag_auth_antiroll() {
    _now=$(/system/bin/date +%s)
    _last=$(cat "$AG_AUTH_STAMP" 2>/dev/null || echo 0)
    if [ "$_last" -gt 0 ] && [ "$_now" -lt $((_last - 21600)) ]; then
        AG_AUTH_REASON="检测到系统时间被回拨，授权暂不可用，请校准系统时间"
        AG_AUTH_CODE_ERR="CLOCK_ROLL"
        return 1
    fi
    if [ -f "$AG_AUTH_STAMP" ]; then
        _mt=$(/system/bin/toybox stat -c %Y "$AG_AUTH_STAMP" 2>/dev/null || echo 0)
        if [ "$_mt" -gt 0 ] && [ "$_now" -lt $((_mt - 21600)) ]; then
            AG_AUTH_REASON="系统时间早于授权记录时间，请校准系统时间"
            AG_AUTH_CODE_ERR="CLOCK_ROLL"
            return 1
        fi
    fi
    [ "$_now" -gt "$_last" ] && echo "$_now" > "$AG_AUTH_STAMP" 2>/dev/null
    return 0
}

ag_auth_valid() {
    # 进程内缓存：同一次调用里反复校验无意义
    [ "$AG_AUTH_OK" = "1" ] && return 0
    case "${AG_AUTH_VALID_CACHE:-}" in
        1) return 0 ;;
        0) return 1 ;;
    esac

    # 快照必须先就绪，否则设备码不稳定
    ag_auth_snapshot_init || { AG_AUTH_REASON="真机指纹快照建立失败"; AG_AUTH_CODE_ERR="NO_SNAPSHOT"; return 1; }

    ag_auth_load || return 1
    ag_auth_antiroll || return 1

    ag_auth_init_cache
    _dev="$AG_AUTH_DEVID"
    if [ "$_dev" != "$AG_AUTH_DEVICE" ]; then
        AG_AUTH_REASON="真机指纹已变化，原授权与本设备不匹配"
        AG_AUTH_CODE_ERR="FP_CHANGED"
        return 1
    fi

    ag_auth_verify_code "$AG_AUTH_DEVICE" "$AG_AUTH_CODE"
    case $? in
        0) ;;
        2) AG_AUTH_REASON="授权已到期"; AG_AUTH_CODE_ERR="EXPIRED"; return 1 ;;
        *) AG_AUTH_REASON="授权码签名无效，与本设备不匹配"; AG_AUTH_CODE_ERR="CODE_BAD"; return 1 ;;
    esac

    # 授权码是否通过校验但存在异常特征
    if command -v ag_auth_check_anomaly >/dev/null 2>&1; then
        if ! ag_auth_check_anomaly; then
            AG_AUTH_REASON="授权信息异常：${AG_ANOMALY:-与本机不匹配}"
            AG_AUTH_CODE_ERR="ANOMALY"
            return 1
        fi
    fi

    # 运行环境自检：异常时记录但不阻断，避免误伤正常用户
    if command -v ag_env_check >/dev/null 2>&1; then
        if ! ag_env_check; then
            echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') ENV_ANOMALY 运行环境异常" >> "$AG_AUTH_LOG" 2>/dev/null
            command -v ag_log >/dev/null 2>&1 && ag_log WARN "运行环境异常，已记录"
        fi
    fi

    AG_AUTH_OK=1
    AG_AUTH_REASON="已授权"
    AG_AUTH_CODE_ERR="OK"
    echo "$(ag_auth_device_id)|$(/system/bin/date +%s)" > "$AG_AUTH_LASTOK" 2>/dev/null
    return 0
}

ag_auth_validate_silent() {
    # 已有结论则直接复用，不重新计算
    [ "$AG_AUTH_OK" = "1" ] && return 0
    case "${AG_AUTH_VALID_CACHE:-}" in
        1) AG_AUTH_OK=1; return 0 ;;
        0) return 1 ;;
    esac
    AG_AUTH_OK=0
    ag_auth_valid >/dev/null 2>&1
    if [ "$AG_AUTH_OK" = "1" ]; then
        AG_AUTH_VALID_CACHE=1
    else
        AG_AUTH_VALID_CACHE=0
    fi
    return $([ "$AG_AUTH_OK" = "1" ] && echo 0 || echo 1)
}

ag_auth_guard() {
    if ag_auth_valid; then
        return 0
    fi
    _who=${1:-${0##*/}}
    _msg="未授权拦截 [$AG_AUTH_REASON] 调用者=$_who 设备码=$(ag_auth_device_id)"
    echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') $_msg" >> "$AG_AUTH_LOG" 2>/dev/null
    command -v ag_log >/dev/null 2>&1 && ag_log WARN "$_msg"
    # 被拒绝时也刷新一次卡片，确保 KSU 里文案与真实状态一致
    ag_auth_update_prop
    return 1
}

ag_auth_activate() {
    _code=$(printf '%s' "$1" | tr -d ' \t\r\n' | tr 'a-f' 'A-F')
    [ -n "$_code" ] || { AG_AUTH_REASON="请输入授权码"; AG_AUTH_CODE_ERR="EMPTY_INPUT"; return 1; }

    ag_auth_snapshot_init || { AG_AUTH_REASON="真机指纹快照建立失败"; AG_AUTH_CODE_ERR="NO_SNAPSHOT"; return 1; }
    _dev=$(ag_auth_device_id)

    ag_auth_verify_code "$_dev" "$_code"
    case $? in
        0) ;;
        2) AG_AUTH_REASON="授权码有效但已过期"; AG_AUTH_CODE_ERR="EXPIRED"; return 2 ;;
        *) AG_AUTH_REASON="授权码与本机设备码不匹配（该码不属于本机）"; AG_AUTH_CODE_ERR="CODE_BAD"; return 1 ;;
    esac

    ag_auth_save "$_dev" "$_code"
    AG_AUTH_OK=0
    ag_auth_validate_silent
    ag_auth_update_prop
    ag_auth_upload_cloud "activate"
    command -v ag_log >/dev/null 2>&1 && \
        ag_log INFO "授权激活成功 device=$_dev expire=$(ag_auth_expire_of "$_code")"
    return 0
}

# 到期时间直接展示（不做天数递减）
#  module.prop 动态改写
#  设备码导出（供签发 APP 读取，APP 无 root）
#  云端上报（预留位置）
#  启动/刷新
#  卡片文案守护
#  未授权提示文本
