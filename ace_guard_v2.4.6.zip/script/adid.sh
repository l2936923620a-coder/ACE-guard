#!/system/bin/sh

[ "${_AG_ADID_SHIM:-0}" = "1" ] && return 0 2>/dev/null
_AG_ADID_SHIM=1

_ag_adid_shim_load() {
    local f
    for f in \
        "${MODDIR:-/data/adb/modules/ace_guard}/script/identity.sh" \
        "/data/adb/modules/ace_guard/script/identity.sh" ; do
        [ -f "$f" ] && { . "$f" 2>/dev/null; return 0; }
    done
    return 1
}

if ! command -v ag_identity_load >/dev/null 2>&1; then
    _ag_adid_shim_load || {
        echo "adid.sh: identity.sh 缺失，身份功能不可用" >&2
    }
fi

# 兼容变量名（旧脚本可能直接引用）
AG_ADID_LEGACY="${AG_ADID_LEGACY:-$DATA_DIR/adid}"
AG_IDENTITY_FILE="${AG_IDENTITY_FILE:-$DATA_DIR/identity}"
