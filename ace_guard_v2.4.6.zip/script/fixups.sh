#!/system/bin/sh

ag_fixup_selfcheck() {
    local miss="" f
    for f in ag_empty_for ag_prepare_empty ag_check_mounts ag_hide_empty; do
        command -v "$f" >/dev/null 2>&1 || miss="$miss $f"
    done
    [ -z "$miss" ] && return 0
    ag_log ERROR "缺失函数:$miss"
    return 1
}
