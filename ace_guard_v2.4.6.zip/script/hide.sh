#!/system/bin/sh

# >>> AG-AUTH-GUARD >>>
# 授权闸门（性能优化版）
#   1) 同进程内复用：_AG_AUTH_GUARDED=1 直接跳过
#   2) 跨进程复用：60 秒内通过的标记文件，避免每次 source 都跑 sha256
#   3) 缓存失效才真正校验
if [ "${_AG_AUTH_GUARDED:-0}" != "1" ]; then
    _ag_gcache="/data/adb/ace_guard/auth/.guardok"
    _ag_gok=0
    if [ -f "$_ag_gcache" ]; then
        _ag_gt=$(cat "$_ag_gcache" 2>/dev/null)
        _ag_now=$(/system/bin/date +%s)
        # 60 秒内的标记视为有效
        case "$_ag_gt" in
            ''|*[!0-9]*) : ;;
            *) [ $(( _ag_now - _ag_gt )) -lt 60 ] && _ag_gok=1 ;;
        esac
    fi
    if [ "$_ag_gok" != "1" ]; then
        if [ -f "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh" ]; then
            . "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh"
            if ! ag_auth_guard "${0##*/}" 2>/dev/null; then
                echo "此设备未授权，功能已冻结" >&2
                exit 1
            fi
            /system/bin/date +%s > "$_ag_gcache" 2>/dev/null
        fi
    fi
fi
_AG_AUTH_GUARDED=1
# <<< AG-AUTH-GUARD <<<

AG_FAKE="$DATA_DIR/.pm_fake"

# ---------- 兼容桩：状态查询用，恒返回"已注入" ----------
# monitor.sh 的 ag_check_hide / action.sh 的 status 依赖此函数，
# 隐藏功能移除后不再有注入概念，统一视为满足。
ag_hide_injected() {
    return 0
}

# ---------- 空源目录（守护层 LOCK_DIRS bind 用）----------
ag_hide_empty() {
    : > "$DATA_DIR/.empty" 2>/dev/null
    /system/bin/chmod 000 "$DATA_DIR/.empty" 2>/dev/null
}
