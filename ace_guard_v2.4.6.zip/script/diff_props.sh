#!/system/bin/sh

# 从探针 JSON 提取某 key 的 detail
ag_diff_probe_value() {  # $1=JSON $2=key
    printf '%s' "$1" | /system/bin/toybox tr '{' '\n' \
        | /system/bin/grep "\"key\":\"$2\"" \
        | sed -n 's/.*"detail":"\([^"]*\)".*/\1/p' | head -n1
}

ag_diff_probe_state() {  # $1=JSON $2=key
    printf '%s' "$1" | /system/bin/toybox tr '{' '\n' \
        | /system/bin/grep "\"key\":\"$2\"" \
        | sed -n 's/.*"state":"\([^"]*\)".*/\1/p' | head -n1
}

ag_diff_props_items() {
    _probe="$1"
    _items=""
    _add() {
        [ -n "$_items" ] && _items="$_items,"
        _items="$_items{\"group\":\"属性对比\",\"key\":\"$1\",\"name\":\"$2\",\"state\":\"$3\",\"detail\":\"$4\",\"important\":${5:-1},\"scope\":\"app\"}"
    }

    if [ -z "$_probe" ]; then
        printf '[]'
        return
    fi

    _ok=0; _fail=0; _skip=0; _warn=0

    # 伪装值（模块当前配置）
    _exp_s=""; _exp_i=""; _exp_c=""
    if [ -r "$DATA_DIR/identity" ]; then
        _exp_s=$(/system/bin/sed -n 's/^SERIAL=//p'   "$DATA_DIR/identity" | head -n1)
        _exp_i=$(/system/bin/sed -n 's/^IMEI=//p'     "$DATA_DIR/identity" | head -n1)
        _exp_c=$(/system/bin/sed -n 's/^CHIPECID=//p' "$DATA_DIR/identity" | head -n1)
    fi
    # 真机值
    _real_s=""; _real_i=""; _real_c=""
    if [ -r "$AG_SNAPSHOT" ]; then
        _real_s=$(/system/bin/sed -n 's/^REAL_SERIAL=//p'   "$AG_SNAPSHOT" | head -n1)
        _real_i=$(/system/bin/sed -n 's/^REAL_IMEI=//p'     "$AG_SNAPSHOT" | head -n1)
        _real_c=$(/system/bin/sed -n 's/^REAL_CHIPECID=//p' "$AG_SNAPSHOT" | head -n1)
    fi

    # 单属性判定
    _check() {  # $1=探针key $2=中文名 $3=伪装值 $4=真机值
        _st=$(ag_diff_probe_state "$_probe" "$1")
        _v=$(ag_diff_probe_value "$_probe" "$1")
        [ -n "$_st" ] || { _skip=$((_skip + 1)); return; }

        # 空值 → 跳过不显示
        case "$_v" in
            ""|"空"*|"不可读"*|"不存在"*)
                _skip=$((_skip + 1))
                return ;;
        esac

        if [ -n "$4" ] && [ "$_v" = "$4" ]; then
            _add "diff_$1" "$2" "FAIL" "读到真机值 $_v"
            _fail=$((_fail + 1))
        elif [ -n "$3" ] && [ "$_v" = "$3" ]; then
            _add "diff_$1" "$2" "OK" "伪装 $_v"
            _ok=$((_ok + 1))
        else
            _add "diff_$1" "$2" "WARN" "$_v（预期 $_3）"
            _fail=$((_fail + 1))
        fi
    }

    _check "prop_serial"     "序列号" "$_exp_s" "$_real_s"
    _check "prop_bootserial" "序列号(启动)" "$_exp_s" "$_real_s"
    _check "prop_chipecid"   "芯片ID" "$_exp_c" "$_real_c"

    # chipid（v1.9.7 补：ro.boot.chipid = chipecid 后 8 位，曾漏覆盖）
    _cur_cid8=$(/system/bin/getprop ro.boot.chipid 2>/dev/null)
    _exp_cid8=""
    [ -n "$_exp_c" ] && _exp_cid8=$(printf '%s' "$_exp_c" | /system/bin/cut -c9-16 2>/dev/null)
    if [ -n "$_cur_cid8" ]; then
        if [ -n "$_exp_cid8" ] && [ "$_cur_cid8" = "$_exp_cid8" ]; then
            _items="$_items${_items:+,}{\"group\":\"属性对比\",\"key\":\"diff_chipid\",\"name\":\"芯片ID(短)\",\"state\":\"OK\",\"detail\":\"$_cur_cid8\",\"important\":1,\"scope\":\"module\"}"
            _ok=$((_ok + 1))
        else
            _items="$_items${_items:+,}{\"group\":\"属性对比\",\"key\":\"diff_chipid\",\"name\":\"芯片ID(短)\",\"state\":\"WARN\",\"detail\":\"$_cur_cid8（预期 $_exp_cid8）\",\"important\":1,\"scope\":\"module\"}"
            _warn=$((_warn + 1))
        fi
    fi

    # IMEI：探针未单独输出，用 root 读（仅作模块侧确认，标注 module 域）
    _cur_i=$(/system/bin/getprop persist.radio.imei1 2>/dev/null)
    if [ -n "$_cur_i" ]; then
        if [ -n "$_real_i" ] && [ "$_cur_i" = "$_real_i" ]; then
            _items="$_items${_items:+,}{\"group\":\"属性对比\",\"key\":\"diff_imei\",\"name\":\"IMEI\",\"state\":\"FAIL\",\"detail\":\"仍是真机值 $_cur_i\",\"important\":1,\"scope\":\"module\"}"
            _fail=$((_fail + 1))
        elif [ -n "$_exp_i" ] && [ "$_cur_i" = "$_exp_i" ]; then
            _items="$_items${_items:+,}{\"group\":\"属性对比\",\"key\":\"diff_imei\",\"name\":\"IMEI\",\"state\":\"OK\",\"detail\":\"伪装 $_cur_i\",\"important\":1,\"scope\":\"module\"}"
            _ok=$((_ok + 1))
        else
            _items="$_items${_items:+,}{\"group\":\"属性对比\",\"key\":\"diff_imei\",\"name\":\"IMEI\",\"state\":\"WARN\",\"detail\":\"$_cur_i（预期 $_exp_i）\",\"important\":1,\"scope\":\"module\"}"
            _fail=$((_fail + 1))
        fi
    else
        _skip=$((_skip + 1))
    fi

    # ADID（与属性指纹同属设备身份，归属 user0 的那一份）
    _adid=$(/system/bin/settings --user 0 get secure android_id 2>/dev/null)
    _adid_orig=""
    [ -r "$DATA_DIR/original_adid" ] && _adid_orig=$(/system/bin/grep "^0=" "$DATA_DIR/original_adid" 2>/dev/null | cut -d= -f2)
    _adid_saved=""
    if command -v ag_identity_get_kv >/dev/null 2>&1; then
        _adid_saved=$(ag_identity_get_kv ADID 2>/dev/null)
    elif [ -r "$DATA_DIR/identity" ]; then
        _adid_saved=$(/system/bin/grep "^ADID=" "$DATA_DIR/identity" 2>/dev/null | cut -d= -f2)
    fi
    if [ -n "$_adid" ]; then
        if [ -n "$_adid_orig" ] && [ "$_adid" = "$_adid_orig" ]; then
            _items="$_items${_items:+,}{\"group\":\"属性对比\",\"key\":\"diff_adid\",\"name\":\"安卓ID\",\"state\":\"FAIL\",\"detail\":\"仍是原始值 $_adid\",\"important\":1,\"scope\":\"module\"}"
            _fail=$((_fail + 1))
        elif [ -n "$_adid_saved" ] && [ "$_adid" != "$_adid_saved" ]; then
            _items="$_items${_items:+,}{\"group\":\"属性对比\",\"key\":\"diff_adid\",\"name\":\"安卓ID\",\"state\":\"WARN\",\"detail\":\"$_adid（与记录 $_adid_saved 不一致）\",\"important\":1,\"scope\":\"module\"}"
            _warn=$((_warn + 1))
        else
            _items="$_items${_items:+,}{\"group\":\"属性对比\",\"key\":\"diff_adid\",\"name\":\"安卓ID\",\"state\":\"OK\",\"detail\":\"$_adid\",\"important\":1,\"scope\":\"module\"}"
            _ok=$((_ok + 1))
        fi
    else
        _skip=$((_skip + 1))
    fi
    # IMEI9 多卡槽位泄露检测（v1.9.4 补）
    _cur_i9=$(/system/bin/getprop persist.radio.imei9 2>/dev/null)
    if [ -n "$_cur_i9" ]; then
        if [ -n "$_real_i" ] && [ "$_cur_i9" = "$_real_i" ]; then
            _items="$_items${_items:+,}{\"group\":\"属性对比\",\"key\":\"diff_imei9\",\"name\":\"IMEI9\",\"state\":\"FAIL\",\"detail\":\"仍是真机值 $_cur_i9\",\"important\":1,\"scope\":\"module\"}"
            _fail=$((_fail + 1))
        elif [ -n "$_exp_i" ] && [ "$_cur_i9" = "$_exp_i" ]; then
            _items="$_items${_items:+,}{\"group\":\"属性对比\",\"key\":\"diff_imei9\",\"name\":\"IMEI9\",\"state\":\"OK\",\"detail\":\"伪装 $_cur_i9\",\"important\":1,\"scope\":\"module\"}"
            _ok=$((_ok + 1))
        else
            _items="$_items${_items:+,}{\"group\":\"属性对比\",\"key\":\"diff_imei9\",\"name\":\"IMEI9\",\"state\":\"WARN\",\"detail\":\"$_cur_i9（预期 $_exp_i）\",\"important\":1,\"scope\":\"module\"}"
            _fail=$((_fail + 1))
        fi
    fi

    # GSM 基带序列号泄露检测（v1.9.4 补）
    _gsmv=$(/system/bin/getprop vendor.gsm.serial 2>/dev/null)
    if [ -n "$_gsmv" ]; then
        _glen=${#_gsmv}
        if [ "$_glen" -eq 21 ]; then
            _items="$_items${_items:+,}{\"group\":\"属性对比\",\"key\":\"diff_gsmserial\",\"name\":\"GSM序列号\",\"state\":\"OK\",\"detail\":\"$_gsmv\",\"important\":1,\"scope\":\"module\"}"
            _ok=$((_ok + 1))
        else
            _items="$_items${_items:+,}{\"group\":\"属性对比\",\"key\":\"diff_gsmserial\",\"name\":\"GSM序列号\",\"state\":\"WARN\",\"detail\":\"长度$_glen: $_gsmv\",\"important\":1,\"scope\":\"module\"}"
            _warn=$((_warn + 1))
        fi
    fi

    [ "$_fail" -gt 0 ] && _st="FAIL"
    _sum="正常 $_ok 项"
    [ "$_fail" -gt 0 ] && _sum="$_sum · 异常 $_fail 项"
    [ "$_skip" -gt 0 ] && _sum="$_sum · 跳过 $_skip 项"
    _items="$_items${_items:+,}{\"group\":\"属性对比\",\"key\":\"diff_summary\",\"name\":\"总结\",\"state\":\"$_st\",\"detail\":\"$_sum\",\"important\":1,\"scope\":\"app\"}"

    printf '[%s]' "$_items"
}
