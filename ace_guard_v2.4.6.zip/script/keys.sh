
# 核心程序路径
AG_CORE="${MODDIR:-/data/adb/modules/ace_guard}/lib/agcore"

# 计算签名
#   $1 = 待签内容
#   输出 16 位签名值
ag_sign_hex() {
    if [ -x "$AG_CORE" ]; then
        "$AG_CORE" sign "$1" 2>/dev/null | head -n1
        return $?
    fi
    return 1
}

# 授权码密钥占位（实际由核心程序使用，脚本不持有）
AG_KEY_LICENSE="__core__"
AG_KEY_RELEASE="__core__"

# 本地完整性密钥：每台设备独立派生，不使用固定值
#   用途：把某台设备的指纹基线抄到别的机器上无效
ag_key_local() {
    _m1=$(/system/bin/getprop ro.boot.hardware 2>/dev/null)
    _m2=$(/system/bin/getprop ro.board.platform 2>/dev/null)
    _m3=$(/system/bin/getprop ro.build.version.sdk 2>/dev/null)
    _m4=$(/system/bin/getprop ro.product.device 2>/dev/null)
    _raw="local|${_m1}|${_m2}|${_m3}|${_m4}|guard"
    _out=$(printf '%s' "$_raw" | /system/bin/toybox sha256sum 2>/dev/null | /system/bin/toybox cut -c1-40)
    if [ -n "$_out" ]; then
        printf '%s' "$_out"
    else
        printf '%s' "local-fallback-0000000000000000000000"
    fi
}

# 运行环境自检（反调试 + 自身完整性）
#   返回 0=正常  1=环境异常
#   注意：异常时不阻断用户使用，只做记录，避免误伤正常设备
ag_env_check() {
    [ -x "$AG_CORE" ] || return 0
    _r=$("$AG_CORE" check 2>/dev/null)
    [ "$_r" = "OK" ] && return 0
    return 1
}
