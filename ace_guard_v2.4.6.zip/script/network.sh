#!/system/bin/sh

# >>> AG-AUTH-GUARD >>>
# 授权闸门（性能优化版）
#   1) 同进程内复用：_AG_AUTH_GUARDED=1 直接跳过
#   2) 跨进程复用：60 秒内通过的标记文件，避免每次 source 都跑 sha256
#   3) 缓存失效才真正校验
if [ "${_AG_AUTH_GUARDED:-0}" != "1" ]; then
    _ag_gcache="/data/adb/ace_guard/auth/.guardok"
    _ag_gok=0
    if [ -f "$_ag_gcache" ]; then
        _ag_gt=$(cat "$_ag_gcache" 2>/dev/null)
        _ag_now=$(/system/bin/date +%s)
        # 60 秒内的标记视为有效
        case "$_ag_gt" in
            ''|*[!0-9]*) : ;;
            *) [ $(( _ag_now - _ag_gt )) -lt 60 ] && _ag_gok=1 ;;
        esac
    fi
    if [ "$_ag_gok" != "1" ]; then
        if [ -f "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh" ]; then
            . "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh"
            if ! ag_auth_guard "${0##*/}" 2>/dev/null; then
                echo "此设备未授权，功能已冻结" >&2
                exit 1
            fi
            /system/bin/date +%s > "$_ag_gcache" 2>/dev/null
        fi
    fi
fi
_AG_AUTH_GUARDED=1
# <<< AG-AUTH-GUARD <<<

# ---------- 清理 ----------
ag_ipt_clear() {
    /system/bin/iptables -D OUTPUT -j ACG_CYCLE 2>/dev/null
    /system/bin/iptables -D OUTPUT -j ACG_FULL 2>/dev/null
    /system/bin/iptables -F ACG_CYCLE 2>/dev/null
    /system/bin/iptables -X ACG_CYCLE 2>/dev/null
    /system/bin/iptables -F ACG_FULL 2>/dev/null
    /system/bin/iptables -X ACG_FULL 2>/dev/null
}

# ---------- 全量阻断层 ----------
ag_ipt_init() {
    [ "$ENABLE_NET_BLOCK" = "1" ] || return 0

    local uid
    uid=$(ag_find_game_pid >/dev/null 2>&1 && \
          /system/bin/stat -c %u "/proc/$(ag_find_game_pid)" 2>/dev/null)

    /system/bin/iptables -N ACG_FULL 2>/dev/null
    /system/bin/iptables -F ACG_FULL 2>/dev/null

    # 1. 报文关键词（按 UID 限定，不影响其他应用）
    if [ -n "$uid" ]; then
        local kw proto
        for kw in $BLOCK_KEYWORDS; do
            proto=tcp
            case "$kw" in
                statdata|user_report|crash_log|login-risk|serial_info|beagle|heartbeat|sample) proto=udp ;;
            esac
            /system/bin/iptables -A ACG_FULL -m owner --uid-owner "$uid" \
                -p "$proto" -m string --string "$kw" --algo bm -j DROP 2>/dev/null
        done
    fi

    # 2. 域名
    local d
    for d in $BLOCK_DOMAINS; do
        [ -z "$d" ] && continue
        /system/bin/iptables -A ACG_FULL -d "$d" -j DROP 2>/dev/null
    done

    # 3. 端口段
    local pr
    for pr in $BLOCK_PORTS; do
        [ -z "$pr" ] && continue
        /system/bin/iptables -A ACG_FULL -p tcp --dport "$pr" -j DROP 2>/dev/null
        /system/bin/iptables -A ACG_FULL -p udp --dport "$pr" -j DROP 2>/dev/null
    done

    ag_log INFO "iptables 规则已建立"
}

ag_ipt_refresh() {
    [ "$ENABLE_NET_BLOCK" = "1" ] || return 0
    /system/bin/iptables -C OUTPUT -j ACG_FULL 2>/dev/null || \
        /system/bin/iptables -I OUTPUT 1 -j ACG_FULL 2>/dev/null
}

# ---------- 循环断流：已移除 ----------
# 原本的 ag_ipt_fill_cycle / ag_ipt_cycle 已删除。
ag_ipt_cycle_cleanup() {
    local cnt
    cnt=$(/system/bin/iptables -S 2>/dev/null | /system/bin/grep -c "ACG_CYCLE")
    [ "${cnt:-0}" = "0" ] && return 0
    /system/bin/iptables -D OUTPUT -j ACG_CYCLE 2>/dev/null
    /system/bin/iptables -F ACG_CYCLE 2>/dev/null
    /system/bin/iptables -X ACG_CYCLE 2>/dev/null
    ag_log INFO "已清理残留的 ACG_CYCLE 链"
    return 0
}
