#!/system/bin/sh

AG_SC_BOOT_FLAG="$DATA_DIR/.selfcheck_boot"
AG_SC_FAIL=""

# ---------- 单项记录 ----------
# $1=级别 OK|WARN|FAIL|SKIP  $2=模块名  $3=说明
ag_sc_item() {
    local st="$1" name="$2" detail="$3"
    [ "$st" = "FAIL" ] && AG_SC_FAIL="$AG_SC_FAIL $name"
    ag_log "SC" "$st $name${detail:+ | $detail}"
    printf '%-4s %-14s %s\n' "$st" "$name" "$detail"
}

# ---------- 检查1: 指纹 ----------
ag_sc_identity() {
    local cur srv
    if [ "$ENABLE_IDENTITY" != "1" ]; then
        ag_sc_item SKIP "identity" "ENABLE_IDENTITY=0"; return 0
    fi
    ag_identity_load || { ag_sc_item FAIL "identity" "identity 文件缺失/不可读"; return 1; }

    local ok=1 msg=""
    ag_valid_serial "$AG_SERIAL" || { ok=0; msg="$msg serial非法"; }
    ag_valid_imei "$AG_IMEI" || { ok=0; msg="$msg imei非法"; }
    ag_valid_chipecid "$AG_CHIPECID" "$CHIPECID_LEN" || { ok=0; msg="$msg chipecid非法"; }
    [ "$ok" = "1" ] || { ag_sc_item FAIL "identity" "生成值不合法:$msg"; return 1; }

    # 属性是否真的应用上了（v1.9.6：ro.serialno/ro.boot.serialno 已回滚，改用厂商序列号+chipecid 判生效）
    local applied=1
    cur=$(/system/bin/getprop ro.serialno 2>/dev/null)
    srv=$(/system/bin/getprop ro.boot.serialno 2>/dev/null)
    [ "$cur" = "$AG_SERIAL" ] || applied=0
    [ "$srv" = "$AG_SERIAL" ] || applied=0
    if [ "$applied" = "1" ]; then
        ag_sc_item OK "identity" "SERIAL=$AG_SERIAL 属性已生效"
    else
        ag_sc_item FAIL "identity" "属性未生效 当前=$cur/$srv 期望=$AG_SERIAL"
        return 1
    fi

    local cc
    cc=$(/system/bin/getprop ro.boot.chipecid 2>/dev/null)
    [ "$cc" = "$AG_CHIPECID" ] || ag_log "SC" "WARN chipecid 属性=$cc 期望=$AG_CHIPECID"

    # --- chipid 一致性（v1.9.7 补：ro.boot.chipid = chipecid 后 8 位）---
    local _cid8 _chp
    _cid8=$(printf '%s' "$AG_CHIPECID" | /system/bin/cut -c9-16 2>/dev/null)
    _chp=$(/system/bin/getprop ro.boot.chipid 2>/dev/null)
    if [ -n "$_chp" ] && [ "$_chp" != "$_cid8" ]; then
        ag_sc_item FAIL "identity" "chipid 不一致 当前=$_chp 期望=$_cid8"
        return 1
    fi

    # --- IMEI 组完整性（v1.9.4 补：imei9 曾是泄露点）---
    local imei_bad=""
    for _p in $IMEI_PROPS; do
        [ -n "$_p" ] || continue
        _cur=$(/system/bin/getprop "$_p" 2>/dev/null)
        [ -n "$_cur" ] || continue
        [ "$_cur" = "$AG_IMEI" ] || imei_bad="$imei_bad $_p=$_cur"
    done
    if [ -n "$imei_bad" ]; then
        ag_sc_item FAIL "identity" "IMEI 未全部覆盖:$imei_bad"
        return 1
    fi

    # --- GSM 基带序列号泄露检测（v1.9.4 补：vendor.gsm.serial 曾是泄露点）---
    local gsm_hit=""
    for _p in $GSMSERIAL_PROPS; do
        [ -n "$_p" ] || continue
        _cur=$(/system/bin/getprop "$_p" 2>/dev/null)
        [ -n "$_cur" ] || continue
        # GSM 序列号是随机生成的，无法与固定期望比对；
        # 只检查它的长度是否符合 21 位（不是原始值则默认已覆盖）
        _len=${#_cur}
        [ "$_len" -eq 21 ] || gsm_hit="$gsm_hit $_p(长度$_len)"
    done
    if [ -n "$gsm_hit" ]; then
        ag_log "SC" "WARN GSM序列号异常:$gsm_hit"
    fi
    return 0
}

# ---------- 检查2: 风险目录遮蔽（游戏未运行时应当为 0）----------
ag_sc_shadow() {
    if [ "$ENABLE_SHADOW" != "1" ]; then
        ag_sc_item SKIP "shadow" "ENABLE_SHADOW=0"; return 0
    fi
    local base
    base=$(ag_game_dirs 2>/dev/null | /system/bin/head -1)
    [ -n "$base" ] || { ag_sc_item WARN "shadow" "未找到游戏数据目录"; return 0; }

    # 精确统计遮蔽目录挂载（v1.9.9：与锁目录分开计数）
    eval "$(ag_mount_stat 2>/dev/null | /system/bin/sed 's/^/_ms_/')"
    local sb="${_ms_shadow_bound:-0}" st="${_ms_shadow_total:-0}"
    local gpid
    gpid=$(ag_find_game_pid 2>/dev/null)

    if [ "$st" -eq 0 ]; then
        ag_sc_item WARN "shadow" "无可遮蔽目标目录（RISK_DIRS 均不存在）"
        return 0
    fi

    if [ -n "$gpid" ]; then
        # 游戏运行中：应当全部遮蔽
        if [ "$sb" -eq "$st" ]; then
            ag_sc_item OK "shadow" "游戏运行 遮蔽 $sb/$st 全部生效"
        else
            ag_sc_item FAIL "shadow" "游戏运行 但遮蔽仅 $sb/$st"
            return 1
        fi
    else
        # 闲时：不应有遮蔽挂载
        if [ "$sb" -eq 0 ]; then
            ag_sc_item OK "shadow" "无游戏 遮蔽 $sb/$st (闲时不挂载，符合设计)"
        else
            ag_sc_item FAIL "shadow" "无游戏却有 $sb/$st 条遮蔽挂载残留"
            return 1
        fi
    fi
    return 0
}

# ---------- 检查3: 守护层 LOCK_DIRS ----------
ag_sc_guard() {
    if [ "$ENABLE_GUARD" != "1" ]; then
        ag_sc_item SKIP "guard" "ENABLE_GUARD=0"; return 0
    fi
    # 精确统计锁目录挂载（v1.9.9：与遮蔽目录分开计数）
    eval "$(ag_mount_stat 2>/dev/null | /system/bin/sed 's/^/_ms_/')"
    local lb="${_ms_lock_bound:-0}" lt="${_ms_lock_total:-0}"
    local gpid
    gpid=$(ag_find_game_pid 2>/dev/null)

    if [ "$lt" -eq 0 ]; then
        ag_sc_item WARN "guard" "未找到 LOCK_DIRS 目标目录"
        return 0
    fi

    if [ -z "$gpid" ]; then
        # 闲时不应有锁目录挂载
        if [ "$lb" -eq 0 ]; then
            ag_sc_item OK "guard" "无游戏 锁目录 $lb/$lt (闲时未挂载，符合设计)"
        else
            ag_sc_item FAIL "guard" "无游戏却有 $lb/$lt 条锁目录残留挂载"
            return 1
        fi
        return 0
    fi

    if [ "$lb" -eq "$lt" ]; then
        ag_sc_item OK "guard" "游戏运行 锁目录 $lb/$lt 全部锁定"
    else
        ag_sc_item FAIL "guard" "游戏运行 锁目录仅 $lb/$lt 未全部锁定"
        return 1
    fi
    return 0
}

# ---------- 检查4: 配置伪装 ----------
# 文件必须存在且内容合法；bind 上锁只在游戏运行时才要求
ag_sc_green() {
    if [ "$ENABLE_GREEN_LOCK" != "1" ]; then
        ag_sc_item SKIP "green_lock" "ENABLE_GREEN_LOCK=0"; return 0
    fi
    local base xml gpid bound
    base=$(ag_stealth_base 2>/dev/null)
    [ -n "$base" ] || { ag_sc_item WARN "green_lock" "未找到游戏数据目录"; return 0; }
    xml="$base/shared_prefs/ace_config.xml"

    # 文件缺失：补生成（配置内容在任何时候都应存在）
    if [ ! -f "$xml" ]; then
        ag_gen_green 2>/dev/null
    fi
    [ -f "$xml" ] || { ag_sc_item FAIL "green_lock" "ace_config.xml 不存在"; return 1; }

    bound=0
    /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $xml " && bound=1
    gpid=$(ag_find_game_pid 2>/dev/null)

    if [ -z "$gpid" ]; then
        # 闲时不应挂载
        if [ "$bound" = "0" ]; then
            ag_sc_item OK "green_lock" "无游戏 已生成未挂载(符合设计)"
        else
            ag_sc_item FAIL "green_lock" "无游戏却存在残留 bind"
            return 1
        fi
        return 0
    fi
    if [ "$bound" = "1" ]; then
        ag_sc_item OK "green_lock" "已生成并上锁(bind+ro)"
        return 0
    fi
    ag_sc_item FAIL "green_lock" "游戏运行但未上锁"
    return 1
}

# ---------- 检查5: 关键属性 ----------
ag_sc_props() {
    local bad
    bad=$(ag_check_props 2>/dev/null)
    if [ -z "$bad" ]; then
        ag_sc_item OK "props" "ro.debuggable/secure/tags/vbmeta 全部正常"
        return 0
    fi
    ag_sc_item FAIL "props" "异常:$bad"
    return 1
}

# ---------- 检查6: 监控/守护后台进程存活 ----------
ag_sc_daemons() {
    # v2.0.0：基于 AG_ROLE 环境变量精确统计各进程数量
    eval "$(ag_proc_stat 2>/dev/null | /system/bin/sed 's/^/_ps_/')"
    local svc="${_ps_service:-0}" s_shadow="${_ps_shadow:-0}" s_guard="${_ps_guard:-0}"
    local s_house="${_ps_house:-0}" s_green="${_ps_green:-0}" s_prop="${_ps_prop:-0}"
    local s_mon="${_ps_monitor:-0}" s_warm="${_ps_warm:-0}" s_other="${_ps_other:-0}"

    # 预期：按开关决定各子系统是否应有
    local exp_shadow=0 exp_guard=0 exp_green=0 exp_house=1
    [ "${ENABLE_SHADOW:-1}" = "1" ] && exp_shadow=1
    [ "${ENABLE_GUARD:-1}" = "1" ]  && exp_guard=1
    [ "${ENABLE_GREEN_LOCK:-1}" = "1" ] && exp_green=1

    local total=$((svc + s_shadow + s_guard + s_house + s_green + s_prop + s_mon + s_warm + s_other))
    local detail="主进程=${svc} 遮蔽=${s_shadow} 守护=${s_guard} 配置=${s_green} 维护=${s_house} 文案=${s_prop} 监控=${s_mon}"
    [ "$s_warm" -gt 0 ] && detail="$detail 预热=${s_warm}"
    [ "$s_other" -gt 0 ] && detail="$detail 其他=${s_other}"
    detail="$detail | 共${total}个"

    # 主服务必须恰好 1 份
    if [ "$svc" -eq 0 ]; then
        ag_sc_item FAIL "daemons" "主服务未运行 | $detail"
        return 1
    fi
    if [ "$svc" -gt 1 ]; then
        ag_sc_item FAIL "daemons" "主服务重复 $svc 份(应为1) | $detail"
        return 1
    fi

    # 子系统数量与预期比对
    local bad=""
    [ "$exp_shadow" = "1" ] && [ "$s_shadow" -ne 1 ] && bad="$bad 遮蔽(应1实$s_shadow)"
    [ "$exp_guard"  = "1" ] && [ "$s_guard"  -ne 1 ] && bad="$bad 守护(应1实$s_guard)"
    [ "$exp_green"  = "1" ] && [ "$s_green"  -ne 1 ] && bad="$bad 配置(应1实$s_green)"
    [ "$exp_house"  = "1" ] && [ "$s_house"  -ne 1 ] && bad="$bad 维护(应1实$s_house)"

    if [ -n "$bad" ]; then
        ag_sc_item WARN "daemons" "数量异常:$bad | $detail"
        return 0
    fi

    ag_sc_item OK "daemons" "$detail"
    return 0
}

# ---------- 检查7: 下发扫描配置就绪 ----------
ag_sc_purge_cfg() {
    if [ "$ENABLE_PURGE_WATCH" != "1" ]; then
        ag_sc_item SKIP "purge_watch" "ENABLE_PURGE_WATCH=0"; return 0
    fi
    local np nd
    np=$(echo "$PURGE_PATTERNS" | /system/bin/toybox wc -w)
    nd=$(echo "$PURGE_DIRS" | /system/bin/toybox wc -w)
    if [ "$np" -gt 0 ] && [ "$nd" -gt 0 ]; then
        ag_sc_item OK "purge_watch" "通配=$np 条 目录=$nd 个 depth=$PURGE_MAXDEPTH"
        return 0
    fi
    ag_sc_item FAIL "purge_watch" "PURGE_PATTERNS 或 PURGE_DIRS 为空"
    return 1
}

# ---------- 检查8: 网络层 ----------
ag_sc_net() {
    # 循环断流 ACG_CYCLE 已移除，只剩全量阻断层 ACG_FULL
    if [ "$ENABLE_NET_BLOCK" != "1" ]; then
        ag_sc_item SKIP "network" "ENABLE_NET_BLOCK=0 (循环断流已移除)"
        return 0
    fi
    local n
    n=$(/system/bin/iptables -S 2>/dev/null | /system/bin/grep -c ACG_FULL)
    if [ "$n" -eq 0 ]; then
        ag_sc_item WARN "network" "全量阻断已开启但 ACG_FULL 链尚未建立"
        return 0
    fi
    ag_sc_item OK "network" "ACG_FULL 规则=$n 条"
    return 0
}

# ---------- 检查9: 依赖函数完整性 ----------
ag_sc_deps() {
    local miss="" f
    for f in ag_find_game_pid ag_find_game_dir ag_game_dirs ag_check_props \
             ag_check_purge_files ag_empty_for ag_prepare_empty ag_check_mounts \
             ag_shadow_restore ag_stealth_base ag_log ag_identity_load; do
        command -v "$f" >/dev/null 2>&1 || miss="$miss $f"
    done
    if [ -z "$miss" ]; then
        ag_sc_item OK "deps" "12 个关键函数均已定义"
        return 0
    fi
    ag_sc_item FAIL "deps" "缺失:$miss"
    return 1
}

ag_selfcheck_boot() {
    AG_SC_FAIL=""
    ag_log INFO "========== 开机自检开始 =========="
    echo "──────── 开机自检 ────────"

    ag_sc_deps
    ag_sc_identity
    ag_sc_props
    ag_sc_daemons
    ag_sc_shadow
    ag_sc_guard
    ag_sc_green
    ag_sc_purge_cfg
    ag_sc_net

    local ts total_fail
    ts=$(/system/bin/date '+%Y-%m-%d %H:%M:%S')
    if [ -z "$AG_SC_FAIL" ]; then
        ag_log INFO "开机自检通过：全部功能正常"
        printf 'time=%s result=OK\n' "$ts" > "$AG_SC_BOOT_FLAG"
    else
        total_fail=$(echo "$AG_SC_FAIL" | /system/bin/toybox wc -w)
        ag_log ALERT "开机自检发现 $total_fail 项异常:$AG_SC_FAIL"
        printf 'time=%s result=FAIL fail=%s\n' "$ts" "$AG_SC_FAIL" > "$AG_SC_BOOT_FLAG"
    fi
    ag_log INFO "========== 开机自检结束 =========="
    echo "─────────────────────────"
}

ag_selfcheck_json() {
    _sj_items=""
    _sj_add() {  # $1=key $2=state $3=msg
        [ -n "$_sj_items" ] && _sj_items="$_sj_items,"
        _sj_items="$_sj_items{\"key\":\"$1\",\"name\":\"$4\",\"state\":\"$2\",\"msg\":\"$(printf '%s' "$3" | /system/bin/sed 's/"/\\"/g')\"}"
    }
    # 复用 ag_sc_item，把每项捕获进 _sj_items
    AG_SC_FAIL=""
    ag_sc_item() {
        _sj_add "$2" "$1" "${3:-}" "$(ag_sc_cname "$2")"
        [ "$1" = "FAIL" ] && AG_SC_FAIL="$AG_SC_FAIL $2"
    }
    ag_sc_deps
    ag_sc_identity
    ag_sc_props
    ag_sc_daemons
    ag_sc_shadow
    ag_sc_guard
    ag_sc_green
    ag_sc_purge_cfg
    ag_sc_net
    printf '[%s]' "$_sj_items"
}

# 自检项中文名
ag_sc_cname() {
    case "$1" in
        deps)        echo "依赖" ;;
        identity)    echo "身份指纹" ;;
        props)       echo "关键属性" ;;
        daemons)     echo "守护进程" ;;
        shadow)      echo "目录遮蔽" ;;
        guard)       echo "锁目录" ;;
        green_lock)  echo "配置伪装" ;;
        purge_watch) echo "下发监控" ;;
        network)     echo "网络层" ;;
        *)           echo "$1" ;;
    esac
}
