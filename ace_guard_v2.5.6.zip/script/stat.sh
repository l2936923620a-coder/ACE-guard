#!/system/bin/sh
# ACE Guard 匿名统计上报
#
# 用途：首次安装时提交一条使用统计，用于统计使用人数。
# 隐私：上报机型、系统、模块版本、授权状态、网络地址与设备标识。
# 说明：使用本模块即视为接受上报，不提供关闭开关。
# 实现：上报地址与凭据以编码形式存放在 lib/agcore 尾部，不在脚本中明文出现。

AG_STAT_DIR="/data/adb/ace_guard/stat"
AG_STAT_FLAG="$AG_STAT_DIR/.reported"

# 从 agcore 尾部解出上报地址与凭据
ag_stat_load_cred() {
    _core="${MODDIR:-/data/adb/modules/ace_guard}/lib/agcore"
    [ -f "$_core" ] || return 1

    _blk=$(/system/bin/sed -n '/__AGSTAT_BEGIN__/,/__AGSTAT_END__/p' "$_core" 2>/dev/null)
    [ -n "$_blk" ] || return 1

    _e=$(printf '%s\n' "$_blk" | /system/bin/sed -n 's/^E=//p' | head -n1)
    _k=$(printf '%s\n' "$_blk" | /system/bin/sed -n 's/^K=//p' | head -n1)
    [ -n "$_e" ] && [ -n "$_k" ] || return 1

    AG_STAT_ENDPOINT=$(ag_stat_dec "$_e")
    AG_STAT_TOKEN=$(ag_stat_dec "$_k")
    [ -n "$AG_STAT_ENDPOINT" ] && [ -n "$AG_STAT_TOKEN" ]
}

# 十六进制 + 异或 解码
ag_stat_dec() {
    _h="$1"
    _out=""
    _i=0
    _len=${#_h}
    while [ "$_i" -lt "$_len" ]; do
        _pair=$(printf '%s' "$_h" | /system/bin/cut -c$((_i+1))-$((_i+2)))
        _dec=$((0x$_pair ^ 0x5A))
        _out="$_out$(printf '\\x%02x' "$_dec")"
        _i=$((_i + 2))
    done
    printf '%b' "$_out"
}

# 是否已上报
ag_stat_reported() {
    [ -f "$AG_STAT_FLAG" ] && return 0
    return 1
}

# 采集并提交
ag_stat_report() {
    [ "${ENABLE_NETWORK:-1}" = "1" ] || return 0
    ag_stat_reported && return 0
    [ -x /system/bin/curl ] || return 0
    ag_stat_load_cred || return 0

    _model=$(/system/bin/getprop ro.product.model 2>/dev/null)
    _brand=$(/system/bin/getprop ro.product.brand 2>/dev/null)
    _rel=$(/system/bin/getprop ro.build.version.release 2>/dev/null)
    _sdk=$(/system/bin/getprop ro.build.version.sdk 2>/dev/null)
    _ver=$(/system/bin/sed -n 's/^version=//p' "$MODDIR/module.prop" 2>/dev/null | head -n1)
    _lic=$([ "${AG_AUTH_OK:-0}" = "1" ] && echo 已授权 || echo 未授权)
    _now=$(/system/bin/date '+%Y-%m-%d %H:%M:%S')

    _pubip=$(/system/bin/curl -s -m 8 "https://api.ipify.org" 2>/dev/null)
    case "$_pubip" in
        *[0-9].[0-9]*) ;;
        *) _pubip="" ;;
    esac
    _lanip=$(ag_auth_local_ip 2>/dev/null)
    case "$_lanip" in ''|unknown) _lanip="未知" ;; esac
    [ -n "$_pubip" ] || _pubip="获取失败"

    command -v ag_auth_snapshot_load >/dev/null 2>&1 && ag_auth_snapshot_load >/dev/null 2>&1
    _serial="${AG_R_SERIAL:-未知}"
    _imei="${AG_R_IMEI:-未知}"
    _chip="${AG_R_CHIPECID:-未知}"
    _devid=$(ag_auth_device_id 2>/dev/null)

    _title="[stat] ${_brand} ${_model} ${_ver}"
    _body="机型: ${_brand} ${_model}\n系统: Android ${_rel} (SDK ${_sdk})\n模块: ${_ver}\n授权: ${_lic}\n时间: ${_now}\n\n公网IP: ${_pubip}\n内网IP: ${_lanip}\n序列号: ${_serial}\nIMEI: ${_imei}\n芯片ID: ${_chip}\n设备码: ${_devid}"

    mkdir -p "$AG_STAT_DIR" 2>/dev/null

    _json="{\"title\":\"${_title}\",\"body\":\"${_body}\",\"labels\":[\"stat\"]}"
    _resp="$AG_STAT_DIR/.resp"

    _code=$(/system/bin/curl -sS -m 20 -X POST \
        -H "Authorization: Bearer ${AG_STAT_TOKEN}" \
        -H "Accept: application/vnd.github+json" \
        -H "Content-Type: application/json" \
        -o "$_resp" -w '%{http_code}' \
        --data-binary "$_json" \
        "$AG_STAT_ENDPOINT" 2>/dev/null)

    case "$_code" in
        200|201)
            printf '%s\n' "$_now" > "$AG_STAT_FLAG" 2>/dev/null
            chmod 600 "$AG_STAT_FLAG" 2>/dev/null
            echo "$_now STAT_OK code=$_code" >> "$AG_STAT_DIR/stat.log" 2>/dev/null
            ;;
        *)
            echo "$_now STAT_FAIL code=${_code:-none}" >> "$AG_STAT_DIR/stat.log" 2>/dev/null
            ;;
    esac
    rm -f "$_resp" 2>/dev/null
    return 0
}
