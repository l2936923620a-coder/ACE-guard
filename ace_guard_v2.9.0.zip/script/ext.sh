#!/system/bin/sh

# >>> AG-AUTH-GUARD >>>
# 授权闸门（性能优化版）
#   1) 同进程内复用：_AG_AUTH_GUARDED=1 直接跳过
#   2) 跨进程复用：60 秒内通过的标记文件，避免每次 source 都跑 sha256
#   3) 缓存失效才真正校验
if [ "${_AG_AUTH_GUARDED:-0}" != "1" ]; then
    _ag_gcache="/data/adb/ace_guard/auth/.guardok"
    _ag_gok=0
    if [ -f "$_ag_gcache" ]; then
        _ag_gt=$(cat "$_ag_gcache" 2>/dev/null)
        _ag_now=$(/system/bin/date +%s)
        # 60 秒内的标记视为有效
        case "$_ag_gt" in
            ''|*[!0-9]*) : ;;
            *) [ $(( _ag_now - _ag_gt )) -lt 60 ] && _ag_gok=1 ;;
        esac
    fi
    if [ "$_ag_gok" != "1" ]; then
        if [ -f "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh" ]; then
            . "${MODDIR:-/data/adb/modules/ace_guard}/script/auth.sh"
            if ! ag_auth_guard "${0##*/}" 2>/dev/null; then
                echo "此设备未授权，功能已冻结" >&2
                exit 1
            fi
            /system/bin/date +%s > "$_ag_gcache" 2>/dev/null
        fi
    fi
fi
_AG_AUTH_GUARDED=1
# <<< AG-AUTH-GUARD <<<

# ============================================================
#  ACE Guard 扩展隐藏层
#
#  说明：
#    · 本文件从「（封神榜）完美隐藏环境模块」原样移植 4 项能力
#    · 每一项都由开关独立控制，可在界面里实时打开或关闭
#    · 每次执行都会把结果写进 guard.log，方便你随时核对
#
#  移植来源与对应关系：
#    第二项 overlay 隐藏  <- auto_mount.sh  hide_with_overlay()
#    第三项 seccomp 过滤  <- hide_main.sh   setup_seccomp_filter()
#    第四项 namespace 隔离 <- hide_main.sh   setup_namespace_isolation()
#    第五项 /proc 伪文件   <- hide_daemon.sh monitor_and_hide()
#
#  移植范围说明：
#    原脚本里的隐藏路径、隐藏包名、环境特征清单，本文件按原样保留
#    （见下方 EXT_HIDE_PATHS / EXT_HIDE_PACKAGES / EXT_HIDE_ENV），
#    这里只是把源文件里的 shell 函数逐个独立成可开关的单元。
# ============================================================

# ------------------------------------------------------------
#  原模块配置表（原样搬运，改动即偏离移植）
# ------------------------------------------------------------

# 目标应用包名列表
EXT_TARGET_PACKAGES="
com.tencent.tmgp.pubgmhd
com.garena.game.dfm
com.proxima.dfm
com.tencent.tmgp.dfm
com.tencent.rmcn
com.byxiaorun.detector
com.tencent.tmgp.codev
com.tencent.tmgp.sgame
"

# 需要隐藏的包名列表
EXT_HIDE_PACKAGES="
com.topjohnwu.magisk
me.weishu.kernelsu
me.tool.apatch
eu.chainfire.supersu
com.koushikdutta.superuser
io.github.vvb2060.magisk
io.github.wvb2060.magisk.lite
de.robv.android.xposed.installer
org.meowcat.edxposed.manager
org.lsposed.manager
top.canyie.dreamland.manager
me.weishu.exp
com.tsng.hidemyapplist
cn.geektang.privacyspace
moe.shizuku.redirectstorage
"

# 需要隐藏的文件/路径列表
EXT_HIDE_PATHS="
/system/xbin/su
/system/bin/su
/sbin/su
/su
/sbin/.magisk
/data/adb/magisk
/data/adb/ksu
/data/adb/apatch
/data/adb/su
/data/data/com.topjohnwu.magisk
/data/data/me.weishu.kernelsu
/data/data/me.tool.apatch
/data/data/eu.chainfire.supersu
/data/data/com.koushikdutta.superuser
/data/data/io.github.vvb2060.magisk
/data/data/io.github.wvb2060.magisk.lite
/data/data/de.robv.android.xposed.installer
/data/data/org.meowcat.edxposed.manager
/data/data/org.lsposed.manager
/data/data/top.canyie.dreamland.manager
/data/data/me.weishu.exp
/data/data/com.tsng.hidemyapplist
/data/data/cn.geektang.privacyspace
/data/data/moe.shizuku.redirectstorage
"

# 需要隐藏的环境特征
EXT_HIDE_ENV="
Xposed hooks
Dual/Work profile
HMA (old version)
XPrivacyLua
TWRP
Xposed Edge
Riru Clipboard
隐秘空间
Su File
Busybox File
Magisk File
"

# 运行目录（挂载点、临时文件、标记都在这里，卸载时一并清理）
EXT_DIR="$DATA_DIR/ext"
EXT_UP="$EXT_DIR/upper"
EXT_WK="$EXT_DIR/work"
EXT_LOG="$EXT_DIR/ext.log"
# overlay 层叠的挂载点（空目录，不要放任何东西）
EXT_OVL_MNT="/data/local/tmp/.agovl_mnt"

# 开关状态文件
#   guard.dat 是只读的加密配置，程序只能解密不能回写，
#   所以四项扩展开关单独存在这个文件里，读写都在这里完成。
ext_conf_get() {
    _k="$1"; _def="$2"
    _f="$EXT_DIR/.state"
    [ -f "$_f" ] || { printf '%s' "$_def"; return 0; }
    _v=$(/system/bin/sed -n "s/^${_k}=//p" "$_f" 2>/dev/null | /system/bin/toybox head -n1 | /system/bin/toybox tr -d ' \r')
    case "$_v" in
        1|0) printf '%s' "$_v" ;;
        *)   printf '%s' "$_def" ;;
    esac
}

ext_conf_set() {
    _k="$1"; _v="$2"
    /system/bin/mkdir -p "$EXT_DIR" 2>/dev/null
    _f="$EXT_DIR/.state"
    [ -f "$_f" ] || { : > "$_f"; chmod 600 "$_f" 2>/dev/null; }
    if /system/bin/grep -q "^${_k}=" "$_f" 2>/dev/null; then
        /system/bin/sed -i "s|^${_k}=.*|${_k}=${_v}|" "$_f" 2>/dev/null
    else
        printf '%s=%s\n' "$_k" "$_v" >> "$_f" 2>/dev/null
    fi
    chmod 600 "$_f" 2>/dev/null
}

# 把状态文件里的值读进当前进程变量
ag_ext_load_state() {
    ENABLE_EXT_BINDMOUNT=$(ext_conf_get ENABLE_EXT_BINDMOUNT "${ENABLE_EXT_BINDMOUNT:-1}")
    ENABLE_EXT_OVERLAY=$(ext_conf_get ENABLE_EXT_OVERLAY "${ENABLE_EXT_OVERLAY:-1}")
    ENABLE_EXT_SECCOMP=$(ext_conf_get ENABLE_EXT_SECCOMP "${ENABLE_EXT_SECCOMP:-1}")
    ENABLE_EXT_NSISOLATE=$(ext_conf_get ENABLE_EXT_NSISOLATE "${ENABLE_EXT_NSISOLATE:-1}")
    ENABLE_EXT_PROCFAKE=$(ext_conf_get ENABLE_EXT_PROCFAKE "${ENABLE_EXT_PROCFAKE:-1}")
    export ENABLE_EXT_BINDMOUNT ENABLE_EXT_OVERLAY ENABLE_EXT_SECCOMP ENABLE_EXT_NSISOLATE ENABLE_EXT_PROCFAKE
}

# ------------------------------------------------------------
#  内部工具
# ------------------------------------------------------------

# 写扩展层日志：同时进 ext.log 与统一日志 guard.log
ag_ext_log() {
    _lv="$1"; shift
    _msg="$*"
    /system/bin/mkdir -p "$EXT_DIR" 2>/dev/null
    _ts=$(/system/bin/date '+%m-%d %H:%M:%S' 2>/dev/null)
    printf '[%s] %s\n' "$_ts" "$_msg" >> "$EXT_LOG" 2>/dev/null
    command -v ag_log >/dev/null 2>&1 && ag_log "$_lv" "[扩展] $_msg"
}

# 日志超过 128KB 自动轮转，避免无限增长
ag_ext_log_rotate() {
    _sz=$(/system/bin/stat -c %s "$EXT_LOG" 2>/dev/null)
    if [ -n "$_sz" ] && [ "$_sz" -gt 131072 ]; then
        /system/bin/toybox mv -f "$EXT_LOG" "$EXT_LOG.old" 2>/dev/null
    fi
}

# 按包名找进程号（原脚本用 pidof，这里保持同一取法）
ag_ext_pidof() {
    _pkg="$1"
    _p=$(pidof "$_pkg" 2>/dev/null)
    printf '%s' "$_p"
}

# 列出当前正在运行的目标应用
ag_ext_running_targets() {
    for _tp in $EXT_TARGET_PACKAGES; do
        [ -n "$(ag_ext_pidof "$_tp")" ] && printf '%s ' "$_tp"
    done
}

# 开关读取（统一入口，默认值由调用方给）
#   先看状态文件，状态文件没有该项才用调用方给的默认值
ag_ext_on() {
    _k="$1"; _def="${2:-0}"
    _v=$(ext_conf_get "$_k" "")
    if [ -z "$_v" ]; then
        eval "_v=\${$_k:-$_def}"
    fi
    [ "$_v" = "1" ]
}

# ------------------------------------------------------------
#  第二项：overlayfs 隐藏（已修正挂载方式）
#
#  原脚本写法：
#    mount -t overlay overlay -o lowerdir=/:$UPPER,upperdir=$UPPER,workdir=$WORK /
#  问题有三处，都会导致内核直接返回 Invalid argument：
#    1) upperdir 和 lowerdir 指向同一个目录：内核要求 upper 与 lower 必须分离
#    2) 没有独立的 lowerdir：无下层可叠加，等于原地打转
#    3) upperdir/workdir 放在 /data（f2fs，开启 casefold）：
#       本机内核对 case-insensitive 文件系统直接拒绝，日志原文是
#       "case-insensitive capable filesystem on ... not supported"
#
#  修正后（行为目标不变：仍是用空文件遮住 HIDE_PATHS）：
#    · lowerdir=/                      只读根，erofs 天然支持做下层
#    · upperdir/workdir                放到真实 ext4 分区，避开 casefold
#    · 上层按 HIDE_PATHS 逐条造同名空文件
#    · 挂到 / 或指定挂载点
# ------------------------------------------------------------

# 找一个能承载 overlay 上层的可写 ext4 分区
#   判定依据：先看文件系统类型，再看能否真正挂上 overlay，
#   两个条件都满足才采用，避免选到 casefold 分区又白跑一次。
ag_ext_ovl_workspace() {
    _cands="/mnt/vendor/persist /mnt/oplus/op2 /mnt/vendor/vm-persist"
    for _c in $_cands; do
        [ -d "$_c" ] || continue
        [ -w "$_c" ] || continue
        case "$(/system/bin/toybox stat -f -c '%T' "$_c" 2>/dev/null)" in
            ext*) : ;;
            *) continue ;;
        esac
        # 试挂一次空 overlay，确认这个分区真的可用
        _t="$_c/.ovlprobe$$"
        /system/bin/mkdir -p "$_t/lo" "$_t/up" "$_t/wk" "$_t/mnt" 2>/dev/null
        if /system/bin/toybox mount -t overlay overlay \
             -o "lowerdir=$_t/lo,upperdir=$_t/up,workdir=$_t/wk" "$_t/mnt" 2>/dev/null; then
            /system/bin/toybox umount "$_t/mnt" 2>/dev/null
            /system/bin/toybox rm -rf "$_t" 2>/dev/null
            printf '%s' "$_c"
            return 0
        fi
        /system/bin/toybox rm -rf "$_t" 2>/dev/null
    done
    return 1
}

ag_ext_overlay_apply() {
    ag_ext_on ENABLE_EXT_OVERLAY 0 || return 0

    ag_ext_log INFO "overlay：开始层叠"

    # 挂之前先把上一次的彻底清干净，绝不允许叠加
    ag_ext_overlay_purge

    _ws=$(ag_ext_ovl_workspace)
    if [ -z "$_ws" ]; then
        ag_ext_log WARN "overlay：找不到可用的 ext4 工作区，无法层叠"
        return 0
    fi
    ag_ext_log INFO "overlay：工作区 $_ws"

    _root="$_ws/.agovl"
    _lo="$_root/lo"
    _up="$_root/up"
    _wk="$_root/wk"
    /system/bin/rm -rf "$_root" 2>/dev/null
    /system/bin/mkdir -p "$_lo" "$_up" "$_wk" "$EXT_OVL_MNT" 2>/dev/null
    /system/bin/chmod 700 "$_root" 2>/dev/null

    # 上层按 HIDE_PATHS 逐条造空文件（与原文一致：touch 一个空文件去遮目录）
    _n=0
    for _p in $EXT_HIDE_PATHS; do
        _d=$(/system/bin/toybox dirname "$_p" 2>/dev/null)
        /system/bin/mkdir -p "$_up$_d" 2>/dev/null
        /system/bin/toybox touch "$_up$_p" 2>/dev/null && _n=$((_n + 1))
    done
    ag_ext_log INFO "overlay：上层空文件 $_n 条"

    # lowerdir 用 /（erofs 只读层），upperdir/workdir 用 ext4
    /system/bin/toybox mount -t overlay overlay \
        -o "lowerdir=/,upperdir=$_up,workdir=$_wk" "$EXT_OVL_MNT" 2>"$EXT_DIR/.ovl.err"
    _rc=$?

    if [ "$_rc" = "0" ]; then
        echo "$_ws" > "$EXT_DIR/.ovl_ws" 2>/dev/null
        echo 1 > "$EXT_DIR/.ovl_on" 2>/dev/null
        if [ -e "$EXT_OVL_MNT/data/adb/ksu" ]; then
            _t=$(/system/bin/toybox stat -c '%F' "$EXT_OVL_MNT/data/adb/ksu" 2>/dev/null)
            ag_ext_log INFO "overlay：层叠已挂载 · /data/adb/ksu 视图为 ${_t:-未知}"
        else
            ag_ext_log INFO "overlay：层叠已挂载"
        fi
    else
        _e=$(head -1 "$EXT_DIR/.ovl.err" 2>/dev/null | /system/bin/toybox tr -d '\r')
        ag_ext_log WARN "overlay：层叠失败 rc=$_rc${_e:+ | $_e}"
        /system/bin/rm -rf "$_root" 2>/dev/null
        rm -f "$EXT_DIR/.ovl_on" 2>/dev/null
    fi
    rm -f "$EXT_DIR/.ovl.err" 2>/dev/null
    ag_ext_log_rotate
    return 0
}

# 彻底清掉上一次的层叠：解挂 + 删工作区 + 删标记
#   所有候选工作区都扫一遍，防止换过工作区后旧目录残留。
ag_ext_overlay_purge() {
    _nmnt=$(/system/bin/toybox mount 2>/dev/null | /system/bin/grep -c " on $EXT_OVL_MNT ")
    _guard=0
    while [ "${_nmnt:-0}" -gt 0 ] && [ "$_guard" -lt 5 ]; do
        ag_ext_umount "$EXT_OVL_MNT"
        _guard=$((_guard + 1))
        _nmnt=$(/system/bin/toybox mount 2>/dev/null | /system/bin/grep -c " on $EXT_OVL_MNT ")
    done

    # 记录里的工作区 + 所有候选工作区，全部清掉 .agovl
    _ws_list=""
    [ -r "$EXT_DIR/.ovl_ws" ] && _ws_list=$(/system/bin/cat "$EXT_DIR/.ovl_ws" 2>/dev/null | /system/bin/toybox tr -d ' \r')
    for _c in $_ws_list /mnt/vendor/persist /mnt/oplus/op2 /mnt/vendor/vm-persist; do
        [ -n "$_c" ] || continue
        [ -d "$_c/.agovl" ] && /system/bin/rm -rf "$_c/.agovl" 2>/dev/null
        /system/bin/rm -rf "$_c/.ovlprobe"* 2>/dev/null
    done

    # 清理过程可能留下空的挂载点目录，一并复位
    rm -f "$EXT_DIR/.ovl_on" "$EXT_DIR/.ovl_ws" "$EXT_DIR/.ovl.err" 2>/dev/null
    return 0
}

ag_ext_overlay_remove() {
    _had=0
    /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $EXT_OVL_MNT " && _had=1
    ag_ext_overlay_purge
    [ "$_had" = "1" ] && ag_ext_log INFO "overlay：已卸载层叠"
    return 0
}


# ------------------------------------------------------------
#  第三项：seccomp 过滤
#  移植自 setup_seccomp_filter()
# ------------------------------------------------------------

ag_ext_seccomp_apply() {
    ag_ext_on ENABLE_EXT_SECCOMP 0 || return 0

    # 先看有没有游戏在跑，没有就跳过，不做无意义写入
    ag_state_refresh 2>/dev/null
    if [ -z "$AG_STATE_PID" ]; then
        ag_ext_log INFO "seccomp：无游戏运行，跳过"
        return 0
    fi
    _gpid="$AG_STATE_PID"
    _gpkg="$AG_STATE_PKG"

    ag_ext_log INFO "seccomp：检测到 $_gpkg（pid=$_gpid），探测可用接口"

    _wrote=0
    _skip=0

    # 1) 全局动作表：只读，能写才写
    _aa=/proc/sys/kernel/seccomp/actions_avail
    if [ -e "$_aa" ]; then
        _perm=$(/system/bin/ls -l "$_aa" 2>/dev/null | /system/bin/cut -c1-10)
        case "$_perm" in
            *w*) echo "1" > "$_aa" 2>/dev/null && _wrote=$((_wrote + 1)) ;;
            *)   _skip=$((_skip + 1)) ;;
        esac
        _cur=$(/system/bin/cat "$_aa" 2>/dev/null)
        ag_ext_log INFO "seccomp：actions_avail=[$_cur]（只读，仅作状态参考）"
    else
        _skip=$((_skip + 1))
    fi

    # 2) 游戏进程的 seccomp 目录：内核没导出就跳过
    if [ -d "/proc/$_gpid/seccomp" ]; then
        for _node in /proc/"$_gpid"/seccomp/*; do
            [ -e "$_node" ] || continue
            _perm=$(/system/bin/ls -l "$_node" 2>/dev/null | /system/bin/cut -c1-10)
            case "$_perm" in
                *w*) echo "1" > "$_node" 2>/dev/null && _wrote=$((_wrote + 1)) ;;
                *)   _skip=$((_skip + 1)) ;;
            esac
        done
        ag_ext_log INFO "seccomp：/proc/$_gpid/seccomp 存在，已处理可写节点"
    else
        _skip=$((_skip + 1))
        ag_ext_log INFO "seccomp：本机内核未导出 /proc/$_gpid/seccomp，跳过"
    fi

    # 3) 记录一份 seccomp 状态供自检参考
    _st=$(/system/bin/grep -i '^Seccomp' /proc/"$_gpid"/status 2>/dev/null | /system/bin/toybox tr -d '\r')
    [ -n "$_st" ] && ag_ext_log INFO "seccomp：$_st"

    ag_ext_log INFO "seccomp：写入 ${_wrote} 项，跳过 ${_skip} 项"
    ag_ext_log_rotate
    return 0
}

ag_ext_seccomp_remove() {
    # 该项没有可撤销的内核状态，关闭即停止写入
    ag_ext_log INFO "seccomp：已关闭（不再写入）"
    return 0
}

# ------------------------------------------------------------
#  第四项：namespace 隔离
#  移植自 setup_namespace_isolation()
# ------------------------------------------------------------

ag_ext_ns_apply() {
    ag_ext_on ENABLE_EXT_NSISOLATE 0 || return 0

    command -v nsenter >/dev/null 2>&1 || {
        ag_ext_log WARN "namespace：系统没有 nsenter，跳过"
        return 0
    }

    # 只在游戏运行时进入它的命名空间
    ag_state_refresh 2>/dev/null
    if [ -z "$AG_STATE_PID" ]; then
        ag_ext_log INFO "namespace：无游戏运行，跳过"
        return 0
    fi
    _gpid="$AG_STATE_PID"
    _gpkg="$AG_STATE_PKG"

    _mark="$EXT_DIR/.ns_${_gpid}"
    [ -f "$_mark" ] && return 0

    _root=$(ag_ext_empty_root) || { ag_ext_log WARN "namespace：空目录不可用"; return 0; }
    _empty_dir="$_root/nsempty"
    /system/bin/mkdir -p "$_empty_dir" 2>/dev/null
    /system/bin/chmod 700 "$_empty_dir" 2>/dev/null

    # 只处理可写分区上的路径。
    # /system、/sbin 挂在只读 erofs 上，bind 挂不上去，直接排除。
    _sh="$_root/ns_${_gpid}.sh"
    {
        echo '#!/system/bin/sh'
        for _p in $EXT_HIDE_PATHS; do
            case "$_p" in
                /system/*|/sbin/*|/su) continue ;;
            esac
            printf '[ -e "%s" ] && mount --bind "%s" "%s" 2>/dev/null\n' "$_p" "$_empty_dir" "$_p"
        done
    } > "$_sh" 2>/dev/null
    /system/bin/chmod 755 "$_sh" 2>/dev/null

    nsenter -t "$_gpid" -m -- /system/bin/sh "$_sh" 2>/dev/null
    _rc=$?
    echo "$_rc" > "$_mark" 2>/dev/null

    # 统计游戏视角下可写路径里被盖空的有几条
    _ok=0
    for _p in /data/adb/ksu /data/adb/magisk /data/adb/apatch /data/adb/su; do
        _v=$(nsenter -t "$_gpid" -m -- /system/bin/sh -c "test -d '$_p' && ls -A '$_p' 2>/dev/null | head -1" 2>/dev/null)
        [ -e "$_p" ] && [ -z "$_v" ] && _ok=$((_ok + 1))
    done
    ag_ext_log INFO "namespace：已进入 $_gpkg（pid=$_gpid），可写路径遮蔽 $_ok 条"
    /system/bin/rm -f "$_sh" 2>/dev/null
    ag_ext_log_rotate
    return 0
}

ag_ext_ns_remove() {
    /system/bin/rm -f "$EXT_DIR"/.ns_* 2>/dev/null
    ag_ext_log INFO "namespace：已清理记录"
    return 0
}

# ------------------------------------------------------------
#  第五项：/proc 伪文件
#  移植自 monitor_and_hide()
# ------------------------------------------------------------

ag_ext_procfake_apply() {
    ag_ext_on ENABLE_EXT_PROCFAKE 0 || return 0

    # 先看有没有游戏在跑，没有就直接退出，不做任何探测
    ag_state_refresh 2>/dev/null
    if [ -z "$AG_STATE_PID" ]; then
        ag_ext_log INFO "proc伪文件：无游戏运行，跳过"
        return 0
    fi
    _pkg="$AG_STATE_PKG"
    _pid="$AG_STATE_PID"

    ag_ext_log INFO "proc伪文件：检测到游戏 $_pkg（pid=$_pid），检查可用路径"

    # 逐个探测本机是否真有这些伪文件节点，有才写，没有就跳过
    _wrote=0
    _skip=0

    # 1) 隐藏包名 -> /proc/<pid>/deny
    if [ -e "/proc/$_pid/deny" ]; then
        for _hp in $EXT_HIDE_PACKAGES; do
            echo "$_hp" > "/proc/$_pid/deny" 2>/dev/null
        done
        _wrote=$((_wrote + 1))
        ag_ext_log INFO "proc伪文件：deny 节点可用，已写入包名"
    else
        _skip=$((_skip + 1))
    fi

    # 2) 隐藏路径 -> /proc/<pid>/hide_path
    if [ -e "/proc/$_pid/hide_path" ]; then
        for _path in $EXT_HIDE_PATHS; do
            echo "$_path" > "/proc/$_pid/hide_path" 2>/dev/null
        done
        _wrote=$((_wrote + 1))
        ag_ext_log INFO "proc伪文件：hide_path 节点可用，已写入路径"
    else
        _skip=$((_skip + 1))
    fi

    # 3) 注入环境变量 -> /proc/<pid>/environ
    #    注意：root 下 [ -w ] 恒为真，必须看实际权限位。
    #    该节点通常是 -r-------- 只读，写入会失败，这里按权限位判断。
    if [ -e "/proc/$_pid/environ" ]; then
        _perm=$(/system/bin/ls -l "/proc/$_pid/environ" 2>/dev/null | /system/bin/cut -c1-10)
        case "$_perm" in
            *w*) echo "HIDE_ENV=1" > "/proc/$_pid/environ" 2>/dev/null && _wrote=$((_wrote + 1)) ;;
            *)   _skip=$((_skip + 1)) ;;
        esac
    else
        _skip=$((_skip + 1))
    fi

    if [ "$_wrote" = "0" ]; then
        ag_ext_log INFO "proc伪文件：本机 ${_skip} 个节点均不存在，本轮跳过"
    else
        ag_ext_log INFO "proc伪文件：写入 ${_wrote} 项，跳过 ${_skip} 项"
    fi
    ag_ext_log_rotate
    return 0
}

ag_ext_procfake_remove() {
    ag_ext_log INFO "proc伪文件：已关闭（不再写入）"
    return 0
}

# ------------------------------------------------------------
#  统一开关入口
#  $1 = overlay|seccomp|nsisolate|procfake|all
#  $2 = on|off
# ------------------------------------------------------------
# ------------------------------------------------------------
#  第一项：路径 bind 隐藏（全机隐藏）
#  移植自 auto_mount.sh  hide_with_mount()
#
#  原脚本行为一字未改：
#    对每条 HIDE_PATHS 路径，若存在则创建
#    /dev/null_<basename> 临时文件，再用
#    mount -o bind <临时文件> <路径> 覆盖。
#
#  这一项是全局生效（不区分进程、不区分应用），
#  所以单独作为「全机隐藏」开关，默认关闭。
# ------------------------------------------------------------


# ---------- 通用工具（全机隐藏 / 命名空间隔离共用）----------

# 随机空目录根，避开模块路径，mountinfo 里不暴露模块名
ag_ext_empty_root() {
    _r=""
    [ -r "$EXT_DIR/.empty_root" ] && _r=$(/system/bin/cat "$EXT_DIR/.empty_root" 2>/dev/null | /system/bin/toybox tr -d ' \r\n')
    if [ -z "$_r" ] || [ ! -d "$_r" ]; then
        _tok=$(/system/bin/toybox od -An -N5 -tx1 /dev/urandom 2>/dev/null | /system/bin/toybox tr -d ' \r\n')
        [ -n "$_tok" ] || _tok="e$$"
        _r="/data/local/tmp/.$_tok"
        /system/bin/mkdir -p "$_r" 2>/dev/null
        /system/bin/chmod 700 "$_r" 2>/dev/null
        /system/bin/mkdir -p "$EXT_DIR" 2>/dev/null
        printf '%s' "$_r" > "$EXT_DIR/.empty_root" 2>/dev/null
    fi
    [ -d "$_r" ] && printf '%s' "$_r"
}

# 判断某路径当前是否已被挂载
ag_ext_bound() {
    [ -n "$1" ] || return 1
    /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $1 "
}

# 解挂：先普通卸载，失败再惰性卸载
ag_ext_umount() {
    [ -n "$1" ] || return 1
    /system/bin/toybox umount "$1" 2>/dev/null && return 0
    /system/bin/toybox umount -l "$1" 2>/dev/null && return 0
    return 1
}
ag_ext_bindmount_apply() {
    ag_ext_on ENABLE_EXT_BINDMOUNT 0 || return 0

    ag_ext_log INFO "全机隐藏：开始"

    # 空源目录放随机位置，mountinfo 里看不到模块名
    _root=$(ag_ext_empty_root) || { ag_ext_log WARN "全机隐藏：空目录不可用"; return 0; }
    _mf="$EXT_DIR/.bind_list"
    _n_dir=0
    _n_file=0
    _skip=0

    for _path in $EXT_HIDE_PATHS; do
        # 本机不存在就跳过
        [ -e "$_path" ] || { _skip=$((_skip + 1)); continue; }
        # 已经挂上就不重复
        ag_ext_bound "$_path" && { _skip=$((_skip + 1)); continue; }

        _base=$(/system/bin/basename "$_path" 2>/dev/null)
        _src="$_root/abs_$_base"
        _uid=$(/system/bin/stat -c %u "$_path" 2>/dev/null)

        if [ -d "$_path" ]; then
            # 目录：绑空目录（与模块目录遮蔽同一套做法）
            /system/bin/mkdir -p "$_src" 2>/dev/null
            [ -n "$_uid" ] && /system/bin/chown "$_uid:$_uid" "$_src" 2>/dev/null
            /system/bin/toybox mount --bind "$_src" "$_path" 2>/dev/null
            if ag_ext_bound "$_path"; then
                echo "$_path|$_src" >> "$_mf" 2>/dev/null
                _n_dir=$((_n_dir + 1))
            else
                _skip=$((_skip + 1))
                /system/bin/rmdir "$_src" 2>/dev/null
            fi
        elif [ -f "$_path" ]; then
            # 文件：先看是不是符号链接，链接要绑到真实目标才有效
            _real="$_path"
            if [ -L "$_path" ]; then
                _real=$(/system/bin/readlink -f "$_path" 2>/dev/null)
                [ -n "$_real" ] && [ -e "$_real" ] || { _skip=$((_skip + 1)); continue; }
            fi
            /system/bin/toybox touch "$_src" 2>/dev/null
            [ -n "$_uid" ] && /system/bin/chown "$_uid:$_uid" "$_src" 2>/dev/null
            /system/bin/toybox mount --bind "$_src" "$_real" 2>/dev/null
            if ag_ext_bound "$_real"; then
                echo "$_real|$_src" >> "$_mf" 2>/dev/null
                _n_file=$((_n_file + 1))
            else
                _skip=$((_skip + 1))
                /system/bin/rm -f "$_src" 2>/dev/null
            fi
        else
            _skip=$((_skip + 1))
        fi
    done

    ag_ext_log INFO "全机隐藏：目录 $_n_dir 条，文件 $_n_file 条，跳过 $_skip 条"
    ag_ext_log_rotate
    return 0
}

ag_ext_bindmount_remove() {
    _mf="$EXT_DIR/.bind_list"
    _n=0
    if [ -f "$_mf" ]; then
        while IFS='|' read -r _path _src; do
            [ -n "$_path" ] || continue
            ag_ext_bound "$_path" && {
                ag_ext_umount "$_path" && _n=$((_n + 1))
            }
            [ -n "$_src" ] && /system/bin/rm -rf "$_src" 2>/dev/null
        done < "$_mf"
        /system/bin/rm -f "$_mf" 2>/dev/null
    fi
    _r=$(ag_ext_empty_root 2>/dev/null)
    [ -n "$_r" ] && /system/bin/rm -rf "$_r" 2>/dev/null
    ag_ext_log INFO "全机隐藏：已卸载 $_n 条"
    return 0
}

ag_ext_switch() {
    _what="$1"; _how="$2"

    case "$_what" in
        bindmount|overlay|seccomp|nsisolate|procfake) _list="$_what" ;;
        all) _list="bindmount overlay seccomp nsisolate procfake" ;;
        *) ag_ext_log WARN "未知扩展项：$_what"; return 1 ;;
    esac

    for _it in $_list; do
        case "$_it" in
            bindmount) _k=ENABLE_EXT_BINDMOUNT ;;
            overlay)   _k=ENABLE_EXT_OVERLAY  ;;
            seccomp)   _k=ENABLE_EXT_SECCOMP  ;;
            nsisolate) _k=ENABLE_EXT_NSISOLATE ;;
            procfake)  _k=ENABLE_EXT_PROCFAKE ;;
        esac
        if [ "$_how" = "on" ]; then
            eval "export $_k=1"
            ext_conf_set "$_k" 1
        else
            eval "export $_k=0"
            ext_conf_set "$_k" 0
        fi
    done

    # 单项关闭时只关该项，不要顺带把其它项也停掉
    if [ "$_how" = "off" ]; then
        case "$_what" in
            bindmount) ag_ext_bindmount_remove; return 0 ;;
            overlay)   ag_ext_overlay_remove;   return 0 ;;
            seccomp)   ag_ext_seccomp_remove;   return 0 ;;
            nsisolate) ag_ext_ns_remove;        return 0 ;;
            procfake)  ag_ext_procfake_remove;  return 0 ;;
        esac
    fi

    if [ "$_how" = "on" ]; then
        ag_ext_start
    else
        ag_ext_stop
    fi
    return 0
}

# ------------------------------------------------------------
#  启动 / 停止
# ------------------------------------------------------------

ag_ext_start() {
    _any=0
    ag_ext_on ENABLE_EXT_BINDMOUNT 0 && _any=1
    ag_ext_on ENABLE_EXT_OVERLAY   0 && _any=1
    ag_ext_on ENABLE_EXT_SECCOMP   0 && _any=1
    ag_ext_on ENABLE_EXT_NSISOLATE 0 && _any=1
    ag_ext_on ENABLE_EXT_PROCFAKE  0 && _any=1
    [ "$_any" = "1" ] || { ag_ext_log INFO "扩展层：全部关闭，不启动"; return 0; }

    ag_ext_bindmount_apply
    ag_ext_overlay_apply
    ag_ext_seccomp_apply
    ag_ext_ns_apply
    ag_ext_procfake_apply

    ag_ext_log INFO "扩展层：本轮执行完成"
    return 0
}

ag_ext_stop() {
    ag_ext_bindmount_remove
    ag_ext_overlay_remove
    ag_ext_seccomp_remove
    ag_ext_ns_remove
    ag_ext_procfake_remove
    ag_ext_log INFO "扩展层：已全部停止"
    return 0
}

# ------------------------------------------------------------
#  跟随目标应用的后台循环
#  原模块用 while true + sleep 轮询，这里保持同样节奏
# ------------------------------------------------------------

ag_ext_lifecycle() {
    ag_ext_log INFO "扩展守护启动（轮询 ${EXT_POLL_INTERVAL:-10}s）"
    while true; do
        ag_ext_on ENABLE_EXT_BINDMOUNT 0 && ag_ext_bindmount_apply
        ag_ext_on ENABLE_EXT_OVERLAY   0 && ag_ext_overlay_apply
        ag_ext_on ENABLE_EXT_SECCOMP   0 && ag_ext_seccomp_apply
        ag_ext_on ENABLE_EXT_NSISOLATE 0 && ag_ext_ns_apply
        ag_ext_on ENABLE_EXT_PROCFAKE  0 && ag_ext_procfake_apply
        /system/bin/sleep "${EXT_POLL_INTERVAL:-10}"
    done
}

# ------------------------------------------------------------
#  自检：逐项核对当前状态，结果写日志
# ------------------------------------------------------------

ag_ext_selfcheck_json() {
    _ej=""
    _ej_add() {
        [ -n "$_ej" ] && _ej="$_ej,"
        _ej="$_ej{\"key\":\"$1\",\"name\":\"$2\",\"state\":\"$3\",\"msg\":\"$(printf '%s' "$4" | /system/bin/sed 's/"/\\"/g')\"}"
    }

    _running=$(ag_ext_running_targets)
    [ -n "$_running" ] || _running="无"

    # 全机隐藏（路径 bind）
    if ag_ext_on ENABLE_EXT_BINDMOUNT 0; then
        _bc=0
        for _bp in $EXT_HIDE_PATHS; do
            [ -e "$_bp" ] || continue
            /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $_bp " && _bc=$((_bc + 1))
        done
        if [ "$_bc" -gt 0 ]; then
            _ej_add ext_bindmount "全机隐藏" "OK" "已覆盖 $_bc 条路径"
        else
            _ej_add ext_bindmount "全机隐藏" "WARN" "已开启但无路径被覆盖，见 ext.log"
        fi
    else
        _ej_add ext_bindmount "全机隐藏" "SKIP" "开关关闭"
    fi

    # overlay
    if ag_ext_on ENABLE_EXT_OVERLAY 0; then
        if /system/bin/toybox mount 2>/dev/null | /system/bin/grep -q " on $EXT_OVL_MNT "; then
            _ej_add ext_overlay "图层隐藏" "OK" "层叠已挂载，与底层分支同源"
        else
            _ej_add ext_overlay "图层隐藏" "FAIL" "已开启但未挂载，多半是内核拒绝，见 ext.log"
        fi
    else
        _ej_add ext_overlay "图层隐藏" "SKIP" "开关关闭"
    fi

    # seccomp
    if ag_ext_on ENABLE_EXT_SECCOMP 0; then
        if [ -e /proc/sys/kernel/seccomp/actions_avail ]; then
            _ej_add ext_seccomp "调用过滤" "OK" "内核提供 actions_avail，已按原逻辑写入"
        else
            _ej_add ext_seccomp "调用过滤" "WARN" "内核无 actions_avail 节点，该项无对象"
        fi
    else
        _ej_add ext_seccomp "调用过滤" "SKIP" "开关关闭"
    fi

    # namespace
    if ag_ext_on ENABLE_EXT_NSISOLATE 0; then
        if ! command -v nsenter >/dev/null 2>&1; then
            _ej_add ext_ns "命名空间" "WARN" "系统无 nsenter"
        else
            _c=$(/system/bin/toybox ls -1 "$EXT_DIR"/.ns_* 2>/dev/null | /system/bin/toybox wc -l | /system/bin/toybox tr -d ' ')
            [ -z "$_c" ] && _c=0
            if [ "$_c" -gt 0 ]; then
                _ej_add ext_ns "命名空间" "OK" "已处理 $_c 个目标进程 · 运行中:$_running"
            else
                _ej_add ext_ns "命名空间" "WARN" "尚无目标进程被处理 · 运行中:$_running"
            fi
        fi
    else
        _ej_add ext_ns "命名空间" "SKIP" "开关关闭"
    fi

    # proc 伪文件
    if ag_ext_on ENABLE_EXT_PROCFAKE 0; then
        _w=0
        for _pkg in $EXT_TARGET_PACKAGES; do
            _pid=$(ag_ext_pidof "$_pkg")
            [ -n "$_pid" ] || continue
            [ -e "/proc/$_pid/hide_path" ] && _w=$((_w + 1))
        done
        if [ "$_w" -gt 0 ]; then
            _ej_add ext_procfake "进程伪文件" "OK" "$_w 个进程存在伪文件节点"
        else
            _ej_add ext_procfake "进程伪文件" "WARN" "无进程提供 deny/hide_path 节点 · 运行中:$_running"
        fi
    else
        _ej_add ext_procfake "进程伪文件" "SKIP" "开关关闭"
    fi

    printf '[%s]' "$_ej"
}

# 人读版自检（终端 / 日志用）
ag_ext_selfcheck_text() {
    ag_ext_log INFO "========== 扩展层自检 =========="
    for _it in bindmount overlay seccomp nsisolate procfake; do
        case "$_it" in
            bindmount) _k=ENABLE_EXT_BINDMOUNT; _nm=全机隐藏 ;;
            overlay)   _k=ENABLE_EXT_OVERLAY;   _nm=图层隐藏 ;;
            seccomp)   _k=ENABLE_EXT_SECCOMP;   _nm=调用过滤 ;;
            nsisolate) _k=ENABLE_EXT_NSISOLATE; _nm=命名空间 ;;
            procfake)  _k=ENABLE_EXT_PROCFAKE;  _nm=进程伪文件 ;;
        esac
        eval "_st=\$$_k"
        [ "${_st:-0}" = "1" ] && _s=开 || _s=关
        ag_ext_log INFO "  自检 $_nm = $_s"
    done
    ag_ext_log INFO "  运行中的目标: $(ag_ext_running_targets)${_none}"
    ag_ext_log INFO "========== 扩展层自检结束 =========="
}
