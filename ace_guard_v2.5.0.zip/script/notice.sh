#!/system/bin/sh
# ============================================================
#  ACE Guard 远程更新服务
#
#  作用：
#    定期检查是否有新版本，并在需要时提示用户更新。
#    更新信息由作者发布，模块自动获取，无需手动查找。
#
#  对用户的行为：
#    · 有新版本时，模块卡片会显示更新提示
#    · 打开模块界面可以看到更新内容并下载安装包
#    · 网络异常时沿用上一次的结果，不会误报
#    · 更新完成并重启后，功能自动恢复
#
#  说明：
#    本模块只检查版本号与更新信息，不收集任何个人数据。
# ============================================================

AG_NOTICE_DIR="/data/adb/ace_guard/notice"
AG_NOTICE_JSON="$AG_NOTICE_DIR/version.json"
AG_NOTICE_META="$AG_NOTICE_DIR/meta"
AG_NOTICE_LOG="$AG_NOTICE_DIR/notice.log"
AG_NOTICE_TMP="$AG_NOTICE_DIR/.fetch.tmp"
AG_FREEZE_FLAG="$AG_NOTICE_DIR/.need_update"

mkdir -p "$AG_NOTICE_DIR" 2>/dev/null
chmod 755 "$AG_NOTICE_DIR" 2>/dev/null

# 冻结执行器（终止全部模块进程 + 还原挂载）
[ -f "${MODDIR:-/data/adb/modules/ace_guard}/script/freeze.sh" ] && \
    . "${MODDIR:-/data/adb/modules/ace_guard}/script/freeze.sh"

# 持久配置层（版本号从 module.prop 迁出）
[ -f "${MODDIR:-/data/adb/modules/ace_guard}/script/config.sh" ] && \
    . "${MODDIR:-/data/adb/modules/ace_guard}/script/config.sh"

# 完整性指纹（内容哈希，与版本号解耦）
[ -f "${MODDIR:-/data/adb/modules/ace_guard}/script/integrity.sh" ] && \
    . "${MODDIR:-/data/adb/modules/ace_guard}/script/integrity.sh"



# 更新源地址：由核心程序内置提供，不读取配置文件
# 用户修改 config/guard.conf 也无法改变更新源
AG_CORE_BIN="${MODDIR:-/data/adb/modules/ace_guard}/lib/agcore"
if [ -x "$AG_CORE_BIN" ]; then
    NOTICE_URL=$("$AG_CORE_BIN" url 2>/dev/null)
    NOTICE_MIRROR=$("$AG_CORE_BIN" mirror 2>/dev/null)
else
    NOTICE_URL=""
    NOTICE_MIRROR=""
fi
NOTICE_INTERVAL="${NOTICE_INTERVAL:-300}"
NOTICE_TIMEOUT="${NOTICE_TIMEOUT:-${NET_TIMEOUT:-20}}"
# 联网总开关：0 = 离线模式，任何网络请求都不发
ENABLE_NETWORK="${ENABLE_NETWORK:-1}"
AG_N_REMOTE_VER=""
AG_N_CHANGELOG=""
AG_N_DLURL=""
AG_N_FETCH_TS=0
AG_N_NEED=0
AG_N_FORCE=0

# ============================================================
#  拉取
# ============================================================

ag_notice_http_get() {
    _url="$1"; _out="$2"; _to="${3:-$NOTICE_TIMEOUT}"
    if [ -x /system/bin/curl ]; then
        /system/bin/curl -sS -L -f -m "$_to" \
            -H 'User-Agent: AceGuard/2.0' \
            -o "$_out" "$_url" 2>>"$AG_NOTICE_LOG"
        return $?
    elif command -v wget >/dev/null 2>&1; then
        wget -q -T "$_to" -O "$_out" --header 'User-Agent: AceGuard/2.0' \
            "$_url" 2>>"$AG_NOTICE_LOG"
        return $?
    fi
    return 127
}

# 从 JSON 取字段（不依赖 jq，正则提取）
ag_notice_json_get() {
    # $1=文件 $2=字段名 $3=num|bool|str
    _f="$1"; _k="$2"; _t="${3:-str}"
    if [ "$_t" = "num" ]; then
        /system/bin/sed -n "s/.*\"${_k}\"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p" "$_f" 2>/dev/null | head -n1
    elif [ "$_t" = "bool" ]; then
        # 拆成每行一个字段，再用 grep 定位该字段行，最后提取 true/false
        _v=$(/system/bin/sed 's/,/,\
/g; s/{/{\
/g' "$_f" 2>/dev/null \
            | /system/bin/grep -F "\"${_k}\"" \
            | /system/bin/toybox head -n1 \
            | /system/bin/toybox tr -d ' \t')
        case "$_v" in
            *:true*|*:true\}*) echo 1 ;;
            *) echo 0 ;;
        esac
    else
        # 单行 JSON 也能正确截断：只取该字段第一个字符串值，不跨字段
        _v=$(/system/bin/toybox grep -o "\"${_k}\"[[:space:]]*:[[:space:]]*\"[^\"]*\"" "$_f" 2>/dev/null | head -n1)
        _v=$(printf '%s' "$_v" | /system/bin/sed "s/^\"${_k}\"[[:space:]]*:[[:space:]]*\"//; s/\"$//")
        # 还原 \n 转义为真实换行
        printf '%s' "$_v" | /system/bin/sed 's/\\n/\
/g; s/\\"/"/g; s/\\\\/\\/g'
    fi
}

# 本地 versionCode（权威来源：KSU 配置系统，不再直接信任 module.prop）
# 用户手改 module.prop 不会影响这里的判定结果。
ag_notice_local_vc() {
    _v=$(ag_cfg_installed_vc 2>/dev/null)
    case "$_v" in
        ''|*[!0-9]*)
            # 配置层不可用时的最终回退
            _mp="${MODDIR:-/data/adb/modules/ace_guard}/module.prop"
            /system/bin/sed -n 's/^versionCode=//p' "$_mp" 2>/dev/null \
                | head -n1 | /system/bin/toybox tr -dc '0-9'
            ;;
        *) printf '%s' "$_v" ;;
    esac
}
# 拉取一次；$1=force 强制
# 返回 0=成功 1=失败沿用旧 3=未配置
ag_notice_fetch() {
    [ -n "$NOTICE_URL" ] || return 3
    # 联网总开关关闭时不做任何网络请求
    [ "$ENABLE_NETWORK" = "1" ] || return 3

    # 先在函数入口保存参数：内部调用会覆盖位置参数 $1
    _mode="${1:-auto}"

    if [ "$_mode" != "force" ] && ag_notice_state_load; then
        _now=$(/system/bin/date +%s)
        # 本地版本变过就必须重新判定，不能因为没到拉取间隔就跳过
        _sig_now=$(ag_notice_local_sig)
        _sig_old=$(cat "$AG_NOTICE_DIR/.local_sig" 2>/dev/null)
        if [ "$_sig_now" != "$_sig_old" ]; then
            _mode="force"
        elif [ $(( _now - AG_N_FETCH_TS )) -lt "$NOTICE_INTERVAL" ]; then
            # 未到间隔，但仍要按最新本地版本复核一次判定结果
            ag_notice_evaluate >/dev/null 2>&1
            return 0
        fi
    fi

    _ok=1
    _best_vc=0
    _best_src=""

    # 记录当前已缓存的版本，作为接受下限
    if [ -f "$AG_NOTICE_JSON" ]; then
        _old_vc=$(ag_notice_json_get "$AG_NOTICE_JSON" versionCode num 2>/dev/null)
        case "$_old_vc" in ''|*[!0-9]*) _old_vc=0 ;; esac
    else
        _old_vc=0
    fi
    _best_vc=$_old_vc
    rm -f "$AG_NOTICE_TMP.best" 2>/dev/null

    for _src in "$NOTICE_URL" $NOTICE_MIRROR; do
        [ -n "$_src" ] || continue
        rm -f "$AG_NOTICE_TMP" 2>/dev/null
        if ag_notice_http_get "$_src" "$AG_NOTICE_TMP"; then
            if [ -s "$AG_NOTICE_TMP" ] && /system/bin/grep -q 'versionCode' "$AG_NOTICE_TMP" 2>/dev/null; then
                _src_vc=$(ag_notice_json_get "$AG_NOTICE_TMP" versionCode num 2>/dev/null)
                case "$_src_vc" in ''|*[!0-9]*) _src_vc=0 ;; esac
                echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') OK src=$_src vc=$_src_vc" >>"$AG_NOTICE_LOG"

                if [ "$_src" = "$NOTICE_URL" ]; then
                    # 主源是唯一权威：无论版本升高还是回退都无条件采纳
                    #   线上把版本改回去时必须能同步降下来，否则会永久冻结
                    cp -f "$AG_NOTICE_TMP" "$AG_NOTICE_TMP.best" 2>/dev/null
                    _best_vc=$_src_vc
                    _best_src=$_src
                    _ok=0
                elif [ "$_src_vc" -gt "$_best_vc" ]; then
                    # 镜像有缓存延迟，只允许补充更高版本，防止旧数据覆盖权威值
                    cp -f "$AG_NOTICE_TMP" "$AG_NOTICE_TMP.best" 2>/dev/null
                    _best_vc=$_src_vc
                    _best_src=$_src
                    _ok=0
                else
                    echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') SKIP src=$_src vc=$_src_vc 镜像低于已缓存 $_best_vc" >>"$AG_NOTICE_LOG"
                fi

                # 主源已成功取到数据，无需再试镜像
                if [ "$_src" = "$NOTICE_URL" ]; then
                    break
                fi
            else
                echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') BAD src=$_src" >>"$AG_NOTICE_LOG"
            fi
        else
            echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') FAIL src=$_src" >>"$AG_NOTICE_LOG"
        fi
    done
    rm -f "$AG_NOTICE_TMP" 2>/dev/null
    ag_notice_log_trim

    # 没有任何来源提供可用数据（或都低于缓存），保留原缓存
    if [ "$_ok" != "0" ] || [ ! -f "$AG_NOTICE_TMP.best" ]; then
        rm -f "$AG_NOTICE_TMP.best" 2>/dev/null
        [ "$_ok" = "0" ] && return 0
        return 1
    fi

    # 采纳最优结果
    mv -f "$AG_NOTICE_TMP.best" "$AG_NOTICE_JSON" 2>/dev/null
    chmod 644 "$AG_NOTICE_JSON" 2>/dev/null
    echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') ADOPT src=$_best_src vc=$_best_vc" >>"$AG_NOTICE_LOG"
    [ "$_ok" = "0" ] || return 1

    # 写 meta（拉取时间戳）
    echo "FETCH_TS=$(/system/bin/date +%s)" > "$AG_NOTICE_META" 2>/dev/null
    chmod 644 "$AG_NOTICE_META" 2>/dev/null

    ag_notice_state_load
    ag_notice_evaluate
    return 0
}

# 读取本地缓存的版本信息到 AG_N_*
ag_notice_state_load() {
    AG_N_FETCH_TS=0
    [ -f "$AG_NOTICE_META" ] && \
        AG_N_FETCH_TS=$(/system/bin/sed -n 's/^FETCH_TS=//p' "$AG_NOTICE_META" 2>/dev/null | head -n1)
    case "$AG_N_FETCH_TS" in ''|*[!0-9]*) AG_N_FETCH_TS=0 ;; esac

    [ -f "$AG_NOTICE_JSON" ] || return 1

    AG_N_REMOTE_VC=$(ag_notice_json_get "$AG_NOTICE_JSON" versionCode num)
    AG_N_REMOTE_VER=$(ag_notice_json_get "$AG_NOTICE_JSON" version str)
    AG_N_CHANGELOG=$(ag_notice_json_get "$AG_NOTICE_JSON" changelog str)
    AG_N_DLURL=$(ag_notice_json_get "$AG_NOTICE_JSON" url str)
    AG_N_FORCE=$(ag_notice_json_get "$AG_NOTICE_JSON" force bool)
    case "$AG_N_REMOTE_VC" in ''|*[!0-9]*) AG_N_REMOTE_VC=0 ;; esac
    case "$AG_N_FORCE" in ''|*[!0-9]*) AG_N_FORCE=0 ;; esac
    return 0
}

# 本地版本指纹：module.prop 的 versionCode + mtime
# 只要本地版本变化（哪怕没联网），就该重新判定一次
ag_notice_local_sig() {
    _mp="${MODDIR:-/data/adb/modules/ace_guard}/module.prop"
    _vc=$(ag_notice_local_vc)
    _mt=$(/system/bin/toybox stat -c %Y "$_mp" 2>/dev/null || echo 0)
    printf '%s:%s' "$_vc" "$_mt"
}

# 比较版本，写冻结标记并刷新模块卡片
ag_notice_evaluate() {
    _local=$(ag_notice_local_vc)
    case "$_local" in ''|*[!0-9]*) _local=0 ;; esac
    _newsig=$(ag_notice_local_sig)


    if [ "$AG_N_REMOTE_VC" -gt "$_local" ]; then
        AG_N_NEED=1
        _was_frozen=0
        [ -f "$AG_FREEZE_MARK" ] 2>/dev/null && _was_frozen=1

        # 已冻结且远程版本未变：不重复杀进程，避免陷入「刚拉起就被杀」的循环
        if [ "$_was_frozen" = "1" ]; then
            _prev=0
            [ -f "$AG_FREEZE_FLAG" ] && \
                _prev=$(/system/bin/sed -n 's/^REMOTE_VC=//p' "$AG_FREEZE_FLAG" 2>/dev/null | head -n1)
            case "$_prev" in ''|*[!0-9]*) _prev=0 ;; esac
            if [ "$_prev" = "$AG_N_REMOTE_VC" ]; then
                echo "$($/system/bin/date '+%Y-%m-%d %H:%M:%S') KEEP_FROZEN remote=$AG_N_REMOTE_VC local=$_local" >>"$AG_NOTICE_LOG"
                echo "$_newsig" > "$AG_NOTICE_DIR/.local_sig" 2>/dev/null
                return 0
            fi
        fi

        # 冻结标记：模块主功能闸门读它
        {
            echo "REMOTE_VC=$AG_N_REMOTE_VC"
            echo "REMOTE_VER=$AG_N_REMOTE_VER"
            echo "LOCAL_VC=$_local"
            echo "LOCAL_SIG=$_newsig"
            echo "FORCE=$AG_N_FORCE"
            echo "TS=$(/system/bin/date +%s)"
        } > "$AG_FREEZE_FLAG" 2>/dev/null
        chmod 644 "$AG_FREEZE_FLAG" 2>/dev/null
        echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') UPDATE remote=$AG_N_REMOTE_VC($AG_N_REMOTE_VER) local=$_local freeze=1" >>"$AG_NOTICE_LOG"
        # 立即终止所有模块进程并还原挂载（不是只挡新进程）
        if command -v ag_freeze_all >/dev/null 2>&1; then
            ag_freeze_all "new_version_$AG_N_REMOTE_VER" >/dev/null 2>&1
        fi
    else
        AG_N_NEED=0
        _was_frozen=0
        [ -f "$AG_FREEZE_MARK" ] 2>/dev/null && _was_frozen=1
        rm -f "$AG_FREEZE_FLAG" 2>/dev/null
        # 只有确实处于冻结态时才执行解冻，避免每次版本检查都刷一条已解除冻结
        if [ "$_was_frozen" = "1" ]; then
            if command -v ag_unfreeze_all >/dev/null 2>&1; then
                ag_unfreeze_all >/dev/null 2>&1
            fi
        fi
        echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') UPTODATE remote=$AG_N_REMOTE_VC local=$_local" >>"$AG_NOTICE_LOG"

        # 关键：从冻结态恢复时，必须把服务重新拉起来
        # 否则标记虽然删了，业务进程仍是 0 个，等于没恢复
        if [ "$_was_frozen" = "1" ]; then
            ag_notice_resume_service
        fi
    fi

    # 记录本次判定时的本地版本指纹，供守护进程检测变化
    echo "$_newsig" > "$AG_NOTICE_DIR/.local_sig" 2>/dev/null

    # 刷新 KSU 卡片
    command -v ag_auth_update_prop >/dev/null 2>&1 && ag_auth_update_prop 2>/dev/null
    ag_notice_log_trim
    return 0
}

# 解冻后重新拉起服务
ag_notice_resume_service() {
    _md="${MODDIR:-/data/adb/modules/ace_guard}"
    [ -f "$_md/service.sh" ] || return 0
    # 已在跑就不重复启动
    _running=$(/system/bin/toybox ps -A -o PID,ARGS 2>/dev/null \
        | /system/bin/grep -F "$_md/service.sh" | /system/bin/grep -vF grep | wc -l)
    [ "$_running" -gt 0 ] && return 0
    if command -v setsid >/dev/null 2>&1; then
        setsid /system/bin/sh "$_md/service.sh" </dev/null >>"$_md/log/service.log" 2>&1 &
    else
        nohup /system/bin/sh "$_md/service.sh" </dev/null >>"$_md/log/service.log" 2>&1 &
    fi
    echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') resume service after unfreeze" >>"$AG_NOTICE_LOG"
    return 0
}

# 是否需要更新（供主流程闸门调用，快，不联网）
# 自包含：自己读文件，不依赖调用方是否已 ag_notice_state_load
ag_notice_need_update() {
    # 缓存缺失或已过期时，尝试同步拉取一次（限时，避免拖慢开机）
    #   过期判断很关键：线上把版本改回去后，旧缓存会把冻结状态永久钉死
    _need_pull=0
    if [ ! -f "$AG_NOTICE_JSON" ]; then
        _need_pull=1
    else
        _fts=0
        [ -f "$AG_NOTICE_META" ] && \
            _fts=$(/system/bin/sed -n 's/^FETCH_TS=//p' "$AG_NOTICE_META" 2>/dev/null | head -n1)
        case "$_fts" in ''|*[!0-9]*) _fts=0 ;; esac
        _nowts=$(/system/bin/date +%s)
        _maxage="${NOTICE_STALE_MAX:-900}"
        if [ "$_fts" -le 0 ] || [ $(( _nowts - _fts )) -ge "$_maxage" ]; then
            _need_pull=1
        fi
    fi

    if [ "$_need_pull" = "1" ]; then
        _budget=6
        [ -x /system/bin/curl ] || _budget=0
        if [ "$_budget" -gt 0 ]; then
            AG_TIMEOUT_SAVED="${NOTICE_TIMEOUT:-}"
            NOTICE_TIMEOUT="$_budget"
            command -v ag_notice_fetch >/dev/null 2>&1 && ag_notice_fetch force >/dev/null 2>&1
            NOTICE_TIMEOUT="${AG_TIMEOUT_SAVED:-20}"
        fi
        [ -f "$AG_NOTICE_JSON" ] || return 1
    fi
    _rvc=$(ag_notice_json_get "$AG_NOTICE_JSON" versionCode num)
    case "$_rvc" in ''|*[!0-9]*) return 1 ;; esac
    [ "$_rvc" -le 0 ] && return 1
    _lvc=$(ag_notice_local_vc)
    case "$_lvc" in ''|*[!0-9]*) _lvc=0 ;; esac

    if [ "$_rvc" -gt "$_lvc" ]; then
        return 0
    fi

    # 本地版本已追平但标记还在（手动改 prop / 升级后残留）→ 顺手清理并拉服务
    if [ -f "$AG_FREEZE_FLAG" ] || [ -f "$AG_FREEZE_MARK" ]; then
        _was=0
        [ -f "$AG_FREEZE_MARK" ] && _was=1
        rm -f "$AG_FREEZE_FLAG" "$AG_FREEZE_MARK" 2>/dev/null
        echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') STALE_FLAG_CLEARED local=$_lvc remote=$_rvc" \
            >>"$AG_NOTICE_LOG" 2>/dev/null
        [ "$_was" = "1" ] && ag_notice_resume_service >/dev/null 2>&1
    fi
    return 1
}

ag_notice_log_trim() {
    [ -f "$AG_NOTICE_LOG" ] || return 0
    _sz=$(/system/bin/toybox stat -c %s "$AG_NOTICE_LOG" 2>/dev/null || echo 0)
    [ "$_sz" -gt 65536 ] && /system/bin/toybox tail -n 200 "$AG_NOTICE_LOG" > "$AG_NOTICE_LOG.t" 2>/dev/null && \
        mv -f "$AG_NOTICE_LOG.t" "$AG_NOTICE_LOG" 2>/dev/null
    return 0
}

# ============================================================
#  后台守护进程
# ============================================================
ag_notice_daemon() {
    _iv="$NOTICE_INTERVAL"
    case "$_iv" in ''|*[!0-9]*) _iv=300 ;; esac
    [ "$_iv" -lt 60 ] && _iv=60

    # 判定轮询间隔：远小于拉取间隔，保证改本地版本后能快速感知
    _check_iv="${NOTICE_CHECK_INTERVAL:-15}"
    case "$_check_iv" in ''|*[!0-9]*) _check_iv=15 ;; esac
    [ "$_check_iv" -lt 5 ] && _check_iv=5

    mkdir -p "${MODDIR:-/data/adb/modules/ace_guard}/data/run" 2>/dev/null
    _mypid=$$
    # 兼容 sh -c / setsid 包装：取最贴近自身的真实进程号
    _pstat=$(/system/bin/toybox cat "/proc/$$/stat" 2>/dev/null)
    case "$_pstat" in
        '') ;;
        *) _mypid=$(printf '%s' "$_pstat" | /system/bin/toybox cut -d' ' -f1) ;;
    esac
    case "$_mypid" in ''|*[!0-9]*) _mypid=$$ ;; esac
    echo "$_mypid" > "${MODDIR:-/data/adb/modules/ace_guard}/data/run/notice.pid" 2>/dev/null
    echo "$(/system/bin/date '+%Y-%m-%d %H:%M:%S') notice_daemon start iv=${_iv}s check=${_check_iv}s pid=$_mypid" >>"$AG_NOTICE_LOG"

    _last_fetch=0
    _last_sig=""

    while true; do
        # 每轮刷新 pid 文件，避免被外部清理或进程号记录过期
        _cur=$(/system/bin/toybox cat "${MODDIR:-/data/adb/modules/ace_guard}/data/run/notice.pid" 2>/dev/null)
        [ "$_cur" = "$_mypid" ] || echo "$_mypid" > "${MODDIR:-/data/adb/modules/ace_guard}/data/run/notice.pid" 2>/dev/null

        # ---- 1) 本地版本变化立即重新判定（不需要联网）----
        _cur_sig=$(ag_notice_local_sig)
        if [ "$_cur_sig" != "$_last_sig" ]; then
            _last_sig="$_cur_sig"
            if ag_notice_state_load 2>/dev/null; then
                ag_notice_evaluate >/dev/null 2>&1
            fi
        fi

        # ---- 2) 到点才联网拉取 ----
        # 冻结期间缩短拉取间隔：线上把版本改回去后要能尽快解冻
        _cur_iv="$_iv"
        if [ -f "$AG_FREEZE_MARK" ]; then
            _cur_iv="${NOTICE_FROZEN_INTERVAL:-60}"
            case "$_cur_iv" in ''|*[!0-9]*) _cur_iv=60 ;; esac
            [ "$_cur_iv" -lt 30 ] && _cur_iv=30
        fi
        _now=$(/system/bin/date +%s)
        if [ -n "$NOTICE_URL" ] && [ $(( _now - _last_fetch )) -ge "$_cur_iv" ]; then
            ag_notice_fetch force >/dev/null 2>&1
            _last_fetch=$_now
            _last_sig=$(ag_notice_local_sig)
        fi

        /system/bin/sleep "$_check_iv"
    done
}
