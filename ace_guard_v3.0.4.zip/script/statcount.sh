#!/system/bin/sh
# ACE Guard 使用人数统计
#
# 读取仓库 Issues 中带 stat 标签的记录数，作为使用人数展示。
# 只读，不修改任何数据。

AG_STAT_CACHE="/data/adb/ace_guard/stat/.count"
AG_STAT_TTL=600

# 取使用人数（带缓存，1 小时）
ag_stat_count() {
    _now=$(/system/bin/date +%s)

    if [ -f "$AG_STAT_CACHE" ]; then
        _ct=$(/system/bin/stat -c %Y "$AG_STAT_CACHE" 2>/dev/null || echo 0)
        case "$_ct" in ''|*[!0-9]*) _ct=0 ;; esac
        if [ "$_ct" -gt 0 ] && [ $(( _now - _ct )) -lt "$AG_STAT_TTL" ]; then
            /system/bin/cat "$AG_STAT_CACHE" 2>/dev/null
            return 0
        fi
    fi

    command -v ag_stat_load_cred >/dev/null 2>&1 || {
        . "${MODDIR:-/data/adb/modules/ace_guard}/script/stat.sh" 2>/dev/null
    }

    _ep=""; _tk=""
    if command -v ag_stat_load_cred >/dev/null 2>&1; then
        ag_stat_load_cred >/dev/null 2>&1
        _ep="$AG_STAT_ENDPOINT"
        _tk="$AG_STAT_TOKEN"
    fi
    [ -n "$_ep" ] && [ -n "$_tk" ] || return 1
    [ -x /system/bin/curl ] || return 1

    # 按标签过滤，取总数
    _url="${_ep}?state=all&labels=stat&per_page=100"
    _resp=$(/system/bin/curl -sS -m 15 \
        -H "Authorization: Bearer ${_tk}" \
        -H "Accept: application/vnd.github+json" \
        "$_url" 2>/dev/null)

    [ -n "$_resp" ] || return 1

    # 接口报错时不要当成 0 写缓存。
    #   常见情况：Token 失效返回 401 Bad credentials。
    #   之前会把 401 数成 0 并缓存一小时，界面一直显示 0。
    case "$_resp" in
        *'"message"'*'"status"'*)
            _em=$(printf '%s' "$_resp" | /system/bin/sed -n 's/.*"message"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | /system/bin/head -1)
            ag_log WARN "使用统计接口异常：${_em:-未知}，本次不写缓存"
            rm -f "$AG_STAT_CACHE" 2>/dev/null
            return 1
            ;;
    esac

    _n=$(printf '%s' "$_resp" | /system/bin/grep -c '"number"')
    case "$_n" in ''|*[!0-9]*) return 1 ;; esac

    mkdir -p "$(dirname "$AG_STAT_CACHE")" 2>/dev/null
    printf '%s\n' "$_n" > "$AG_STAT_CACHE" 2>/dev/null
    printf '%s' "$_n"
    return 0
}
